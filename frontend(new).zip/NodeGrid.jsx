// src/components/NodeGrid.jsx
import React from 'react'

function timeAgo(isoStr) {
  if (!isoStr) return '—'
  const diff = Math.floor((Date.now() - new Date(isoStr).getTime()) / 1000)
  if (diff < 5)   return 'just now'
  if (diff < 60)  return `${diff}s ago`
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`
  return `${Math.floor(diff / 3600)}h ago`
}

function NodeCard({ node, latestMetric }) {
  const online = node.status === 'online'

  return (
    <div
      className={`panel animate-slidein p-0 transition-all duration-300 ${
        online ? 'border-cyber-border' : 'border-cyber-red/30'
      }`}
      style={{ borderLeftWidth: 3, borderLeftColor: online ? 'var(--green)' : 'var(--red)' }}
    >
      {/* Header row */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-cyber-border">
        <div className="flex items-center gap-2">
          <span
            className={`dot ${online ? 'dot-green animate-pulse-slow' : 'dot-red'}`}
          />
          <span className="font-display font-700 text-[11px] tracking-wider text-cyber-text truncate max-w-[120px]">
            {node.node_id}
          </span>
        </div>
        <span
          className={`badge ${online ? 'badge-low' : 'badge-critical'}`}
        >
          {online ? 'ONLINE' : 'OFFLINE'}
        </span>
      </div>

      {/* Body */}
      <div className="px-3 py-2 space-y-1 text-[11px] text-cyber-muted font-mono">
        <div className="flex justify-between">
          <span>HOST</span>
          <span className="text-cyber-text truncate max-w-[120px]">{node.hostname || '—'}</span>
        </div>
        <div className="flex justify-between">
          <span>IP</span>
          <span className="text-cyber-cyan">{node.ip_address || '—'}</span>
        </div>
        <div className="flex justify-between">
          <span>LAST SEEN</span>
          <span className={online ? 'text-cyber-green' : 'text-cyber-red'}>
            {timeAgo(node.last_seen)}
          </span>
        </div>
      </div>

      {/* Live metric strip */}
      {latestMetric && (
        <div className="grid grid-cols-2 gap-px border-t border-cyber-border">
          <div className="px-3 py-1 bg-cyber-surface/60">
            <div className="text-[9px] text-cyber-muted">LATENCY</div>
            <div className={`text-[13px] font-bold ${
              latestMetric.latency_ms > 200 ? 'text-cyber-red' :
              latestMetric.latency_ms > 100 ? 'text-cyber-amber' : 'text-cyber-green'
            }`}>
              {latestMetric.latency_ms?.toFixed(1)} ms
            </div>
          </div>
          <div className="px-3 py-1 bg-cyber-surface/60">
            <div className="text-[9px] text-cyber-muted">LOSS</div>
            <div className={`text-[13px] font-bold ${
              latestMetric.packet_loss_rate > 0.05 ? 'text-cyber-red' :
              latestMetric.packet_loss_rate > 0.02 ? 'text-cyber-amber' : 'text-cyber-green'
            }`}>
              {((latestMetric.packet_loss_rate || 0) * 100).toFixed(1)}%
            </div>
          </div>
          <div className="px-3 py-1 bg-cyber-surface/60">
            <div className="text-[9px] text-cyber-muted">THROUGHPUT</div>
            <div className={`text-[13px] font-bold ${
              latestMetric.throughput_mbps < 1 ? 'text-cyber-red' :
              latestMetric.throughput_mbps < 5 ? 'text-cyber-amber' : 'text-cyber-cyan'
            }`}>
              {latestMetric.throughput_mbps?.toFixed(1)} Mbps
            </div>
          </div>
          <div className="px-3 py-1 bg-cyber-surface/60">
            <div className="text-[9px] text-cyber-muted">JITTER</div>
            <div className={`text-[13px] font-bold ${
              latestMetric.jitter_ms > 50 ? 'text-cyber-red' :
              latestMetric.jitter_ms > 20 ? 'text-cyber-amber' : 'text-cyber-text'
            }`}>
              {latestMetric.jitter_ms?.toFixed(1)} ms
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default function NodeGrid({ nodeMap, metricStream }) {
  const nodes = Object.values(nodeMap)
  const online  = nodes.filter(n => n.status === 'online').length
  const offline = nodes.filter(n => n.status !== 'online').length

  // Build latest metric per node
  const latestByNode = {}
  for (const m of metricStream) {
    if (!latestByNode[m.node_id]) latestByNode[m.node_id] = m
  }

  return (
    <div className="panel h-full flex flex-col">
      <div className="panel-header justify-between">
        <div className="flex items-center gap-2">
          <span className="dot dot-cyan" />
          NODE STATUS
        </div>
        <div className="flex gap-3 text-[10px] font-mono">
          <span className="text-cyber-green">{online} ONLINE</span>
          <span className="text-cyber-muted">|</span>
          <span className={offline > 0 ? 'text-cyber-red' : 'text-cyber-muted'}>
            {offline} OFFLINE
          </span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3">
        {nodes.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-32 text-cyber-muted text-[11px]">
            <div className="text-2xl mb-2">◌</div>
            <div>Waiting for nodes to connect...</div>
            <div className="text-[10px] mt-1 text-cyber-border">
              Start a client: python node_client.py --server &lt;IP&gt;
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-2">
            {nodes
              .sort((a, b) => {
                // Online first, then by node_id
                if (a.status === b.status) return a.node_id.localeCompare(b.node_id)
                return a.status === 'online' ? -1 : 1
              })
              .map(node => (
                <NodeCard
                  key={node.node_id}
                  node={node}
                  latestMetric={latestByNode[node.node_id]}
                />
              ))
            }
          </div>
        )}
      </div>
    </div>
  )
}
