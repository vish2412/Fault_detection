import { motion, AnimatePresence } from 'framer-motion';
import { useSimulationStore } from '../../store/simulationStore';
import { StatusBadge } from '../ui/StatusBadge';
import type { NetworkNode, FaultType } from '../../simulation/types';

const TYPE_ICON: Record<NetworkNode['type'], string> = {
  core: '🖥️',
  gateway: '🔀',
  edge: '📡',
  endpoint: '💻',
};

const TYPE_COLOR: Record<NetworkNode['type'], string> = {
  core: 'border-violet-500/40',
  gateway: 'border-blue-500/40',
  edge: 'border-cyan-500/40',
  endpoint: 'border-slate-500/40',
};

function NodeCard({ node }: { node: NetworkNode }) {
  const { selectedNodeId, setSelectedNode, forceNodeFault, recoverNode, setActiveTab } = useSimulationStore();
  const isSelected = selectedNodeId === node.id;
  const m = node.currentMetrics;

  const borderGlow = {
    healthy:  'shadow-emerald-500/10',
    warning:  'shadow-amber-500/20',
    critical: 'shadow-red-500/30',
    offline:  'shadow-slate-500/10',
  };

  const statusBg = {
    healthy:  'bg-emerald-500/5',
    warning:  'bg-amber-500/10',
    critical: 'bg-red-500/15',
    offline:  'bg-slate-800/50',
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.02 }}
      onClick={() => { setSelectedNode(isSelected ? null : node.id); setActiveTab('dashboard'); }}
      className={`
        cursor-pointer rounded-xl border p-3 transition-all duration-300
        ${TYPE_COLOR[node.type]} ${statusBg[node.status]}
        ${isSelected ? 'ring-2 ring-blue-500/60 shadow-lg shadow-blue-500/20' : ''}
        shadow-lg ${borderGlow[node.status]}
      `}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className="text-xl">{TYPE_ICON[node.type]}</span>
          <div>
            <p className="text-xs font-bold text-white font-mono">{node.name}</p>
            <p className="text-xs text-slate-500 font-mono">{node.ip}</p>
          </div>
        </div>
        <StatusBadge status={node.status} pulse={node.status === 'critical'} size="sm" />
      </div>

      {/* Metrics */}
      {node.status !== 'offline' ? (
        <div className="grid grid-cols-2 gap-1.5 mt-2">
          <div className="rounded-lg bg-slate-800/60 px-2 py-1">
            <p className="text-xs text-slate-500">Latency</p>
            <p className={`text-sm font-mono font-bold ${m.latency > 200 ? 'text-red-400' : m.latency > 100 ? 'text-amber-400' : 'text-emerald-400'}`}>
              {m.latency.toFixed(0)}<span className="text-xs text-slate-600">ms</span>
            </p>
          </div>
          <div className="rounded-lg bg-slate-800/60 px-2 py-1">
            <p className="text-xs text-slate-500">Loss</p>
            <p className={`text-sm font-mono font-bold ${m.packetLoss > 10 ? 'text-red-400' : m.packetLoss > 5 ? 'text-amber-400' : 'text-emerald-400'}`}>
              {m.packetLoss.toFixed(1)}<span className="text-xs text-slate-600">%</span>
            </p>
          </div>
          <div className="rounded-lg bg-slate-800/60 px-2 py-1">
            <p className="text-xs text-slate-500">Throughput</p>
            <p className="text-sm font-mono font-bold text-blue-400">
              {m.throughput.toFixed(0)}<span className="text-xs text-slate-600">M</span>
            </p>
          </div>
          <div className="rounded-lg bg-slate-800/60 px-2 py-1">
            <p className="text-xs text-slate-500">Jitter</p>
            <p className={`text-sm font-mono font-bold ${m.jitter > 30 ? 'text-amber-400' : 'text-slate-300'}`}>
              {m.jitter.toFixed(1)}<span className="text-xs text-slate-600">ms</span>
            </p>
          </div>
        </div>
      ) : (
        <div className="mt-2 rounded-lg bg-slate-800/60 px-3 py-2 text-center">
          <p className="text-red-400 text-xs font-mono">● NODE OFFLINE</p>
          <p className="text-slate-500 text-xs">No heartbeat received</p>
        </div>
      )}

      {/* Faults */}
      {node.faults.length > 0 && (
        <div className="mt-2 space-y-0.5">
          {node.faults.slice(0, 2).map(f => (
            <div key={f.id} className="flex items-center gap-1 text-xs font-mono text-red-400 truncate">
              <span>⚠</span><span className="truncate">{f.faultType}</span>
            </div>
          ))}
        </div>
      )}

      {/* Region + Type */}
      <div className="mt-2 flex items-center justify-between">
        <span className="text-xs text-slate-600 font-mono">{node.region}</span>
        <span className="text-xs text-slate-600 font-mono uppercase">{node.type}</span>
      </div>

      {/* Quick actions (show on hover/select) */}
      <AnimatePresence>
        {isSelected && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-2 pt-2 border-t border-slate-700/50"
            onClick={e => e.stopPropagation()}
          >
            <p className="text-xs text-slate-400 mb-1 font-mono">Inject Fault:</p>
            <div className="flex flex-wrap gap-1">
              {(['HIGH_LATENCY', 'PACKET_LOSS', 'NODE_FAILURE', 'CONGESTION'] as FaultType[]).map(ft => (
                <button
                  key={ft}
                  onClick={() => forceNodeFault(node.id, ft)}
                  className="text-xs px-2 py-0.5 rounded bg-red-500/20 text-red-400 hover:bg-red-500/40 font-mono transition-colors"
                >
                  {ft.replace('_', ' ')}
                </button>
              ))}
              <button
                onClick={() => recoverNode(node.id)}
                className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/40 font-mono transition-colors"
              >
                RECOVER
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export function NodeGrid() {
  const nodes = useSimulationStore(s => s.nodes);

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3">
      <AnimatePresence mode="popLayout">
        {nodes.map(node => (
          <NodeCard key={node.id} node={node} />
        ))}
      </AnimatePresence>
    </div>
  );
}
