import hashlib
import logging
import os
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from config import get_settings
from database.db import get_db
from database.models import FileTransfer

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/files", tags=["files"])
settings = get_settings()


def compute_sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


@router.post("/upload")
async def upload_file(
    node_id: str = Form(...),
    client_checksum: str = Form(..., description="SHA256 checksum computed by the client"),
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
):
    """
    Receive a file from a node, compute its SHA256, compare with client's checksum.
    Returns corruption status.
    """
    # Read file content
    content = await file.read()

    # Compute server-side checksum
    server_checksum = compute_sha256(content)

    # Determine corruption
    is_corrupted = server_checksum.lower() != client_checksum.lower()

    # Persist file to uploads directory
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    file_id = str(uuid.uuid4())
    save_path = os.path.join(settings.UPLOAD_DIR, f"{file_id}_{file.filename}")
    with open(save_path, "wb") as f:
        f.write(content)

    # Store transfer record
    transfer = FileTransfer(
        transfer_id=file_id,
        node_id=node_id,
        filename=file.filename,
        file_size_bytes=len(content),
        client_checksum=client_checksum.lower(),
        server_checksum=server_checksum,
        is_corrupted=is_corrupted,
        saved_path=save_path,
        transferred_at=datetime.utcnow(),
    )
    db.add(transfer)
    await db.commit()

    result = {
        "transfer_id": file_id,
        "node_id": node_id,
        "filename": file.filename,
        "file_size_bytes": len(content),
        "client_checksum": client_checksum.lower(),
        "server_checksum": server_checksum,
        "checksum_match": not is_corrupted,
        "corruption_detected": is_corrupted,
        "transferred_at": transfer.transferred_at.isoformat(),
    }

    if is_corrupted:
        logger.warning(
            "DATA CORRUPTION detected for node=%s file=%s | client=%s server=%s",
            node_id, file.filename, client_checksum, server_checksum,
        )

    return result


@router.get("/transfers")
async def list_transfers(
    node_id: str | None = None,
    corrupted_only: bool = False,
    limit: int = 50,
    db: AsyncSession = Depends(get_db),
):
    """List file transfer records."""
    query = select(FileTransfer)
    if node_id:
        query = query.where(FileTransfer.node_id == node_id)
    if corrupted_only:
        query = query.where(FileTransfer.is_corrupted == True)  # noqa: E712

    query = query.order_by(FileTransfer.transferred_at.desc()).limit(limit)
    result = await db.execute(query)
    transfers = result.scalars().all()

    return {
        "transfers": [
            {
                "transfer_id": t.transfer_id,
                "node_id": t.node_id,
                "filename": t.filename,
                "file_size_bytes": t.file_size_bytes,
                "checksum_match": not t.is_corrupted,
                "corruption_detected": t.is_corrupted,
                "transferred_at": t.transferred_at.isoformat() if t.transferred_at else None,
            }
            for t in transfers
        ]
    }
