import { motion } from 'framer-motion';
import type { ReactNode } from 'react';

interface MetricCardProps {
  label: string;
  value: string | number;
  unit?: string;
  icon: ReactNode;
  trend?: 'up' | 'down' | 'stable';
  status?: 'good' | 'warn' | 'bad' | 'neutral';
  subtext?: string;
  className?: string;
  animateIn?: boolean;
}

const STATUS_COLORS = {
  good:    'from-emerald-500/10 to-emerald-500/5 border-emerald-500/30',
  warn:    'from-amber-500/10 to-amber-500/5 border-amber-500/30',
  bad:     'from-red-500/10 to-red-500/5 border-red-500/30',
  neutral: 'from-slate-500/10 to-slate-500/5 border-slate-500/30',
};

const VALUE_COLORS = {
  good:    'text-emerald-300',
  warn:    'text-amber-300',
  bad:     'text-red-300',
  neutral: 'text-slate-200',
};

export function MetricCard({
  label, value, unit, icon, trend, status = 'neutral', subtext, className = '', animateIn = false,
}: MetricCardProps) {
  const trendIcon = trend === 'up' ? '↑' : trend === 'down' ? '↓' : '→';
  const trendColor = trend === 'up' ? 'text-red-400' : trend === 'down' ? 'text-emerald-400' : 'text-slate-400';

  return (
    <motion.div
      initial={animateIn ? { opacity: 0, y: 20 } : {}}
      animate={animateIn ? { opacity: 1, y: 0 } : {}}
      className={`
        relative overflow-hidden rounded-xl border bg-gradient-to-br p-4
        backdrop-blur-sm transition-all duration-300 hover:scale-[1.02]
        ${STATUS_COLORS[status]} ${className}
      `}
    >
      {/* Background glow */}
      <div className={`absolute -top-4 -right-4 w-16 h-16 rounded-full blur-2xl opacity-20
        ${status === 'good' ? 'bg-emerald-500' : status === 'warn' ? 'bg-amber-500' : status === 'bad' ? 'bg-red-500' : 'bg-slate-500'}
      `} />

      <div className="relative flex items-start justify-between">
        <div className="flex-1">
          <p className="text-xs font-mono text-slate-400 uppercase tracking-widest mb-1">{label}</p>
          <div className="flex items-baseline gap-1">
            <motion.span
              key={String(value)}
              initial={{ opacity: 0.5, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              className={`text-2xl font-bold font-mono ${VALUE_COLORS[status]}`}
            >
              {typeof value === 'number' ? (Number.isInteger(value) ? value : value.toFixed(1)) : value}
            </motion.span>
            {unit && <span className="text-xs text-slate-500 font-mono">{unit}</span>}
            {trend && <span className={`text-xs font-mono ${trendColor}`}>{trendIcon}</span>}
          </div>
          {subtext && <p className="text-xs text-slate-500 mt-0.5 font-mono">{subtext}</p>}
        </div>
        <div className="text-2xl opacity-70">{icon}</div>
      </div>
    </motion.div>
  );
}
