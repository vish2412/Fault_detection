/**
 * MLPanel.jsx
 * -----------
 * Displays the most recent ML prediction in detail:
 *   - Fault type + severity badge
 *   - Confidence progress bar
 *   - Full class-probability breakdown
 *   - Recent prediction history (last 20)
 *   - Model availability state
 */

import React, { useState, useEffect, useRef } from "react";
import { clsx } from "clsx";
import { getSeverityColor } from "../hooks/useMetricColor.js";

const FAULT_ICONS = {
  NODE_FAILURE:           "💀",
  HIGH_LATENCY:           "⏱",
  PACKET_LOSS:            "📦",
  THROUGHPUT_DEGRADATION: "📉",
  NETWORK_CONGESTION:     "🚦",
  DATA_CORRUPTION:        "🔥",
  NORMAL:                 "✅",
};

const CLASS_COLORS = {
  NORMAL:                  "#34d399",
  HIGH_LATENCY:            "#fbbf24",
  PACKET_LOSS:             "#fb923c",
  THROUGHPUT_DEGRADATION:  "#a78bfa",
  NETWORK_CONGESTION:      "#f87171",
  DATA_CORRUPTION:         "#ef4444",
  NODE_FAILURE:            "#dc2626",
};

function ProbBar({ label, prob, maxProb, isTop }) {
  const pct   = maxProb > 0 ? (prob / maxProb) * 100 : 0;
  const color = CLASS_COLORS[label] || "#64748b";
  return (
    <div className={clsx("flex items-center gap-3 py-1.5", isTop && "rounded-lg px-2 bg-white/5")}>
      <span className="text-sm leading-none flex-shrink-0">
        {FAULT_ICONS[label] || "⚠"}
      </span>
      <div className="flex-1 min-w-0">
        <div className="flex justify-between items-center mb-1">
          <span className={clsx("text-xs font-medium", isTop ? "text-white" : "text-slate-400")}>
            {label.replace(/_/g, " ")}
          </span>
          <span className="text-xs font-mono" style={{ color }}>
            {(prob * 100).toFixed(2)}%
          </span>
        </div>
        <div className="w-full h-1.5 bg-surface-600 rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{ width: `${pct}%`, backgroundColor: color }}
          />
        </div>
      </div>
    </div>
  );
}

// ── Prediction history chip ────────────────────────────────────────────────────
function HistoryChip({ prediction }) {
  const sc = getSeverityColor(prediction.severity);
  return (
    <div className={clsx(
      "flex-shrink-0 px-2.5 py-1.5 rounded-lg border text-center min-w-[90px]",
      sc.bg, sc.border
    )}>
      <p className={clsx("text-[10px] font-bold truncate", sc.text)}>
        {prediction.fault_type?.replace(/_/g, " ")}
      </p>
      <p className="text-[10px] text-slate-500 font-mono mt-0.5">
        {prediction.confidence != null ? `${(prediction.confidence * 100).toFixed(0)}%` : "—"}
      </p>
    </div>
  );
}

// ── MLPanel ────────────────────────────────────────────────────────────────────
export default function MLPanel({ lastPrediction, alerts, nodes }) {
  // Keep a rolling history of the last 20 predictions
  const [history, setHistory] = useState([]);
  const prevPredRef = useRef(null);

  useEffect(() => {
    if (!lastPrediction) return;
    if (
      prevPredRef.current &&
      prevPredRef.current.ts === lastPrediction.ts &&
      prevPredRef.current.nodeId === lastPrediction.nodeId
    ) return;
    prevPredRef.current = lastPrediction;
    setHistory((prev) => [lastPrediction, ...prev].slice(0, 20));
  }, [lastPrediction]);

  const p = lastPrediction;
  const available = p?.ml_available !== false;

  // Sort class probs descending
  const sortedProbs = p?.class_probabilities
    ? Object.entries(p.class_probabilities).sort(([, a], [, b]) => b - a)
    : [];
  const maxProb = sortedProbs[0]?.[1] || 1;

  // ML-sourced alerts from alert feed
  const mlAlerts = alerts.filter((a) => a.source === "ml_engine" || a.mlPrediction?.ml_available).slice(0, 5);

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">

      {/* ── Left: Current prediction ───────────────────────────────────────── */}
      <div className="xl:col-span-2 space-y-4">

        {/* Model status banner */}
        <div className={clsx(
          "glass-card px-4 py-3 flex items-center gap-3",
          available ? "border-emerald-500/30" : "border-amber-500/30"
        )}>
          <span className="text-xl">{available ? "🤖" : "⚠️"}</span>
          <div>
            <p className={clsx("text-sm font-semibold", available ? "text-emerald-400" : "text-amber-400")}>
              {available ? "ML Model Active" : "ML Model Not Available"}
            </p>
            <p className="text-xs text-slate-500">
              {available
                ? "RandomForestClassifier — 7 fault classes — real-time inference"
                : "Run: python ml_model/train.py to generate the model"}
            </p>
          </div>
        </div>

        {/* Current prediction card */}
        {!p || !available ? (
          <div className="glass-card p-12 text-center">
            <div className="text-4xl mb-3">📡</div>
            <p className="text-slate-400">Waiting for the first ML prediction…</p>
            <p className="text-slate-500 text-xs mt-1">
              Predictions arrive with each metric sample from a connected node.
            </p>
          </div>
        ) : (
          <div className="glass-card p-6">
            {/* Fault type hero */}
            <div className="flex items-center gap-4 mb-6">
              <span className="text-5xl leading-none">{FAULT_ICONS[p.fault_type] || "⚠"}</span>
              <div>
                <p className="text-2xl font-bold text-white">
                  {p.fault_type?.replace(/_/g, " ")}
                </p>
                <div className="flex items-center gap-2 mt-1 flex-wrap">
                  {p.severity && (
                    <span className={clsx(
                      "text-xs font-bold px-2 py-0.5 rounded-full border",
                      getSeverityColor(p.severity).text,
                      getSeverityColor(p.severity).bg,
                      getSeverityColor(p.severity).border
                    )}>
                      {p.severity}
                    </span>
                  )}
                  <span className="text-xs text-slate-500 font-mono">{p.nodeId}</span>
                </div>
              </div>
              {/* Confidence ring */}
              <div className="ml-auto text-center">
                <div className="relative w-16 h-16">
                  <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                    <circle cx="18" cy="18" r="15.9" fill="none" stroke="#1e2745" strokeWidth="3" />
                    <circle
                      cx="18" cy="18" r="15.9" fill="none"
                      stroke={CLASS_COLORS[p.fault_type] || "#6470f3"}
                      strokeWidth="3"
                      strokeDasharray={`${(p.confidence || 0) * 100} 100`}
                      strokeLinecap="round"
                    />
                  </svg>
                  <span className="absolute inset-0 flex items-center justify-center text-xs font-bold text-white">
                    {p.confidence != null ? `${(p.confidence * 100).toFixed(0)}%` : "—"}
                  </span>
                </div>
                <p className="text-[10px] text-slate-500 mt-1">confidence</p>
              </div>
            </div>

            {/* Class probability breakdown */}
            {sortedProbs.length > 0 && (
              <div>
                <p className="section-title mb-3">Class Probabilities</p>
                <div className="space-y-0.5">
                  {sortedProbs.map(([cls, prob], i) => (
                    <ProbBar
                      key={cls}
                      label={cls}
                      prob={prob}
                      maxProb={maxProb}
                      isTop={i === 0}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* ── Right: History + ML alerts ─────────────────────────────────────── */}
      <div className="space-y-4">

        {/* Prediction history */}
        <div className="glass-card p-4">
          <p className="section-title mb-3">Recent Predictions</p>
          {history.length === 0 ? (
            <p className="text-slate-500 text-sm text-center py-4">No predictions yet.</p>
          ) : (
            <div className="flex flex-wrap gap-2 max-h-64 overflow-y-auto scrollbar-thin">
              {history.map((h, i) => (
                <HistoryChip key={i} prediction={h} />
              ))}
            </div>
          )}
        </div>

        {/* Fault distribution from alerts */}
        <div className="glass-card p-4">
          <p className="section-title mb-3">Fault Distribution</p>
          <FaultDistChart alerts={alerts} />
        </div>

        {/* Model info */}
        <div className="glass-card p-4">
          <p className="section-title mb-3">Model Info</p>
          <div className="space-y-2 text-xs">
            {[
              ["Algorithm",  "RandomForestClassifier"],
              ["Estimators", "200 trees"],
              ["Features",   "latency · loss · throughput · jitter"],
              ["Classes",    "7 fault types"],
              ["Scaling",    "StandardScaler"],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-2">
                <span className="text-slate-500">{k}</span>
                <span className="text-slate-300 font-mono text-right">{v}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Fault distribution mini-chart ─────────────────────────────────────────────
function FaultDistChart({ alerts }) {
  const counts = {};
  alerts.forEach((a) => {
    counts[a.faultType] = (counts[a.faultType] || 0) + 1;
  });
  const sorted = Object.entries(counts).sort(([, a], [, b]) => b - a);
  const total  = sorted.reduce((s, [, c]) => s + c, 0);

  if (sorted.length === 0) {
    return <p className="text-slate-500 text-xs text-center py-3">No fault data yet.</p>;
  }

  return (
    <div className="space-y-2">
      {sorted.map(([fault, count]) => {
        const pct   = total > 0 ? (count / total) * 100 : 0;
        const color = CLASS_COLORS[fault] || "#64748b";
        return (
          <div key={fault} className="flex items-center gap-2">
            <span className="text-sm flex-shrink-0">{FAULT_ICONS[fault] || "⚠"}</span>
            <div className="flex-1 min-w-0">
              <div className="flex justify-between mb-0.5">
                <span className="text-[10px] text-slate-400 truncate">{fault.replace(/_/g, " ")}</span>
                <span className="text-[10px] font-mono" style={{ color }}>{count}</span>
              </div>
              <div className="w-full h-1 bg-surface-600 rounded-full overflow-hidden">
                <div className="h-full rounded-full" style={{ width: `${pct}%`, backgroundColor: color }} />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
