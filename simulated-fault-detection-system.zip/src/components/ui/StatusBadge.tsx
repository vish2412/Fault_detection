import { motion } from 'framer-motion';
import type { NodeStatus, AlertSeverity } from '../../simulation/types';

interface StatusBadgeProps {
  status?: NodeStatus;
  severity?: AlertSeverity;
  pulse?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

const STATUS_CONFIG = {
  healthy:  { label: 'HEALTHY',  color: 'text-emerald-400', bg: 'bg-emerald-500/20', border: 'border-emerald-500/50', dot: 'bg-emerald-400' },
  warning:  { label: 'WARNING',  color: 'text-amber-400',   bg: 'bg-amber-500/20',   border: 'border-amber-500/50',   dot: 'bg-amber-400'   },
  critical: { label: 'CRITICAL', color: 'text-red-400',     bg: 'bg-red-500/20',     border: 'border-red-500/50',     dot: 'bg-red-400'     },
  offline:  { label: 'OFFLINE',  color: 'text-slate-400',   bg: 'bg-slate-500/20',   border: 'border-slate-500/50',   dot: 'bg-slate-400'   },
};

const SEVERITY_CONFIG = {
  LOW:      { label: 'LOW',      color: 'text-blue-400',    bg: 'bg-blue-500/20',    border: 'border-blue-500/50',    dot: 'bg-blue-400'    },
  MEDIUM:   { label: 'MEDIUM',   color: 'text-amber-400',   bg: 'bg-amber-500/20',   border: 'border-amber-500/50',   dot: 'bg-amber-400'   },
  CRITICAL: { label: 'CRITICAL', color: 'text-red-400',     bg: 'bg-red-500/20',     border: 'border-red-500/50',     dot: 'bg-red-400'     },
};

const SIZE_CLASS = {
  sm: 'text-xs px-1.5 py-0.5',
  md: 'text-xs px-2 py-1',
  lg: 'text-sm px-3 py-1.5',
};

export function StatusBadge({ status, severity, pulse = false, size = 'md' }: StatusBadgeProps) {
  const cfg = status ? STATUS_CONFIG[status] : severity ? SEVERITY_CONFIG[severity] : STATUS_CONFIG.healthy;

  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border font-mono font-semibold ${cfg.bg} ${cfg.border} ${cfg.color} ${SIZE_CLASS[size]}`}>
      <span className="relative flex h-1.5 w-1.5">
        {pulse && (
          <motion.span
            className={`absolute inline-flex h-full w-full rounded-full ${cfg.dot} opacity-75`}
            animate={{ scale: [1, 2, 1], opacity: [0.75, 0, 0.75] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          />
        )}
        <span className={`relative inline-flex rounded-full h-1.5 w-1.5 ${cfg.dot}`} />
      </span>
      {cfg.label}
    </span>
  );
}
