import { motion, AnimatePresence } from 'framer-motion';
import { useSimulationStore } from '../../store/simulationStore';
import type { NetworkNode } from '../../simulation/types';
import { useState, useRef, useCallback } from 'react';
import { StatusBadge } from '../ui/StatusBadge';

const TYPE_ICON: Record<NetworkNode['type'], string> = {
  core: '🖥️', gateway: '🔀', edge: '📡', endpoint: '💻',
};

const NODE_COLORS = {
  healthy:  { stroke: '#10b981', fill: '#065f46', glow: '#10b981' },
  warning:  { stroke: '#f59e0b', fill: '#78350f', glow: '#f59e0b' },
  critical: { stroke: '#ef4444', fill: '#7f1d1d', glow: '#ef4444' },
  offline:  { stroke: '#475569', fill: '#1e293b', glow: '#475569' },
};

const TYPE_SIZE: Record<NetworkNode['type'], number> = {
  core: 38, gateway: 30, edge: 25, endpoint: 20,
};

// Connection colors based on status of both endpoints
function getConnectionColor(nodeA: NetworkNode, nodeB: NetworkNode): string {
  if (nodeA.status === 'offline' || nodeB.status === 'offline') return '#334155';
  if (nodeA.status === 'critical' || nodeB.status === 'critical') return '#ef444488';
  if (nodeA.status === 'warning' || nodeB.status === 'warning') return '#f59e0b88';
  return '#10b98144';
}

// Unique connections set
function getConnections(nodes: NetworkNode[]): [NetworkNode, NetworkNode][] {
  const seen = new Set<string>();
  const connections: [NetworkNode, NetworkNode][] = [];
  nodes.forEach(node => {
    node.connections.forEach(connId => {
      const key = [node.id, connId].sort().join('-');
      if (!seen.has(key)) {
        seen.add(key);
        const target = nodes.find(n => n.id === connId);
        if (target) connections.push([node, target]);
      }
    });
  });
  return connections;
}

export function NetworkTopology() {
  const { nodes, selectedNodeId, setSelectedNode, forceNodeFault, recoverNode } = useSimulationStore();
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  const connections = getConnections(nodes);

  const W = 780;
  const H = 480;

  // Scale positions to SVG
  const scaleX = (x: number) => (x / 750) * W;
  const scaleY = (y: number) => (y / 460) * H;

  const handleNodeClick = useCallback((nodeId: string) => {
    setSelectedNode(selectedNodeId === nodeId ? null : nodeId);
  }, [selectedNodeId, setSelectedNode]);

  const selectedNode = nodes.find(n => n.id === selectedNodeId);

  return (
    <div className="flex gap-4">
      {/* SVG Topology */}
      <div className="flex-1 rounded-2xl border border-slate-700/60 bg-slate-900/70 backdrop-blur-md overflow-hidden">
        <div className="px-5 py-3 border-b border-slate-700/50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">🌐</span>
            <h3 className="text-sm font-semibold text-slate-200 font-mono uppercase tracking-wide">Network Topology</h3>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono text-slate-500">
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500" />Healthy</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-500" />Warning</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500" />Critical</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-slate-600" />Offline</span>
          </div>
        </div>

        <div className="p-4">
          <svg
            ref={svgRef}
            viewBox={`0 0 ${W} ${H}`}
            className="w-full"
            style={{ height: '420px' }}
          >
            {/* Background grid */}
            <defs>
              <pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse">
                <path d="M 30 0 L 0 0 0 30" fill="none" stroke="#1e293b" strokeWidth="0.5" />
              </pattern>
              {nodes.map(n => {
                return (
                  <filter key={`glow-${n.id}`} id={`glow-${n.id}`}>
                    <feGaussianBlur stdDeviation="4" result="coloredBlur" />
                    <feMerge>
                      <feMergeNode in="coloredBlur" />
                      <feMergeNode in="SourceGraphic" />
                    </feMerge>
                  </filter>
                );
              })}
            </defs>
            <rect width={W} height={H} fill="url(#grid)" />

            {/* Connections */}
            {connections.map(([a, b]) => {
              const color = getConnectionColor(a, b);
              const isActive = (a.id === selectedNodeId || b.id === selectedNodeId ||
                a.id === hoveredId || b.id === hoveredId);
              const ax = scaleX(a.position.x);
              const ay = scaleY(a.position.y);
              const bx = scaleX(b.position.x);
              const by = scaleY(b.position.y);

              return (
                <g key={`${a.id}-${b.id}`}>
                  <line
                    x1={ax} y1={ay} x2={bx} y2={by}
                    stroke={isActive ? '#60a5fa' : color}
                    strokeWidth={isActive ? 2 : 1}
                    opacity={isActive ? 0.8 : 0.4}
                  />
                  {/* Animated data packet */}
                  {a.status !== 'offline' && b.status !== 'offline' && (
                    <motion.circle
                      r={2}
                      fill={isActive ? '#60a5fa' : '#94a3b8'}
                      opacity={0.6}
                      animate={{
                        cx: [ax, bx, ax],
                        cy: [ay, by, ay],
                      }}
                      transition={{
                        duration: 3 + Math.random() * 2,
                        repeat: Infinity,
                        ease: 'linear',
                        delay: Math.random() * 2,
                      }}
                    />
                  )}
                </g>
              );
            })}

            {/* Nodes */}
            {nodes.map(node => {
              const c = NODE_COLORS[node.status];
              const size = TYPE_SIZE[node.type];
              const x = scaleX(node.position.x);
              const y = scaleY(node.position.y);
              const isSelected = selectedNodeId === node.id;
              const isHovered = hoveredId === node.id;

              return (
                <g
                  key={node.id}
                  onClick={() => handleNodeClick(node.id)}
                  onMouseEnter={() => setHoveredId(node.id)}
                  onMouseLeave={() => setHoveredId(null)}
                  style={{ cursor: 'pointer' }}
                >
                  {/* Glow pulse for critical */}
                  {node.status === 'critical' && (
                    <motion.circle
                      cx={x} cy={y} r={size + 8}
                      fill="none" stroke="#ef4444"
                      strokeWidth="2"
                      animate={{ opacity: [0.8, 0, 0.8], r: [size + 8, size + 20, size + 8] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    />
                  )}

                  {/* Selection ring */}
                  {(isSelected || isHovered) && (
                    <motion.circle
                      cx={x} cy={y} r={size + 5}
                      fill="none" stroke="#60a5fa"
                      strokeWidth="2"
                      initial={{ opacity: 0, r: size }}
                      animate={{ opacity: 0.8, r: size + 5 }}
                    />
                  )}

                  {/* Node circle */}
                  <motion.circle
                    cx={x} cy={y} r={size}
                    fill={c.fill}
                    stroke={c.stroke}
                    strokeWidth="2"
                    filter={node.status !== 'offline' ? `url(#glow-${node.id})` : undefined}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    whileHover={{ scale: 1.1 }}
                    transition={{ type: 'spring', stiffness: 200 }}
                  />

                  {/* Node icon */}
                  <text
                    x={x} y={y + 1}
                    textAnchor="middle"
                    dominantBaseline="middle"
                    fontSize={size * 0.7}
                    style={{ pointerEvents: 'none', userSelect: 'none' }}
                  >
                    {TYPE_ICON[node.type]}
                  </text>

                  {/* Node label */}
                  <text
                    x={x} y={y + size + 12}
                    textAnchor="middle"
                    fontSize="9"
                    fill={c.stroke}
                    fontFamily="JetBrains Mono, monospace"
                    fontWeight="600"
                    style={{ pointerEvents: 'none', userSelect: 'none' }}
                  >
                    {node.name.length > 12 ? node.name.slice(0, 10) + '…' : node.name}
                  </text>

                  {/* Latency label */}
                  {node.status !== 'offline' && (
                    <text
                      x={x} y={y + size + 22}
                      textAnchor="middle"
                      fontSize="8"
                      fill="#64748b"
                      fontFamily="JetBrains Mono, monospace"
                      style={{ pointerEvents: 'none', userSelect: 'none' }}
                    >
                      {node.currentMetrics.latency.toFixed(0)}ms
                    </text>
                  )}

                  {/* Fault indicator */}
                  {node.faults.length > 0 && (
                    <motion.text
                      x={x + size - 4} y={y - size + 4}
                      textAnchor="middle"
                      fontSize="12"
                      animate={{ opacity: [1, 0.3, 1] }}
                      transition={{ duration: 0.8, repeat: Infinity }}
                      style={{ pointerEvents: 'none', userSelect: 'none' }}
                    >
                      ⚠️
                    </motion.text>
                  )}
                </g>
              );
            })}
          </svg>
        </div>
      </div>

      {/* Node Detail Panel */}
      <AnimatePresence>
        {selectedNode && (
          <motion.div
            initial={{ opacity: 0, x: 20, width: 0 }}
            animate={{ opacity: 1, x: 0, width: 280 }}
            exit={{ opacity: 0, x: 20, width: 0 }}
            className="rounded-2xl border border-slate-700/60 bg-slate-900/80 backdrop-blur-md overflow-hidden flex-shrink-0"
            style={{ minWidth: 260 }}
          >
            <div className="px-4 py-3 border-b border-slate-700/50 flex items-center justify-between">
              <h3 className="text-sm font-semibold font-mono text-slate-200 uppercase">{selectedNode.name}</h3>
              <button onClick={() => setSelectedNode(null)} className="text-slate-500 hover:text-white text-sm">✕</button>
            </div>
            <div className="p-4 space-y-3">
              <div className="flex items-center justify-between">
                <StatusBadge status={selectedNode.status} pulse />
                <span className="text-xs text-slate-500 font-mono">{selectedNode.type.toUpperCase()}</span>
              </div>

              <div className="text-xs font-mono space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">IP</span>
                  <span className="text-slate-300">{selectedNode.ip}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Region</span>
                  <span className="text-slate-300">{selectedNode.region}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Uptime</span>
                  <span className="text-slate-300">{Math.floor(selectedNode.uptime / 3600)}h {Math.floor((selectedNode.uptime % 3600) / 60)}m</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Connections</span>
                  <span className="text-slate-300">{selectedNode.connections.length}</span>
                </div>
              </div>

              <div className="border-t border-slate-700/50 pt-3">
                <p className="text-xs font-mono text-slate-400 mb-2 uppercase">Live Metrics</p>
                <div className="space-y-2">
                  {[
                    { label: 'Latency', value: `${selectedNode.currentMetrics.latency.toFixed(1)} ms`, bad: selectedNode.currentMetrics.latency > 200 },
                    { label: 'Packet Loss', value: `${selectedNode.currentMetrics.packetLoss.toFixed(2)} %`, bad: selectedNode.currentMetrics.packetLoss > 10 },
                    { label: 'Throughput', value: `${selectedNode.currentMetrics.throughput.toFixed(1)} Mbps`, bad: false },
                    { label: 'Jitter', value: `${selectedNode.currentMetrics.jitter.toFixed(1)} ms`, bad: selectedNode.currentMetrics.jitter > 30 },
                    { label: 'CPU', value: `${selectedNode.currentMetrics.cpuUsage.toFixed(1)} %`, bad: selectedNode.currentMetrics.cpuUsage > 80 },
                    { label: 'Memory', value: `${selectedNode.currentMetrics.memoryUsage.toFixed(1)} %`, bad: selectedNode.currentMetrics.memoryUsage > 85 },
                  ].map(item => (
                    <div key={item.label} className="flex justify-between text-xs font-mono">
                      <span className="text-slate-500">{item.label}</span>
                      <span className={item.bad ? 'text-red-400' : 'text-slate-300'}>{item.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {selectedNode.faults.length > 0 && (
                <div className="border-t border-slate-700/50 pt-3">
                  <p className="text-xs font-mono text-red-400 mb-2 uppercase">Active Faults</p>
                  {selectedNode.faults.map(f => (
                    <div key={f.id} className="text-xs font-mono text-red-400 flex items-start gap-1 mb-1">
                      <span>⚠</span>
                      <span className="text-slate-400 break-words">{f.faultType}: <span className="text-slate-500">{f.description.slice(0, 60)}...</span></span>
                    </div>
                  ))}
                </div>
              )}

              <div className="border-t border-slate-700/50 pt-3 space-y-2">
                <p className="text-xs font-mono text-slate-400 uppercase">Actions</p>
                <button
                  onClick={() => recoverNode(selectedNode.id)}
                  className="w-full text-xs py-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 font-mono transition-colors"
                >
                  ✓ Force Recovery
                </button>
                <div className="grid grid-cols-2 gap-1">
                  {(['HIGH_LATENCY', 'PACKET_LOSS', 'NODE_FAILURE', 'CONGESTION'] as const).map(ft => (
                    <button
                      key={ft}
                      onClick={() => forceNodeFault(selectedNode.id, ft)}
                      className="text-xs py-1 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 font-mono transition-colors"
                    >
                      {ft.replace('_', '\n')}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
