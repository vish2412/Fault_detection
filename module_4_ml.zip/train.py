"""
ml_model/train.py
=================
Dataset generation + RandomForestClassifier training pipeline.

Usage
-----
# Basic — synthetic data only:
    python train.py

# Include real metric logs from the running SQLite database:
    python train.py --use-db-logs --db-path ../server/network_monitor.db

# Full options:
    python train.py \
        --use-db-logs \
        --db-path ../server/network_monitor.db \
        --samples-per-class 1500 \
        --n-estimators 200 \
        --output-dir ./models \
        --no-scaler

Output
------
  models/fault_classifier.pkl   — trained RandomForestClassifier
  models/scaler.pkl             — fitted StandardScaler (omitted with --no-scaler)
  models/training_report.json   — accuracy metrics and confusion matrix
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import warnings
from datetime import datetime
from pathlib import Path
from typing import Optional

import joblib
import numpy as np

warnings.filterwarnings("ignore")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants — fault classes and feature columns
# ---------------------------------------------------------------------------

FAULT_CLASSES = [
    "NORMAL",
    "HIGH_LATENCY",
    "PACKET_LOSS",
    "THROUGHPUT_DEGRADATION",
    "NETWORK_CONGESTION",
    "DATA_CORRUPTION",
    "NODE_FAILURE",
]

FEATURE_COLUMNS = ["latency_ms", "packet_loss_rate", "throughput_mbps", "jitter_ms"]

# Label index mapping (must match ml_inference.py LABEL_MAP)
CLASS_TO_IDX = {cls: i for i, cls in enumerate(FAULT_CLASSES)}
IDX_TO_CLASS = {i: cls for cls, i in CLASS_TO_IDX.items()}


# ---------------------------------------------------------------------------
# Synthetic dataset generation
# ---------------------------------------------------------------------------


def _rng(seed: Optional[int] = None) -> np.random.Generator:
    return np.random.default_rng(seed)


def generate_normal_samples(n: int, rng: np.random.Generator) -> np.ndarray:
    """
    Healthy network traffic.
      latency_ms        :  1 –  50 ms   (log-normal, mean ~15)
      packet_loss_rate  :  0 – 0.01     (near-zero)
      throughput_mbps   : 10 – 1000     (high, log-normal, mean ~200)
      jitter_ms         :  0 –  10 ms   (low)
    """
    latency = rng.lognormal(mean=2.5, sigma=0.6, size=n).clip(1, 50)
    loss = rng.beta(a=0.5, b=50, size=n).clip(0, 0.01)
    throughput = rng.lognormal(mean=5.0, sigma=0.8, size=n).clip(10, 1000)
    jitter = rng.lognormal(mean=1.0, sigma=0.6, size=n).clip(0, 10)
    return np.column_stack([latency, loss, throughput, jitter])


def generate_high_latency_samples(n: int, rng: np.random.Generator) -> np.ndarray:
    """
    High latency fault.
      latency_ms        : 200 – 2000 ms  (well above 200 ms threshold)
      packet_loss_rate  :   0 –  0.04    (mild loss sometimes accompanies latency)
      throughput_mbps   :   5 – 200      (degraded but not zero)
      jitter_ms         :   5 –  80 ms   (elevated)
    """
    latency = rng.uniform(200, 2000, size=n) + rng.exponential(100, size=n)
    latency = latency.clip(200, 3000)
    loss = rng.beta(a=1, b=30, size=n).clip(0, 0.04)
    throughput = rng.lognormal(mean=3.5, sigma=0.9, size=n).clip(5, 200)
    jitter = rng.uniform(5, 80, size=n)
    return np.column_stack([latency, loss, throughput, jitter])


def generate_packet_loss_samples(n: int, rng: np.random.Generator) -> np.ndarray:
    """
    Packet loss fault.
      latency_ms        :  10 – 300 ms   (can be moderate)
      packet_loss_rate  :   0.05 – 0.60  (clearly above 5% threshold)
      throughput_mbps   :   0.5 – 50     (degraded due to retransmissions)
      jitter_ms         :   2 – 60 ms    (variable)
    """
    latency = rng.lognormal(mean=3.5, sigma=0.8, size=n).clip(10, 300)
    loss = rng.uniform(0.05, 0.60, size=n) + rng.exponential(0.05, size=n)
    loss = loss.clip(0.05, 0.95)
    throughput = rng.lognormal(mean=2.0, sigma=0.9, size=n).clip(0.5, 50)
    jitter = rng.uniform(2, 60, size=n)
    return np.column_stack([latency, loss, throughput, jitter])


def generate_throughput_degradation_samples(n: int, rng: np.random.Generator) -> np.ndarray:
    """
    Throughput degradation fault.
      latency_ms        :   5 – 150 ms   (might be normal)
      packet_loss_rate  :   0 –  0.03    (slight loss)
      throughput_mbps   :   0 –  0.99    (below 1 Mbps threshold)
      jitter_ms         :   1 –  30 ms   (moderate)
    """
    latency = rng.lognormal(mean=2.8, sigma=0.8, size=n).clip(5, 150)
    loss = rng.beta(a=0.8, b=40, size=n).clip(0, 0.03)
    throughput = rng.uniform(0.01, 0.99, size=n)
    jitter = rng.uniform(1, 30, size=n)
    return np.column_stack([latency, loss, throughput, jitter])


def generate_network_congestion_samples(n: int, rng: np.random.Generator) -> np.ndarray:
    """
    Network congestion — sustained multi-metric degradation.
      latency_ms        : 150 – 800 ms   (high)
      packet_loss_rate  :   0.03 – 0.25  (elevated)
      throughput_mbps   :   0.1 –  5     (very low)
      jitter_ms         :  20 – 150 ms   (very high)
    """
    latency = rng.uniform(150, 800, size=n) + rng.exponential(50, size=n)
    latency = latency.clip(150, 1500)
    loss = rng.uniform(0.03, 0.25, size=n)
    throughput = rng.uniform(0.1, 5.0, size=n)
    jitter = rng.uniform(20, 150, size=n)
    return np.column_stack([latency, loss, throughput, jitter])


def generate_data_corruption_samples(n: int, rng: np.random.Generator) -> np.ndarray:
    """
    Data corruption — metrics look largely normal but with irregular spikes.
      latency_ms        :   5 – 400 ms   (wide spread, occasional spike)
      packet_loss_rate  :   0 – 0.15     (irregular)
      throughput_mbps   :   1 – 500      (variable)
      jitter_ms         :   0 – 100 ms   (high variance)
    """
    # Base: mostly normal-looking
    latency = rng.lognormal(mean=2.5, sigma=1.2, size=n).clip(5, 400)
    loss = rng.beta(a=1.5, b=20, size=n).clip(0, 0.15)
    throughput = rng.lognormal(mean=4.0, sigma=1.2, size=n).clip(1, 500)
    jitter = rng.uniform(0, 100, size=n)
    return np.column_stack([latency, loss, throughput, jitter])


def generate_node_failure_samples(n: int, rng: np.random.Generator) -> np.ndarray:
    """
    Node failure — node is down; metrics reflect unreachability.
      latency_ms        : 500 – 10000 ms  (extreme / timeout-level)
      packet_loss_rate  :   0.80 – 1.0    (near-total loss)
      throughput_mbps   :   0 –  0.10     (essentially zero)
      jitter_ms         : 100 – 500 ms    (extreme / meaningless)
    """
    latency = rng.uniform(500, 10000, size=n)
    loss = rng.uniform(0.80, 1.0, size=n)
    throughput = rng.uniform(0.0, 0.10, size=n)
    jitter = rng.uniform(100, 500, size=n)
    return np.column_stack([latency, loss, throughput, jitter])


# Map each class name to its generator function
GENERATORS = {
    "NORMAL": generate_normal_samples,
    "HIGH_LATENCY": generate_high_latency_samples,
    "PACKET_LOSS": generate_packet_loss_samples,
    "THROUGHPUT_DEGRADATION": generate_throughput_degradation_samples,
    "NETWORK_CONGESTION": generate_network_congestion_samples,
    "DATA_CORRUPTION": generate_data_corruption_samples,
    "NODE_FAILURE": generate_node_failure_samples,
}


def build_synthetic_dataset(
    samples_per_class: int = 1000,
    seed: int = 42,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Generate a balanced synthetic training dataset.

    Returns
    -------
    X : ndarray of shape (n_samples, 4)
        Feature matrix [latency_ms, packet_loss_rate, throughput_mbps, jitter_ms].
    y : ndarray of shape (n_samples,)
        Integer class labels.
    """
    rng = _rng(seed)
    X_parts, y_parts = [], []

    for class_name, generator in GENERATORS.items():
        label = CLASS_TO_IDX[class_name]
        samples = generator(samples_per_class, rng)
        X_parts.append(samples)
        y_parts.append(np.full(samples_per_class, label, dtype=int))
        logger.info("  Generated %d synthetic samples for class '%s'", samples_per_class, class_name)

    X = np.vstack(X_parts)
    y = np.concatenate(y_parts)

    # Shuffle
    shuffle_idx = rng.permutation(len(X))
    return X[shuffle_idx], y[shuffle_idx]


# ---------------------------------------------------------------------------
# Real database log ingestion
# ---------------------------------------------------------------------------


def load_db_logs(db_path: str) -> tuple[np.ndarray, np.ndarray]:
    """
    Load real metric logs from the SQLite database produced by the running system.

    Rows in ``metric_logs`` that have an associated ``fault_events`` entry within
    ±10 seconds are labelled with that fault type.  All other rows are labelled
    ``NORMAL``.

    Parameters
    ----------
    db_path : str
        Path to the ``network_monitor.db`` SQLite file.

    Returns
    -------
    X : ndarray of shape (n_rows, 4) — may be empty
    y : ndarray of shape (n_rows,)   — may be empty
    """
    try:
        import sqlite3
    except ImportError:
        logger.warning("sqlite3 not available; skipping DB log ingestion.")
        return np.empty((0, 4)), np.empty(0, dtype=int)

    if not os.path.exists(db_path):
        logger.warning("Database not found at '%s'; skipping DB log ingestion.", db_path)
        return np.empty((0, 4)), np.empty(0, dtype=int)

    logger.info("Loading real metric logs from '%s' …", db_path)

    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        # Load all metric log rows
        cursor.execute(
            """
            SELECT
                m.id,
                m.node_id,
                m.latency_ms,
                m.packet_loss_rate,
                m.throughput_mbps,
                m.jitter_ms,
                m.recorded_at
            FROM metric_logs m
            ORDER BY m.recorded_at ASC
            """
        )
        metric_rows = cursor.fetchall()

        if not metric_rows:
            logger.info("No metric log rows found in database.")
            conn.close()
            return np.empty((0, 4)), np.empty(0, dtype=int)

        # Load fault events to use as labels
        cursor.execute(
            """
            SELECT node_id, fault_type, detected_at
            FROM fault_events
            ORDER BY detected_at ASC
            """
        )
        fault_rows = cursor.fetchall()
        conn.close()

        # Build a lookup: (node_id, approx_second) → fault_type
        fault_lookup: dict[tuple[str, str], str] = {}
        for f in fault_rows:
            # Truncate to the nearest second for loose matching
            ts_trunc = str(f["detected_at"])[:19]
            fault_lookup[(f["node_id"], ts_trunc)] = f["fault_type"]

        X_list, y_list = [], []
        labelled_counts: dict[str, int] = {c: 0 for c in FAULT_CLASSES}

        for row in metric_rows:
            features = [
                float(row["latency_ms"] or 0.0),
                float(row["packet_loss_rate"] or 0.0),
                float(row["throughput_mbps"] or 0.0),
                float(row["jitter_ms"] or 0.0),
            ]

            # Look for a fault event within ±10 seconds of this metric sample
            ts_trunc = str(row["recorded_at"])[:19]
            fault_type = fault_lookup.get((row["node_id"], ts_trunc), "NORMAL")

            # Normalise fault type string
            fault_type = fault_type.upper().replace(" ", "_")
            if fault_type not in CLASS_TO_IDX:
                fault_type = "NORMAL"

            X_list.append(features)
            y_list.append(CLASS_TO_IDX[fault_type])
            labelled_counts[fault_type] += 1

        X_real = np.array(X_list, dtype=float)
        y_real = np.array(y_list, dtype=int)

        logger.info(
            "Loaded %d real samples from DB. Label distribution: %s",
            len(X_real),
            {k: v for k, v in labelled_counts.items() if v > 0},
        )
        return X_real, y_real

    except Exception as exc:
        logger.error("Failed to load DB logs: %s", exc)
        return np.empty((0, 4)), np.empty(0, dtype=int)


# ---------------------------------------------------------------------------
# Training
# ---------------------------------------------------------------------------


def train(
    samples_per_class: int = 1000,
    n_estimators: int = 200,
    use_db_logs: bool = False,
    db_path: str = "../server/network_monitor.db",
    use_scaler: bool = True,
    output_dir: str = "./models",
    seed: int = 42,
) -> dict:
    """
    Full training pipeline.

    1. Generate synthetic dataset.
    2. Optionally merge real DB logs (weighted 3× for real data).
    3. Fit StandardScaler (optional).
    4. Train RandomForestClassifier.
    5. Evaluate on held-out test split.
    6. Save model artefacts to ``output_dir``.
    7. Return a training report dict.
    """
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import train_test_split, cross_val_score
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import (
        classification_report,
        confusion_matrix,
        accuracy_score,
    )

    Path(output_dir).mkdir(parents=True, exist_ok=True)

    logger.info("=" * 60)
    logger.info("AI Network Fault Detection — Model Training")
    logger.info("=" * 60)

    # ------------------------------------------------------------------
    # 1. Synthetic data
    # ------------------------------------------------------------------
    logger.info("Generating synthetic training data (%d samples/class) …", samples_per_class)
    X_syn, y_syn = build_synthetic_dataset(samples_per_class=samples_per_class, seed=seed)
    logger.info("Synthetic dataset: %d rows × %d features", *X_syn.shape)

    X_all, y_all = X_syn, y_syn
    sample_weights = np.ones(len(X_syn))

    # ------------------------------------------------------------------
    # 2. Real DB logs
    # ------------------------------------------------------------------
    if use_db_logs:
        X_real, y_real = load_db_logs(db_path)
        if len(X_real) > 0:
            # Weight real samples 3× so the model prefers them
            real_weights = np.full(len(X_real), 3.0)
            X_all = np.vstack([X_syn, X_real])
            y_all = np.concatenate([y_syn, y_real])
            sample_weights = np.concatenate([sample_weights, real_weights])
            logger.info(
                "Combined dataset: %d synthetic + %d real = %d total rows",
                len(X_syn),
                len(X_real),
                len(X_all),
            )

    # ------------------------------------------------------------------
    # 3. Train / test split
    # ------------------------------------------------------------------
    X_train, X_test, y_train, y_test, w_train, _ = train_test_split(
        X_all,
        y_all,
        sample_weights,
        test_size=0.20,
        random_state=seed,
        stratify=y_all,
    )
    logger.info("Train: %d rows | Test: %d rows", len(X_train), len(X_test))

    # ------------------------------------------------------------------
    # 4. Scaling
    # ------------------------------------------------------------------
    scaler: Optional[StandardScaler] = None
    if use_scaler:
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        logger.info("StandardScaler fitted.")
    else:
        X_train_scaled = X_train
        X_test_scaled = X_test

    # ------------------------------------------------------------------
    # 5. Model training
    # ------------------------------------------------------------------
    logger.info("Training RandomForestClassifier (n_estimators=%d) …", n_estimators)
    clf = RandomForestClassifier(
        n_estimators=n_estimators,
        max_depth=None,
        min_samples_split=4,
        min_samples_leaf=2,
        max_features="sqrt",
        class_weight="balanced",
        n_jobs=-1,
        random_state=seed,
        oob_score=True,
    )
    clf.fit(X_train_scaled, y_train, sample_weight=w_train)
    logger.info("OOB score: %.4f", clf.oob_score_)

    # ------------------------------------------------------------------
    # 6. Evaluation
    # ------------------------------------------------------------------
    y_pred = clf.predict(X_test_scaled)
    accuracy = accuracy_score(y_test, y_pred)

    report_str = classification_report(
        y_test,
        y_pred,
        target_names=FAULT_CLASSES,
        zero_division=0,
    )
    cm = confusion_matrix(y_test, y_pred).tolist()

    logger.info("Test accuracy: %.4f", accuracy)
    logger.info("Classification report:\n%s", report_str)

    # Cross-val on the training set for variance estimate
    cv_scores = cross_val_score(clf, X_train_scaled, y_train, cv=5, n_jobs=-1)
    logger.info(
        "5-fold CV accuracy: %.4f ± %.4f",
        cv_scores.mean(),
        cv_scores.std(),
    )

    # Feature importances
    importances = {
        col: round(float(imp), 6)
        for col, imp in zip(FEATURE_COLUMNS, clf.feature_importances_)
    }
    logger.info("Feature importances: %s", importances)

    # ------------------------------------------------------------------
    # 7. Save artefacts
    # ------------------------------------------------------------------
    model_path = os.path.join(output_dir, "fault_classifier.pkl")
    joblib.dump(clf, model_path, compress=3)
    logger.info("Model saved → %s", model_path)

    scaler_path = os.path.join(output_dir, "scaler.pkl")
    if scaler is not None:
        joblib.dump(scaler, scaler_path, compress=3)
        logger.info("Scaler saved → %s", scaler_path)
    elif os.path.exists(scaler_path):
        os.remove(scaler_path)

    # ------------------------------------------------------------------
    # 8. Training report
    # ------------------------------------------------------------------
    report = {
        "trained_at": datetime.utcnow().isoformat(),
        "samples_per_class": samples_per_class,
        "n_estimators": n_estimators,
        "use_scaler": use_scaler,
        "oob_score": round(clf.oob_score_, 6),
        "test_accuracy": round(accuracy, 6),
        "cv_mean": round(float(cv_scores.mean()), 6),
        "cv_std": round(float(cv_scores.std()), 6),
        "confusion_matrix": cm,
        "class_names": FAULT_CLASSES,
        "feature_importances": importances,
        "training_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "real_db_rows_used": int(len(X_real)) if use_db_logs and "X_real" in dir() else 0,
        "model_path": model_path,
        "scaler_path": scaler_path if scaler is not None else None,
    }

    report_path = os.path.join(output_dir, "training_report.json")
    with open(report_path, "w") as fh:
        json.dump(report, fh, indent=2)
    logger.info("Training report saved → %s", report_path)

    logger.info("=" * 60)
    logger.info("Training complete.  Test accuracy: %.2f%%", accuracy * 100)
    logger.info("=" * 60)

    return report


# ---------------------------------------------------------------------------
# CLI entry-point
# ---------------------------------------------------------------------------


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Train the AI network fault detection classifier.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument(
        "--samples-per-class",
        type=int,
        default=1000,
        metavar="N",
        help="Number of synthetic samples to generate per fault class.",
    )
    p.add_argument(
        "--n-estimators",
        type=int,
        default=200,
        metavar="N",
        help="Number of trees in the RandomForest.",
    )
    p.add_argument(
        "--use-db-logs",
        action="store_true",
        default=False,
        help="Merge real metric logs from the SQLite database into training data.",
    )
    p.add_argument(
        "--db-path",
        type=str,
        default="../server/network_monitor.db",
        metavar="PATH",
        help="Path to the network_monitor.db SQLite file (used with --use-db-logs).",
    )
    p.add_argument(
        "--no-scaler",
        action="store_true",
        default=False,
        help="Skip StandardScaler fitting (not recommended).",
    )
    p.add_argument(
        "--output-dir",
        type=str,
        default="./models",
        metavar="DIR",
        help="Directory to write model artefacts.",
    )
    p.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for reproducibility.",
    )
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()

    try:
        report = train(
            samples_per_class=args.samples_per_class,
            n_estimators=args.n_estimators,
            use_db_logs=args.use_db_logs,
            db_path=args.db_path,
            use_scaler=not args.no_scaler,
            output_dir=args.output_dir,
            seed=args.seed,
        )
        sys.exit(0)
    except ImportError as exc:
        logger.error(
            "Missing dependency: %s\n"
            "Install with: pip install -r ml_model/requirements.txt",
            exc,
        )
        sys.exit(1)
    except Exception as exc:
        logger.exception("Training failed: %s", exc)
        sys.exit(2)
