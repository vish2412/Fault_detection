import { motion, AnimatePresence } from 'framer-motion';
import { useSimulationStore } from '../../store/simulationStore';
import { useMemo } from 'react';
import { format } from 'date-fns';

const LEVEL_COLORS = {
  INFO:  'text-blue-400',
  WARN:  'text-amber-400',
  ERROR: 'text-red-400',
  DEBUG: 'text-slate-500',
};

const LEVEL_BG = {
  INFO:  'bg-blue-500/10',
  WARN:  'bg-amber-500/10',
  ERROR: 'bg-red-500/15',
  DEBUG: 'bg-slate-500/10',
};

const CATEGORY_COLORS: Record<string, string> = {
  heartbeat:     'text-emerald-400',
  fault:         'text-red-400',
  recovery:      'text-emerald-300',
  file_transfer: 'text-blue-400',
  ml_detection:  'text-violet-400',
  system:        'text-slate-400',
};

export function LogPanel() {
  const { logs, logFilter, setLogFilter, exportLogs } = useSimulationStore();

  const filtered = useMemo(() =>
    logs.filter(l => logFilter === 'ALL' || l.level === logFilter).slice(0, 200),
    [logs, logFilter]
  );

  return (
    <div className="rounded-2xl border border-slate-700/60 bg-slate-900/70 backdrop-blur-md">
      {/* Header */}
      <div className="px-5 py-3 border-b border-slate-700/50 flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <span className="text-slate-400">📜</span>
          <h3 className="text-sm font-semibold text-slate-200 font-mono uppercase tracking-wide">System Logs</h3>
          <span className="text-xs text-slate-500 font-mono">({logs.length} entries)</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex gap-1 bg-slate-800/60 rounded-lg p-1">
            {(['ALL', 'INFO', 'WARN', 'ERROR', 'DEBUG'] as const).map(f => (
              <button
                key={f}
                onClick={() => setLogFilter(f)}
                className={`text-xs px-2 py-1 rounded font-mono transition-colors ${
                  logFilter === f
                    ? f === 'ERROR' ? 'bg-red-500/30 text-red-300' :
                      f === 'WARN' ? 'bg-amber-500/30 text-amber-300' :
                      f === 'INFO' ? 'bg-blue-500/30 text-blue-300' :
                      'bg-slate-600 text-slate-300'
                    : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
          <button
            onClick={exportLogs}
            className="text-xs px-3 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 font-mono transition-colors flex items-center gap-1"
          >
            ⬇ Export CSV
          </button>
        </div>
      </div>

      {/* Log entries */}
      <div className="p-2 overflow-y-auto max-h-[600px] custom-scrollbar space-y-0.5">
        <AnimatePresence mode="popLayout" initial={false}>
          {filtered.map(log => (
            <motion.div
              key={log.id}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2 }}
              className={`flex items-start gap-2 px-3 py-1.5 rounded-lg font-mono text-xs hover:bg-slate-800/40 transition-colors ${LEVEL_BG[log.level]}`}
            >
              {/* Timestamp */}
              <span className="text-slate-600 flex-shrink-0 w-[140px]">
                {format(log.timestamp, 'HH:mm:ss.SSS')}
              </span>

              {/* Level */}
              <span className={`flex-shrink-0 w-10 font-bold ${LEVEL_COLORS[log.level]}`}>
                {log.level}
              </span>

              {/* Node */}
              <span className="flex-shrink-0 w-[120px] text-slate-400 truncate">
                [{log.nodeName}]
              </span>

              {/* Category */}
              <span className={`flex-shrink-0 w-[110px] ${CATEGORY_COLORS[log.category] || 'text-slate-500'}`}>
                {log.category}
              </span>

              {/* Message */}
              <span className={`flex-1 break-all ${LEVEL_COLORS[log.level] === 'text-red-400' ? 'text-red-300' : 'text-slate-400'}`}>
                {log.message}
              </span>
            </motion.div>
          ))}
        </AnimatePresence>

        {filtered.length === 0 && (
          <div className="text-center py-12 text-slate-600 font-mono text-sm">
            No logs matching filter "{logFilter}"
          </div>
        )}
      </div>
    </div>
  );
}
