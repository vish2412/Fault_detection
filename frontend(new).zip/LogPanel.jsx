// src/components/LogPanel.jsx
import React, { useEffect, useRef } from 'react'

const LEVEL_STYLE = {
  success: 'text-cyber-green',
  error:   'text-cyber-red',
  warn:    'text-cyber-amber',
  info:    'text-cyber-cyan',
}

function shortTs(isoStr) {
  if (!isoStr) return ''
  const d = new Date(isoStr)
  return d.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })
}

export default function LogPanel({ logFeed }) {
  const bottomRef = useRef(null)

  // Auto-scroll to latest entry when feed grows
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [logFeed.length])

  return (
    <div className="panel h-full flex flex-col">
      <div className="panel-header justify-between">
        <div className="flex items-center gap-2">
          <span className="dot dot-green animate-pulse-slow" />
          EVENT LOG
          <span className="cursor" />
        </div>
        <span className="text-[9px] text-cyber-muted font-mono">
          {logFeed.length} entries
        </span>
      </div>

      <div className="flex-1 overflow-y-auto p-2 font-mono">
        {logFeed.length === 0 ? (
          <div className="text-cyber-muted text-[10px] p-2">
            Waiting for events...
          </div>
        ) : (
          <div className="space-y-0.5">
            {[...logFeed].reverse().map((entry, i) => (
              <div
                key={i}
                className="flex gap-2 text-[10px] leading-relaxed animate-slidein hover:bg-cyber-border/20 px-1 rounded"
              >
                <span className="text-cyber-muted shrink-0 select-none">
                  {shortTs(entry.ts)}
                </span>
                <span className={`${LEVEL_STYLE[entry.level] || 'text-cyber-text'} break-all`}>
                  {entry.text}
                </span>
              </div>
            ))}
            <div ref={bottomRef} />
          </div>
        )}
      </div>
    </div>
  )
}
