/**
 * useWebSocket.js
 * ---------------
 * Manages a single WebSocket connection to the backend dashboard endpoint.
 *
 * Features:
 *  - Automatic JSON parsing of incoming messages
 *  - Exponential-backoff reconnection (capped at MAX_DELAY)
 *  - Connection state tracking: "connecting" | "connected" | "disconnected" | "error"
 *  - Stable onMessage callback via ref (no re-subscription on parent re-renders)
 *  - Cleanup on unmount
 */

import { useEffect, useRef, useState, useCallback } from "react";
import CONFIG from "../config.js";

export const WS_STATES = {
  CONNECTING:   "connecting",
  CONNECTED:    "connected",
  DISCONNECTED: "disconnected",
  ERROR:        "error",
};

export function useWebSocket(url, onMessage) {
  const [connectionState, setConnectionState] = useState(WS_STATES.CONNECTING);
  const [reconnectCount,  setReconnectCount]  = useState(0);

  const wsRef           = useRef(null);
  const onMessageRef    = useRef(onMessage);
  const reconnectTimer  = useRef(null);
  const reconnectDelay  = useRef(CONFIG.RECONNECT_DELAY_MS);
  const unmountedRef    = useRef(false);

  // Keep callback ref fresh without causing reconnects
  useEffect(() => {
    onMessageRef.current = onMessage;
  }, [onMessage]);

  const connect = useCallback(() => {
    if (unmountedRef.current) return;

    // Close any existing socket cleanly
    if (wsRef.current) {
      wsRef.current.onclose = null;
      wsRef.current.onerror = null;
      wsRef.current.close();
      wsRef.current = null;
    }

    setConnectionState(WS_STATES.CONNECTING);

    let ws;
    try {
      ws = new WebSocket(url);
    } catch (err) {
      console.error("[WS] Failed to construct WebSocket:", err);
      setConnectionState(WS_STATES.ERROR);
      scheduleReconnect();
      return;
    }

    wsRef.current = ws;

    ws.onopen = () => {
      if (unmountedRef.current) return;
      console.info("[WS] Connected to", url);
      setConnectionState(WS_STATES.CONNECTED);
      setReconnectCount(0);
      reconnectDelay.current = CONFIG.RECONNECT_DELAY_MS; // reset backoff
    };

    ws.onmessage = (event) => {
      if (unmountedRef.current) return;
      try {
        const msg = JSON.parse(event.data);
        onMessageRef.current?.(msg);
      } catch (err) {
        console.warn("[WS] Failed to parse message:", event.data, err);
      }
    };

    ws.onerror = (event) => {
      if (unmountedRef.current) return;
      console.warn("[WS] Socket error:", event);
      setConnectionState(WS_STATES.ERROR);
    };

    ws.onclose = (event) => {
      if (unmountedRef.current) return;
      console.info(`[WS] Closed (code=${event.code}, clean=${event.wasClean})`);
      setConnectionState(WS_STATES.DISCONNECTED);
      wsRef.current = null;
      scheduleReconnect();
    };
  }, [url]);

  const scheduleReconnect = useCallback(() => {
    if (unmountedRef.current) return;
    if (reconnectTimer.current) return; // already scheduled

    const delay = reconnectDelay.current;
    console.info(`[WS] Reconnecting in ${delay}ms…`);

    reconnectTimer.current = setTimeout(() => {
      reconnectTimer.current = null;
      if (!unmountedRef.current) {
        // Exponential backoff: double up to max
        reconnectDelay.current = Math.min(
          reconnectDelay.current * 1.5,
          CONFIG.RECONNECT_MAX_DELAY_MS
        );
        setReconnectCount((c) => c + 1);
        connect();
      }
    }, delay);
  }, [connect]);

  // Initial connection
  useEffect(() => {
    unmountedRef.current = false;
    connect();

    return () => {
      unmountedRef.current = true;
      if (reconnectTimer.current) {
        clearTimeout(reconnectTimer.current);
        reconnectTimer.current = null;
      }
      if (wsRef.current) {
        wsRef.current.onclose = null;
        wsRef.current.onerror = null;
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [connect]);

  return { connectionState, reconnectCount };
}
