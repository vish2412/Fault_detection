// src/components/AlertFeed.jsx
import React, { useState } from 'react'

const SEVERITY_ORDER = { CRITICAL: 0, MEDIUM: 1, LOW: 2 }

const FAULT_ICONS = {
  NODE_FAILURE:           '💀',
  HIGH_LATENCY:           '⏱',
  PACKET_LOSS:            '📉',
  THROUGHPUT_DEGRADATION: '🐢',
  NETWORK_CONGESTION:     '🔴',
  DATA_CORRUPTION:        '☠',
  NORMAL:                 '✅',
}

function timeLabel(isoStr) {
  if (!isoStr) return ''
  const d = new Date(isoStr)
  return d.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })
}

function AlertRow({ alert }) {
  const [expanded, setExpanded] = useState(false)
  const sev = alert.severity?.toUpperCase()
  const badgeClass =
    sev === 'CRITICAL' ? 'badge-critical' :
    sev === 'MEDIUM'   ? 'badge-medium'   : 'badge-low'

  const borderColor =
    sev === 'CRITICAL' ? 'border-l-cyber-red' :
    sev === 'MEDIUM'   ? 'border-l-cyber-amber' : 'border-l-cyber-green'

  return (
    <div
      className={`panel border-l-2 ${borderColor} animate-slidein cursor-pointer select-none`}
      onClick={() => setExpanded(e => !e)}
    >
      <div className="flex items-start gap-2 px-3 py-2">
        <span className="text-base leading-none mt-0.5">
          {FAULT_ICONS[alert.fault_type] || '⚡'}
        </span>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className={`badge ${badgeClass}`}>{sev}</span>
            <span className="text-[11px] font-bold text-cyber-text">{alert.fault_type}</span>
            <span className="text-[10px] text-cyber-cyan ml-auto font-mono">{alert.node_id}</span>
          </div>
          <div className="text-[10px] text-cyber-muted mt-0.5 leading-snug line-clamp-2">
            {alert.description}
          </div>
        </div>
        <div className="text-[9px] text-cyber-muted font-mono whitespace-nowrap ml-1">
          {timeLabel(alert.ts)}
        </div>
      </div>

      {expanded && (
        <div className="border-t border-cyber-border px-3 py-2 text-[10px] space-y-1 bg-cyber-surface/50">
          <div className="flex gap-4">
            <span className="text-cyber-muted">SOURCE</span>
            <span className="text-cyber-text">{alert.source || '—'}</span>
          </div>
          {alert.ml?.ml_available && (
            <>
              <div className="flex gap-4">
                <span className="text-cyber-muted">ML PRED</span>
                <span className="text-cyber-amber font-bold">{alert.ml.fault_type}</span>
              </div>
              <div className="flex gap-4">
                <span className="text-cyber-muted">CONFIDENCE</span>
                <span className="text-cyber-text">{((alert.ml.confidence || 0) * 100).toFixed(1)}%</span>
              </div>
            </>
          )}
          <div className="flex gap-4">
            <span className="text-cyber-muted">TIME</span>
            <span className="text-cyber-text">{alert.ts}</span>
          </div>
        </div>
      )}
    </div>
  )
}

export default function AlertFeed({ alertFeed }) {
  const [filter, setFilter] = useState('ALL')

  const counts = { ALL: alertFeed.length }
  for (const a of alertFeed) {
    const s = a.severity?.toUpperCase()
    counts[s] = (counts[s] || 0) + 1
  }

  const visible = filter === 'ALL'
    ? alertFeed
    : alertFeed.filter(a => a.severity?.toUpperCase() === filter)

  return (
    <div className="panel h-full flex flex-col">
      <div className="panel-header justify-between">
        <div className="flex items-center gap-2">
          <span className="dot dot-red animate-pulse-slow" />
          FAULT ALERTS
          {alertFeed.length > 0 && (
            <span className="ml-1 bg-cyber-red/20 text-cyber-red border border-cyber-red/40 rounded px-1.5 text-[10px] font-bold">
              {alertFeed.length}
            </span>
          )}
        </div>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-1 px-3 py-1.5 border-b border-cyber-border bg-cyber-surface/40">
        {['ALL', 'CRITICAL', 'MEDIUM', 'LOW'].map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`text-[9px] font-bold px-2 py-0.5 rounded transition-all font-mono
              ${filter === f
                ? f === 'CRITICAL' ? 'bg-cyber-red/20 text-cyber-red border border-cyber-red/50'
                : f === 'MEDIUM'   ? 'bg-cyber-amber/20 text-cyber-amber border border-cyber-amber/50'
                : f === 'LOW'      ? 'bg-cyber-green/10 text-cyber-green border border-cyber-green/40'
                :                   'bg-cyber-cyan/10 text-cyber-cyan border border-cyber-cyan/40'
                : 'text-cyber-muted border border-transparent hover:border-cyber-border'
              }`}
          >
            {f} {counts[f] ? `(${counts[f]})` : ''}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
        {visible.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-32 text-cyber-muted text-[11px]">
            <div className="text-xl mb-1">◎</div>
            {filter === 'ALL' ? 'No faults detected yet' : `No ${filter} faults`}
          </div>
        ) : (
          visible.map((a, i) => <AlertRow key={a.id || i} alert={a} />)
        )}
      </div>
    </div>
  )
}
