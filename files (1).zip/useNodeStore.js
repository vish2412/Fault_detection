/**
 * useNodeStore.js
 * ---------------
 * Manages the central node registry and per-node metric history.
 *
 * State shape:
 *
 *   nodes: Array<{
 *     node_id:       string
 *     status:        "online" | "offline" | "unknown"
 *     hostname:      string | null
 *     ip_address:    string | null
 *     os_info:       string | null
 *     last_seen:     ISO timestamp | null
 *     latestMetrics: { latency_ms, packet_loss_rate, throughput_mbps, jitter_ms } | null
 *   }>
 *
 *   metricHistory: Map<node_id, Array<{
 *     timestamp:         ISO string
 *     latency_ms:        number
 *     packet_loss_rate:  number
 *     throughput_mbps:   number
 *     jitter_ms:         number
 *   }>>
 *
 * The hook also runs a background interval that marks nodes as "offline"
 * when their last_seen timestamp exceeds NODE_OFFLINE_TIMEOUT_S.
 */

import { useState, useCallback, useRef, useEffect } from "react";
import CONFIG from "../config.js";

const MAX_HISTORY = CONFIG.MAX_CHART_POINTS; // 60 points per node
const OFFLINE_TIMEOUT_MS = CONFIG.NODE_OFFLINE_TIMEOUT_S * 1000;

// ── Default node shape ────────────────────────────────────────────────────────
function defaultNode(node_id) {
  return {
    node_id,
    status:        "unknown",
    hostname:      null,
    ip_address:    null,
    os_info:       null,
    last_seen:     null,
    latestMetrics: null,
  };
}

export function useNodeStore() {
  // nodes as an ordered array (insertion order preserved)
  const [nodes,         setNodes]         = useState([]);
  // metricHistory as a plain object { [node_id]: [...samples] }
  const [metricHistory, setMetricHistory] = useState({});

  // Internal ref so interval can read current nodes without stale closure
  const nodesRef = useRef([]);
  useEffect(() => { nodesRef.current = nodes; }, [nodes]);

  // ── upsertNode ──────────────────────────────────────────────────────────────
  const upsertNode = useCallback((update) => {
    const { node_id } = update;
    if (!node_id) return;

    setNodes((prev) => {
      const idx = prev.findIndex((n) => n.node_id === node_id);
      if (idx === -1) {
        // New node
        return [...prev, { ...defaultNode(node_id), ...update }];
      }
      // Merge update into existing node
      const updated = [...prev];
      updated[idx] = { ...updated[idx], ...update };
      return updated;
    });
  }, []);

  // ── appendMetric ────────────────────────────────────────────────────────────
  const appendMetric = useCallback((node_id, sample) => {
    if (!node_id) return;
    setMetricHistory((prev) => {
      const existing = prev[node_id] || [];
      const next = [...existing, sample];
      // Keep only the most recent MAX_HISTORY points
      const trimmed = next.length > MAX_HISTORY
        ? next.slice(next.length - MAX_HISTORY)
        : next;
      return { ...prev, [node_id]: trimmed };
    });
  }, []);

  // ── setNodeStatus ───────────────────────────────────────────────────────────
  const setNodeStatus = useCallback((node_id, status) => {
    if (!node_id) return;
    setNodes((prev) => {
      const idx = prev.findIndex((n) => n.node_id === node_id);
      if (idx === -1) return prev;
      const updated = [...prev];
      updated[idx] = { ...updated[idx], status };
      return updated;
    });
  }, []);

  // ── Background offline-detection sweep ─────────────────────────────────────
  // Runs every second; marks nodes offline when last_seen is stale.
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      setNodes((prev) => {
        let changed = false;
        const next = prev.map((node) => {
          if (node.status !== "online") return node;
          if (!node.last_seen) return node;
          const age = now - new Date(node.last_seen).getTime();
          if (age > OFFLINE_TIMEOUT_MS) {
            changed = true;
            return { ...node, status: "offline" };
          }
          return node;
        });
        return changed ? next : prev; // avoid re-render if nothing changed
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return {
    nodes,
    metricHistory,
    upsertNode,
    appendMetric,
    setNodeStatus,
  };
}
