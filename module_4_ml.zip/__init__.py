"""
ml_model/
=========
Machine-learning pipeline for the AI Network Fault Detection System.

Public surface
--------------
    from ml_model.inference import FaultPredictor, predict, get_predictor
    from ml_model.train    import train, build_synthetic_dataset, FAULT_CLASSES

Scripts
-------
    python ml_model/train.py      — train (or retrain) the classifier
    python ml_model/inference.py  — standalone prediction CLI
"""

from ml_model.inference import (
    FaultPredictor,
    get_predictor,
    predict,
    FAULT_CLASSES,
    FEATURE_COLUMNS,
    SEVERITY_MAP,
)

__all__ = [
    "FaultPredictor",
    "get_predictor",
    "predict",
    "FAULT_CLASSES",
    "FEATURE_COLUMNS",
    "SEVERITY_MAP",
]
