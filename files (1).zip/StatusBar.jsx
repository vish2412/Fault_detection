/**
 * StatusBar.jsx
 * -------------
 * Persistent bottom status strip showing:
 *   - WebSocket connection state
 *   - Node count / online count
 *   - Alert count
 *   - Last ML prediction summary
 *   - Current timestamp (ticking clock)
 */

import React, { useState, useEffect } from "react";
import { clsx } from "clsx";
import { WS_STATES } from "../hooks/useWebSocket.js";

function Clock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  const pad = (n) => String(n).padStart(2, "0");
  return (
    <span className="font-mono text-[10px] text-slate-500">
      {pad(now.getHours())}:{pad(now.getMinutes())}:{pad(now.getSeconds())}
    </span>
  );
}

export default function StatusBar({
  connectionState,
  nodeCount,
  onlineCount,
  alertCount,
  lastMLPrediction,
}) {
  const isConnected = connectionState === WS_STATES.CONNECTED;

  return (
    <footer className="bg-surface-800/80 border-t border-surface-600 px-4 py-1.5 flex items-center gap-4 flex-wrap text-[11px] backdrop-blur-sm sticky bottom-0 z-10">

      {/* Connection */}
      <div className="flex items-center gap-1.5">
        <span className={clsx(
          "w-1.5 h-1.5 rounded-full flex-shrink-0",
          isConnected ? "bg-emerald-400" : "bg-red-500 animate-pulse"
        )} />
        <span className={isConnected ? "text-emerald-400" : "text-red-400"}>
          {isConnected ? "WebSocket connected" : connectionState}
        </span>
      </div>

      <span className="text-surface-500 hidden sm:block">│</span>

      {/* Nodes */}
      <span className="text-slate-400">
        Nodes: <span className="text-emerald-400 font-mono">{onlineCount}</span>
        <span className="text-slate-500">/{nodeCount}</span> online
      </span>

      <span className="text-surface-500 hidden sm:block">│</span>

      {/* Alerts */}
      <span className="text-slate-400">
        Alerts: <span className={clsx("font-mono", alertCount > 0 ? "text-amber-400" : "text-slate-400")}>{alertCount}</span>
      </span>

      {/* ML last prediction */}
      {lastMLPrediction?.fault_type && (
        <>
          <span className="text-surface-500 hidden md:block">│</span>
          <span className="text-slate-400 hidden md:block">
            ML: <span className={clsx(
              "font-mono font-medium",
              lastMLPrediction.fault_type === "NORMAL" ? "text-emerald-400" : "text-amber-400"
            )}>
              {lastMLPrediction.fault_type}
            </span>
            {lastMLPrediction.confidence != null && (
              <span className="text-slate-500 ml-1">
                ({(lastMLPrediction.confidence * 100).toFixed(0)}%)
              </span>
            )}
          </span>
        </>
      )}

      {/* Spacer + clock */}
      <div className="ml-auto flex items-center gap-2">
        <span className="text-slate-600 hidden sm:block">NetWatch AI v1.0.0</span>
        <Clock />
      </div>
    </footer>
  );
}
