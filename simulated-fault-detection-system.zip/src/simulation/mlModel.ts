/**
 * Simulated Random Forest ML Model for Fault Detection
 * Mimics a trained RandomForest/XGBoost classifier
 * trained on synthetic network telemetry data
 */

import type { FaultType, MLPrediction } from './types';

interface DecisionTree {
  id: number;
  predict: (features: FeatureVector) => FaultType | 'NORMAL';
}

interface FeatureVector {
  latency: number;
  packetLoss: number;
  throughput: number;
  jitter: number;
  latencyJitterRatio: number;
  throughputLossProduct: number;
}

// Simulated decision tree logic (mimics trained trees from sklearn/xgboost)
function buildDecisionTree(seed: number): DecisionTree {
  // Each tree has slightly different thresholds (simulating ensemble diversity)
  const latencyThresh = 180 + seed * 7;
  const lossThresh = 8 + seed * 0.5;
  const throughputThresh = 30 + seed * 2;
  const jitterThresh = 25 + seed * 3;
  const congestionThresh = 150 + seed * 5;

  return {
    id: seed,
    predict: (f: FeatureVector): FaultType | 'NORMAL' => {
      // Tree branching logic (simulates decision tree splits)
      if (f.latency > latencyThresh * 2 && f.packetLoss > lossThresh * 1.5) {
        return 'CONGESTION';
      }
      if (f.packetLoss > lossThresh * 2) {
        return 'PACKET_LOSS';
      }
      if (f.latency > latencyThresh * 1.8 && f.throughput < throughputThresh * 0.4) {
        return 'CONGESTION';
      }
      if (f.latency > latencyThresh) {
        if (f.jitter > jitterThresh * 1.5) return 'CONGESTION';
        return 'HIGH_LATENCY';
      }
      if (f.throughput < throughputThresh * 0.3) {
        return 'THROUGHPUT_DEGRADATION';
      }
      if (f.packetLoss > lossThresh) {
        return 'PACKET_LOSS';
      }
      if (f.jitter > jitterThresh * 2) {
        return 'HIGH_LATENCY';
      }
      if (f.throughput < throughputThresh * 0.6 && f.latency > congestionThresh) {
        return 'CONGESTION';
      }
      return 'NORMAL';
    }
  };
}

// Build ensemble of 15 decision trees (simulated Random Forest)
const FOREST: DecisionTree[] = Array.from({ length: 15 }, (_, i) => buildDecisionTree(i));

// Feature engineering (mimics sklearn preprocessing pipeline)
function extractFeatures(
  latency: number,
  packetLoss: number,
  throughput: number,
  jitter: number
): FeatureVector {
  return {
    latency,
    packetLoss,
    throughput,
    jitter,
    latencyJitterRatio: latency / Math.max(jitter, 0.1),
    throughputLossProduct: throughput * (1 - packetLoss / 100),
  };
}

// Normalize feature for display (simulates feature importance output)
function normalizeConfidence(votes: number, total: number, margin: number): number {
  const base = votes / total;
  // Add slight calibration noise (realistic model behavior)
  const noise = (Math.random() - 0.5) * 0.04;
  return Math.min(0.99, Math.max(0.51, base + noise + margin * 0.1));
}

export function mlPredict(
  latency: number,
  packetLoss: number,
  throughput: number,
  jitter: number
): MLPrediction {
  const features = extractFeatures(latency, packetLoss, throughput, jitter);

  // Run all trees and collect votes
  const votes: { [key: string]: number } = {
    NORMAL: 0,
    PACKET_LOSS: 0,
    HIGH_LATENCY: 0,
    CONGESTION: 0,
    THROUGHPUT_DEGRADATION: 0,
    NODE_FAILURE: 0,
    DATA_CORRUPTION: 0,
  };

  FOREST.forEach(tree => {
    const prediction = tree.predict(features);
    votes[prediction] = (votes[prediction] || 0) + 1;
  });

  // Find majority vote (Random Forest decision)
  let maxVotes = 0;
  let winner: FaultType | 'NORMAL' = 'NORMAL';
  for (const [label, count] of Object.entries(votes)) {
    if (count > maxVotes) {
      maxVotes = count;
      winner = label as FaultType | 'NORMAL';
    }
  }

  const total = FOREST.length;
  const margin = (maxVotes - total / Object.keys(votes).length) / total;
  const confidence = normalizeConfidence(maxVotes, total, margin);

  // Convert votes to percentages for display
  const treeVotes: { [key: string]: number } = {};
  for (const [label, count] of Object.entries(votes)) {
    if (count > 0) {
      treeVotes[label] = Math.round((count / total) * 100);
    }
  }

  return {
    faultType: winner,
    confidence,
    features: { latency, packetLoss, throughput, jitter },
    treeVotes,
  };
}

// Simulated model metadata (as if loaded from joblib)
export const MODEL_METADATA = {
  algorithm: 'RandomForestClassifier',
  n_estimators: 15,
  max_depth: 8,
  min_samples_split: 5,
  trained_on: '50,000 simulated samples',
  accuracy: 0.9312,
  f1_score: 0.9187,
  classes: ['NORMAL', 'PACKET_LOSS', 'HIGH_LATENCY', 'CONGESTION', 'THROUGHPUT_DEGRADATION', 'NODE_FAILURE', 'DATA_CORRUPTION'],
  feature_importance: {
    latency: 0.312,
    packetLoss: 0.298,
    throughput: 0.221,
    jitter: 0.169,
  },
  training_date: '2024-12-01',
  version: '2.4.1',
};
