import asyncio
import json
import logging
import os
import sys
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Any, Dict, Optional

import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Query, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

# Ensure local modules are importable
sys.path.insert(0, os.path.dirname(__file__))

from config import get_settings
from database.db import init_db, get_db, AsyncSessionLocal
from database.models import Node, MetricLog, FaultEvent as FaultEventModel
from websocket_manager import manager
from fault_detector import rule_detector, FaultEvent, FaultType
from ml_inference import ml_engine
from routers import nodes as nodes_router
from routers import metrics as metrics_router
from routers import alerts as alerts_router
from routers import files as files_router

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger(__name__)
settings = get_settings()


# ---------------------------------------------------------------------------
# Background Tasks
# ---------------------------------------------------------------------------

async def heartbeat_monitor():
    """
    Runs every second.
    Marks nodes as failed if their last heartbeat is older than WS_HEARTBEAT_TIMEOUT.
    """
    reported_failures: set = set()

    while True:
        await asyncio.sleep(1)
        for node_id in list(manager.node_connections.keys()):
            age = manager.get_heartbeat_age(node_id)
            if age is None:
                continue

            if age > settings.WS_HEARTBEAT_TIMEOUT:
                if node_id not in reported_failures:
                    reported_failures.add(node_id)
                    logger.warning("Node %s heartbeat timeout (%.1fs)", node_id, age)

                    fault = rule_detector.node_failure(node_id)
                    await persist_and_broadcast_fault(fault, {})
            else:
                reported_failures.discard(node_id)


async def persist_and_broadcast_fault(
    fault: FaultEvent,
    ml_result: Dict,
    db_session=None,
):
    """Save fault to DB and push to dashboard WebSocket subscribers."""
    async with AsyncSessionLocal() as db:
        db_fault = FaultEventModel(
            node_id=fault.node_id,
            fault_type=fault.fault_type.value,
            severity=fault.severity.value,
            description=fault.description,
            source=fault.source,
            metric_snapshot=json.dumps(fault.metric_snapshot),
            ml_fault_type=ml_result.get("fault_type"),
            ml_confidence=ml_result.get("confidence"),
            detected_at=fault.timestamp,
        )
        db.add(db_fault)
        await db.commit()
        await db.refresh(db_fault)

    payload = {
        "type": "fault_alert",
        **fault.to_dict(),
        "ml_prediction": ml_result,
        "db_id": db_fault.id,
    }
    await manager.broadcast_to_dashboards(payload)
    return db_fault


# ---------------------------------------------------------------------------
# Lifespan
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting %s v%s", settings.APP_NAME, settings.APP_VERSION)

    # Initialize DB
    await init_db()
    logger.info("Database initialized")

    # Create uploads dir
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)

    # ---------------------------------------------------------------------------
    # BUG FIX: ML model auto-reload at startup.
    #
    # ml_engine is a module-level singleton instantiated at import time.  At that
    # exact moment the model file may not yet exist (server started before
    # training), or the resolved path may have differed (CWD issue).
    #
    # We attempt a fresh reload here — after the CWD is fully established and
    # config paths are resolved — so a pre-trained model is always picked up
    # without requiring a manual POST /api/ml/reload call.
    # ---------------------------------------------------------------------------
    model_path_resolved = os.path.abspath(settings.ML_MODEL_PATH)
    if not ml_engine.is_ready:
        if os.path.exists(model_path_resolved):
            logger.info("ML model found at startup — reloading: %s", model_path_resolved)
            ml_engine.reload()
        else:
            logger.warning(
                "ML model not found at '%s'. "
                "Rule-based detection only until 'python ml_model/train.py' is run "
                "and '/api/ml/reload' is called (or the server is restarted).",
                model_path_resolved,
            )

    if ml_engine.is_ready:
        logger.info("ML inference engine: READY")
    else:
        logger.warning("ML inference engine: NOT READY (model not trained yet)")

    # Start background monitors
    monitor_task = asyncio.create_task(heartbeat_monitor())
    logger.info("Heartbeat monitor started")

    yield

    # Shutdown
    monitor_task.cancel()
    try:
        await monitor_task
    except asyncio.CancelledError:
        pass
    logger.info("Server shutdown complete")


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
app.include_router(nodes_router.router)
app.include_router(metrics_router.router)
app.include_router(alerts_router.router)
app.include_router(files_router.router)


# ---------------------------------------------------------------------------
# REST endpoints
# ---------------------------------------------------------------------------

@app.get("/")
async def root():
    return {
        "service": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "running",
        "nodes_online": manager.total_nodes,
        "dashboard_clients": manager.total_dashboards,
    }


@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "ml_model_ready": ml_engine.is_ready,
        "nodes_online": manager.total_nodes,
    }


@app.post("/api/ml/reload")
async def reload_ml_model():
    """Hot-reload the ML model (call after retraining)."""
    success = ml_engine.reload()
    return {"success": success, "ml_ready": ml_engine.is_ready}


# ---------------------------------------------------------------------------
# WebSocket: Node endpoint  ws://host/ws/node/{node_id}
# ---------------------------------------------------------------------------

@app.websocket("/ws/node/{node_id}")
async def node_websocket(
    websocket: WebSocket,
    node_id: str,
    hostname: str = Query("unknown"),
    ip: str = Query("unknown"),
    os_info: str = Query("unknown"),
):
    """
    Node clients connect here and stream metric payloads.
    Expected JSON message types:
      - heartbeat
      - metrics
      - file_checksum (inline checksum result)
    """
    await manager.connect_node(
        websocket,
        node_id,
        metadata={"hostname": hostname, "ip_address": ip, "os_info": os_info},
    )

    # Upsert node record in DB
    async with AsyncSessionLocal() as db:
        from sqlalchemy.future import select as sa_select
        result = await db.execute(sa_select(Node).where(Node.node_id == node_id))
        node = result.scalar_one_or_none()
        if node is None:
            node = Node(
                node_id=node_id,
                hostname=hostname,
                ip_address=ip,
                os_info=os_info,
                registered_at=datetime.utcnow(),
                last_seen=datetime.utcnow(),
            )
            db.add(node)
        else:
            node.last_seen = datetime.utcnow()
            node.hostname = hostname
            node.ip_address = ip
        await db.commit()

    # Notify dashboards of new node
    await manager.broadcast_to_dashboards(
        {
            "type": "node_status",
            "node_id": node_id,
            "status": "online",
            "hostname": hostname,
            "ip_address": ip,
            "timestamp": datetime.utcnow().isoformat(),
        }
    )

    try:
        while True:
            raw = await websocket.receive_text()
            try:
                data: Dict[str, Any] = json.loads(raw)
            except json.JSONDecodeError:
                logger.warning("Non-JSON from node %s: %s", node_id, raw[:80])
                continue

            msg_type = data.get("type", "unknown")

            # -------- HEARTBEAT --------
            if msg_type == "heartbeat":
                manager.update_heartbeat(node_id)

                # Update last_seen in DB
                async with AsyncSessionLocal() as db:
                    from sqlalchemy.future import select as sa_select
                    result = await db.execute(sa_select(Node).where(Node.node_id == node_id))
                    node = result.scalar_one_or_none()
                    if node:
                        node.last_seen = datetime.utcnow()
                        await db.commit()

                # Echo to dashboards
                await manager.broadcast_to_dashboards(
                    {
                        "type": "heartbeat",
                        "node_id": node_id,
                        "timestamp": datetime.utcnow().isoformat(),
                    }
                )

            # -------- METRICS --------
            elif msg_type == "metrics":
                manager.update_heartbeat(node_id)
                metrics: Dict = data.get("payload", {})

                # 1. Persist to DB
                async with AsyncSessionLocal() as db:
                    log = MetricLog(
                        node_id=node_id,
                        latency_ms=metrics.get("latency_ms", 0.0),
                        packet_loss_rate=metrics.get("packet_loss_rate", 0.0),
                        throughput_mbps=metrics.get("throughput_mbps", 0.0),
                        jitter_ms=metrics.get("jitter_ms", 0.0),
                        recorded_at=datetime.utcnow(),
                    )
                    db.add(log)
                    await db.commit()

                # 2. Rule-based fault detection
                faults = rule_detector.detect(node_id, metrics)

                # 3. ML inference
                ml_result = ml_engine.predict_as_dict(metrics)

                # 4. Broadcast live metric to dashboards
                await manager.broadcast_to_dashboards(
                    {
                        "type": "metrics",
                        "node_id": node_id,
                        "payload": metrics,
                        "ml_prediction": ml_result,
                        "timestamp": datetime.utcnow().isoformat(),
                    }
                )

                # 5. Persist & broadcast each fault event
                for fault in faults:
                    await persist_and_broadcast_fault(fault, ml_result)

            # -------- FILE CHECKSUM (inline, without HTTP) --------
            elif msg_type == "file_checksum":
                payload = data.get("payload", {})
                client_checksum = payload.get("checksum", "")
                server_checksum = payload.get("server_checksum", "")  # may be pre-computed
                filename = payload.get("filename", "unknown")
                is_corrupted = client_checksum.lower() != server_checksum.lower() if server_checksum else False

                if is_corrupted:
                    fault = FaultEvent(
                        node_id=node_id,
                        fault_type=FaultType.DATA_CORRUPTION,
                        severity="CRITICAL",
                        description=f"Checksum mismatch for file '{filename}'",
                        metric_snapshot={"filename": filename, "client_checksum": client_checksum},
                        source="checksum_verify",
                    )
                    from fault_detector import Severity
                    fault.severity = Severity.CRITICAL
                    await persist_and_broadcast_fault(fault, {})

            # -------- UNKNOWN --------
            else:
                logger.debug("Unknown message type '%s' from node %s", msg_type, node_id)

    except WebSocketDisconnect:
        logger.info("Node %s disconnected", node_id)
    except Exception as e:
        logger.error("Error in node WS handler for %s: %s", node_id, e)
    finally:
        await manager.disconnect_node(node_id)


# ---------------------------------------------------------------------------
# WebSocket: Dashboard endpoint  ws://host/ws/dashboard
# ---------------------------------------------------------------------------

@app.websocket("/ws/dashboard")
async def dashboard_websocket(websocket: WebSocket):
    """
    Dashboard clients subscribe here to receive real-time events:
    - node_status      (online/offline)
    - heartbeat        (per-node pulse)
    - metrics          (live metric payloads + ML prediction)
    - fault_alert      (detected fault events)
    - initial_state    (sent once on connect)
    """
    await manager.connect_dashboard(websocket)
    try:
        while True:
            # Dashboard may send control messages (e.g., ping keepalive)
            raw = await websocket.receive_text()
            try:
                msg = json.loads(raw)
                if msg.get("type") == "ping":
                    await manager.send_to_websocket(
                        websocket,
                        {"type": "pong", "timestamp": datetime.utcnow().isoformat()},
                    )
            except Exception:
                pass
    except WebSocketDisconnect:
        pass
    finally:
        await manager.disconnect_dashboard(websocket)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG,
        log_level="info",
    )
