/**
 * LogPanel.jsx
 * ------------
 * Scrollable, filterable raw event log.
 * Shows all WebSocket events in reverse-chronological order.
 * Supports: text search, type filtering, pause/resume auto-scroll, CSV export.
 */

import React, { useState, useRef, useEffect, useMemo, useCallback } from "react";
import { clsx } from "clsx";

const TYPE_CONFIG = {
  heartbeat: { label: "HEARTBEAT", color: "text-slate-400",    bg: "bg-slate-500/10" },
  metrics:   { label: "METRICS",   color: "text-brand-400",    bg: "bg-brand-500/10" },
  fault:     { label: "FAULT",     color: "text-red-400",      bg: "bg-red-500/10"   },
  status:    { label: "STATUS",    color: "text-amber-400",    bg: "bg-amber-500/10" },
  system:    { label: "SYSTEM",    color: "text-emerald-400",  bg: "bg-emerald-500/10" },
  unknown:   { label: "UNKNOWN",   color: "text-slate-500",    bg: "bg-slate-600/10" },
};

const FILTER_TYPES = ["ALL", "fault", "metrics", "heartbeat", "status", "system"];

function formatTs(iso) {
  if (!iso) return "—";
  try {
    const d = new Date(iso);
    return `${d.getHours().toString().padStart(2, "0")}:` +
           `${d.getMinutes().toString().padStart(2, "0")}:` +
           `${d.getSeconds().toString().padStart(2, "0")}.` +
           `${d.getMilliseconds().toString().padStart(3, "0")}`;
  } catch { return iso; }
}

function LogRow({ entry }) {
  const cfg = TYPE_CONFIG[entry.type] || TYPE_CONFIG.unknown;
  return (
    <div className="flex items-start gap-3 py-1.5 border-b border-surface-700/40 hover:bg-white/[0.02] px-2 rounded transition-colors">
      <span className="text-[10px] font-mono text-slate-500 flex-shrink-0 w-28 pt-0.5">
        {formatTs(entry.ts)}
      </span>
      <span className={clsx(
        "flex-shrink-0 text-[10px] font-bold px-1.5 py-0.5 rounded w-20 text-center",
        cfg.color, cfg.bg
      )}>
        {cfg.label}
      </span>
      {entry.nodeId && (
        <span className="text-[10px] font-mono text-brand-400 flex-shrink-0 w-24 truncate pt-0.5">
          {entry.nodeId}
        </span>
      )}
      <span className="text-xs text-slate-300 flex-1 min-w-0 font-mono break-all">
        {entry.text}
      </span>
    </div>
  );
}

export default function LogPanel({ entries }) {
  const [filterType,  setFilterType]  = useState("ALL");
  const [searchText,  setSearchText]  = useState("");
  const [paused,      setPaused]      = useState(false);
  const scrollRef = useRef(null);

  // Filter + search
  const filtered = useMemo(() => {
    let list = entries;
    if (filterType !== "ALL") list = list.filter((e) => e.type === filterType);
    if (searchText.trim()) {
      const q = searchText.toLowerCase();
      list = list.filter(
        (e) => e.text?.toLowerCase().includes(q) || e.nodeId?.toLowerCase().includes(q)
      );
    }
    return list;
  }, [entries, filterType, searchText]);

  // Auto-scroll to top (newest entries) unless paused
  useEffect(() => {
    if (!paused && scrollRef.current) {
      scrollRef.current.scrollTop = 0;
    }
  }, [filtered, paused]);

  // CSV export
  const exportCSV = useCallback(() => {
    const rows = [
      ["timestamp", "type", "node_id", "message"],
      ...filtered.map((e) => [e.ts, e.type, e.nodeId || "", e.text || ""]),
    ];
    const csv = rows.map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href     = url;
    a.download = `netwatch-logs-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }, [filtered]);

  return (
    <div className="flex flex-col gap-4">
      {/* Controls */}
      <div className="glass-card p-4 flex flex-wrap items-center gap-3">
        {/* Type filter */}
        <div className="flex items-center gap-1 flex-wrap">
          {FILTER_TYPES.map((t) => (
            <button
              key={t}
              onClick={() => setFilterType(t)}
              className={clsx(
                "px-2.5 py-1 rounded-lg text-xs font-medium border transition-all",
                filterType === t
                  ? "bg-brand-600/30 border-brand-400/50 text-brand-300"
                  : "bg-surface-700 border-surface-500 text-slate-400 hover:text-slate-200"
              )}
            >
              {t.toUpperCase()}
            </button>
          ))}
        </div>

        {/* Search */}
        <input
          type="text"
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
          placeholder="Search logs…"
          className="flex-1 min-w-40 bg-surface-700 border border-surface-500 rounded-lg px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-brand-500/50"
        />

        {/* Actions */}
        <div className="flex items-center gap-2 ml-auto">
          <button
            onClick={() => setPaused((p) => !p)}
            className={clsx(
              "px-3 py-1.5 rounded-lg text-xs font-medium border transition-all",
              paused
                ? "bg-amber-500/20 border-amber-500/40 text-amber-300"
                : "bg-surface-700 border-surface-500 text-slate-400 hover:text-slate-200"
            )}
          >
            {paused ? "▶ Resume" : "⏸ Pause"}
          </button>
          <button
            onClick={exportCSV}
            className="px-3 py-1.5 rounded-lg text-xs font-medium border bg-surface-700 border-surface-500 text-slate-400 hover:text-slate-200 transition-all"
          >
            ⬇ CSV
          </button>
        </div>

        {/* Count */}
        <span className="text-xs text-slate-500 flex-shrink-0">
          {filtered.length} / {entries.length} entries
        </span>
      </div>

      {/* Log table */}
      <div className="glass-card overflow-hidden">
        {/* Column headers */}
        <div className="flex items-center gap-3 px-4 py-2 border-b border-surface-600 bg-surface-700/50">
          <span className="text-[10px] text-slate-500 w-28 flex-shrink-0">TIMESTAMP</span>
          <span className="text-[10px] text-slate-500 w-20 flex-shrink-0">TYPE</span>
          <span className="text-[10px] text-slate-500 w-24 flex-shrink-0">NODE</span>
          <span className="text-[10px] text-slate-500 flex-1">MESSAGE</span>
        </div>
        {/* Rows */}
        <div
          ref={scrollRef}
          className="overflow-y-auto max-h-[600px] scrollbar-thin px-2"
        >
          {filtered.length === 0 ? (
            <div className="py-12 text-center">
              <p className="text-slate-500 text-sm">
                {entries.length === 0 ? "No log entries yet." : "No entries match the current filter."}
              </p>
            </div>
          ) : (
            filtered.map((entry, i) => <LogRow key={i} entry={entry} />)
          )}
        </div>
      </div>
    </div>
  );
}
