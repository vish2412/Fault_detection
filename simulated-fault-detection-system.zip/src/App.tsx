import { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useSimulationStore } from './store/simulationStore';
import { SystemOverview } from './components/dashboard/SystemOverview';
import { NodeGrid } from './components/dashboard/NodeGrid';
import { LiveCharts } from './components/dashboard/LiveCharts';
import { NetworkTopology } from './components/topology/NetworkTopology';
import { AlertPanel } from './components/alerts/AlertPanel';
import { LogPanel } from './components/logs/LogPanel';
import { MLDashboard } from './components/ml/MLDashboard';
import { FileTransferPanel } from './components/transfers/FileTransferPanel';
import { SimulationControls } from './components/controls/SimulationControls';

const TABS = [
  { id: 'dashboard',  label: 'Dashboard',   icon: '📊' },
  { id: 'topology',   label: 'Topology',    icon: '🌐' },
  { id: 'alerts',     label: 'Alerts',      icon: '🚨' },
  { id: 'ml',         label: 'ML Engine',   icon: '🤖' },
  { id: 'transfers',  label: 'Transfers',   icon: '📁' },
  { id: 'logs',       label: 'Logs',        icon: '📜' },
] as const;

type TabId = typeof TABS[number]['id'];

export default function App() {
  const {
    isRunning, startSimulation, activeTab, setActiveTab,
    allFaults, systemStats, tickCount,
  } = useSimulationStore();

  const hasStarted = useRef(false);
  useEffect(() => {
    if (!hasStarted.current) {
      hasStarted.current = true;
      startSimulation();
    }
  }, [startSimulation]);

  const criticalCount = allFaults.filter(f => f.severity === 'CRITICAL' && !f.resolved).length;

  return (
    <div className="min-h-screen bg-slate-950 text-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      {/* ── Animated background ── */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl" />
        <div className="absolute top-1/3 -right-40 w-80 h-80 bg-violet-600/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-1/2 w-64 h-64 bg-cyan-600/8 rounded-full blur-3xl" />
      </div>

      {/* ── Header ── */}
      <header className="relative z-10 border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-xl sticky top-0">
        <div className="max-w-screen-2xl mx-auto px-4 sm:px-6 flex items-center justify-between h-14">
          {/* Logo */}
          <div className="flex items-center gap-3 flex-shrink-0">
            <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-violet-600 shadow-lg shadow-blue-500/30">
              <span className="text-base">🛡️</span>
              {isRunning && (
                <motion.span
                  className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-slate-950"
                  animate={{ scale: [1, 1.3, 1] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                />
              )}
            </div>
            <div className="hidden sm:block">
              <p className="text-sm font-bold text-white tracking-tight leading-none">NetGuard AI</p>
              <p className="text-xs text-slate-500 font-mono">Distributed Fault Detection</p>
            </div>
          </div>

          {/* Center status bar */}
          <div className="hidden md:flex items-center gap-4 text-xs font-mono">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/60">
              <span className={`w-1.5 h-1.5 rounded-full ${isRunning ? 'bg-emerald-400' : 'bg-slate-500'}`} />
              <span className="text-slate-400">{isRunning ? 'LIVE' : 'STOPPED'}</span>
              <span className="text-slate-600">|</span>
              <span className="text-slate-500">Tick #{tickCount}</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-emerald-400">{systemStats.onlineNodes} online</span>
              <span className="text-slate-600">·</span>
              <span className="text-amber-400">{systemStats.warningNodes} warn</span>
              <span className="text-slate-600">·</span>
              <span className="text-red-400">{systemStats.offlineNodes} offline</span>
            </div>
            {criticalCount > 0 && (
              <motion.div
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-red-500/15 border border-red-500/30 text-red-400"
                animate={{ opacity: [1, 0.6, 1] }}
                transition={{ duration: 0.8, repeat: Infinity }}
              >
                <span>⚠</span>
                <span>{criticalCount} CRITICAL</span>
              </motion.div>
            )}
          </div>

          {/* Right: ML badge */}
          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-violet-500/10 border border-violet-500/20 text-violet-400 text-xs font-mono">
              <span>🤖</span>
              <span>RandomForest v2.4.1</span>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800/60 text-xs font-mono text-slate-400">
              <span className="text-emerald-400">93.12%</span>
              <span>acc.</span>
            </div>
          </div>
        </div>

        {/* Tab navigation */}
        <div className="max-w-screen-2xl mx-auto px-4 sm:px-6 flex items-center gap-1 overflow-x-auto pb-0 scrollbar-hide">
          {TABS.map(tab => {
            const isActive = activeTab === tab.id;
            const isBadge = tab.id === 'alerts' && criticalCount > 0;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabId)}
                className={`
                  relative flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-medium
                  border-b-2 transition-all duration-200 whitespace-nowrap flex-shrink-0
                  ${isActive
                    ? 'border-blue-500 text-blue-400'
                    : 'border-transparent text-slate-500 hover:text-slate-300 hover:border-slate-600'
                  }
                `}
              >
                <span>{tab.icon}</span>
                <span className="uppercase tracking-wide">{tab.label}</span>
                {isBadge && (
                  <motion.span
                    className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-red-500 text-white text-xs flex items-center justify-center font-bold"
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 1, repeat: Infinity }}
                  >
                    {criticalCount > 9 ? '9+' : criticalCount}
                  </motion.span>
                )}
              </button>
            );
          })}
        </div>
      </header>

      {/* ── Main Content ── */}
      <main className="relative z-10 max-w-screen-2xl mx-auto px-4 sm:px-6 py-5 space-y-5">
        <AnimatePresence mode="wait">
          {activeTab === 'dashboard' && (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.25 }}
              className="space-y-5"
            >
              {/* Control panel + system overview row */}
              <div className="grid grid-cols-1 xl:grid-cols-4 gap-4">
                <div className="xl:col-span-1">
                  <SimulationControls />
                </div>
                <div className="xl:col-span-3">
                  <SystemOverview />
                </div>
              </div>

              {/* Node grid */}
              <SectionHeader icon="🖥️" title="Node Grid" subtitle={`${systemStats.totalNodes} distributed nodes across all regions`} />
              <NodeGrid />

              {/* Charts */}
              <SectionHeader icon="📈" title="Live Telemetry Charts" subtitle="Real-time simulated network metrics — updated every 2s" />
              <LiveCharts />
            </motion.div>
          )}

          {activeTab === 'topology' && (
            <motion.div
              key="topology"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.25 }}
              className="space-y-5"
            >
              <SectionHeader icon="🌐" title="Network Topology" subtitle="Interactive node map with live fault visualization" />
              <NetworkTopology />
            </motion.div>
          )}

          {activeTab === 'alerts' && (
            <motion.div
              key="alerts"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.25 }}
              className="space-y-5"
            >
              <SectionHeader icon="🚨" title="Alert Center" subtitle="Real-time fault detection — Rule-based + ML hybrid engine" />
              <AlertPanel />
            </motion.div>
          )}

          {activeTab === 'ml' && (
            <motion.div
              key="ml"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.25 }}
              className="space-y-5"
            >
              <SectionHeader icon="🤖" title="ML Fault Detection Engine" subtitle="RandomForest classifier — 50K training samples — 93.12% accuracy" />
              <MLDashboard />
            </motion.div>
          )}

          {activeTab === 'transfers' && (
            <motion.div
              key="transfers"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.25 }}
              className="space-y-5"
            >
              <SectionHeader icon="📁" title="File Transfer Monitor" subtitle="Simulated file transfers with SHA256 checksum integrity verification" />
              <FileTransferPanel />
            </motion.div>
          )}

          {activeTab === 'logs' && (
            <motion.div
              key="logs"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.25 }}
              className="space-y-5"
            >
              <SectionHeader icon="📜" title="System Logs" subtitle="Live event stream from all distributed nodes — exportable to CSV" />
              <LogPanel />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* ── Footer ── */}
      <footer className="relative z-10 border-t border-slate-800/60 mt-8 py-4">
        <div className="max-w-screen-2xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs font-mono text-slate-600">
          <div className="flex items-center gap-3">
            <span>🛡️ NetGuard AI</span>
            <span>·</span>
            <span>AI-Based Distributed Network Fault Detection System</span>
          </div>
          <div className="flex items-center gap-3">
            <span>RandomForest v2.4.1</span>
            <span>·</span>
            <span>Simulation Engine v3.0</span>
            <span>·</span>
            <span className="text-emerald-600">● All data simulated — no real network calls</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

function SectionHeader({ icon, title, subtitle }: { icon: string; title: string; subtitle: string }) {
  return (
    <div className="flex items-center gap-3 py-1">
      <span className="text-xl">{icon}</span>
      <div>
        <h2 className="text-sm font-bold text-slate-200 font-mono uppercase tracking-wide">{title}</h2>
        <p className="text-xs text-slate-500 font-mono">{subtitle}</p>
      </div>
    </div>
  );
}
