// src/App.jsx
import React, { useState } from 'react'
import { useWebSocket } from './hooks/useWebSocket'
import StatusBar    from './components/StatusBar'
import NodeGrid     from './components/NodeGrid'
import MetricCharts from './components/MetricCharts'
import AlertFeed    from './components/AlertFeed'
import MLPanel      from './components/MLPanel'
import LogPanel     from './components/LogPanel'

// ── Tab definitions for mobile/compact view ──
const TABS = [
  { id: 'nodes',   label: 'NODES'   },
  { id: 'charts',  label: 'CHARTS'  },
  { id: 'alerts',  label: 'ALERTS'  },
  { id: 'ai',      label: 'AI'      },
  { id: 'log',     label: 'LOG'     },
]

export default function App() {
  const {
    connected,
    error,
    nodeMap,
    metricStream,
    alertFeed,
    logFeed,
    mlLatest,
  } = useWebSocket()

  const [activeTab, setActiveTab] = useState('nodes')

  const criticalCount = alertFeed.filter(a => a.severity === 'CRITICAL').length

  return (
    <div className="min-h-screen flex flex-col bg-cyber-bg">

      {/* ── Top bar ── */}
      <StatusBar
        connected={connected}
        error={error}
        nodeMap={nodeMap}
        alertFeed={alertFeed}
      />

      {/* ── Connection error banner ── */}
      {error && (
        <div className="bg-cyber-red/10 border-b border-cyber-red/40 px-4 py-2
                        text-cyber-red text-[11px] font-mono flex items-center gap-2">
          <span className="dot dot-red animate-pulse-slow" />
          {error} — Make sure the server is running at{' '}
          <code className="underline">{import.meta.env.VITE_WS_URL || 'ws://localhost:8000'}</code>
        </div>
      )}

      {/* ── Critical alert banner ── */}
      {criticalCount > 0 && (
        <div className="bg-cyber-red/10 border-b border-cyber-red/30 px-4 py-1.5
                        text-cyber-red text-[10px] font-mono flex items-center gap-2 animate-fadein">
          <span className="dot dot-red animate-pulse-slow" />
          ⚠ {criticalCount} CRITICAL fault{criticalCount > 1 ? 's' : ''} detected —
          check Alert Feed for details
        </div>
      )}

      {/* ── Mobile tab bar (visible on small screens) ── */}
      <nav className="flex xl:hidden border-b border-cyber-border bg-cyber-surface overflow-x-auto">
        {TABS.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 text-[10px] font-bold font-mono tracking-widest shrink-0 transition-colors
              ${activeTab === tab.id
                ? 'text-cyber-cyan border-b-2 border-cyber-cyan bg-cyber-panel'
                : 'text-cyber-muted hover:text-cyber-text'
              }`}
          >
            {tab.id === 'alerts' && criticalCount > 0 && (
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-cyber-red mr-1 align-middle animate-pulse-slow" />
            )}
            {tab.label}
          </button>
        ))}
      </nav>

      {/* ── Main layout ── */}
      <main className="flex-1 p-3 overflow-hidden">

        {/* ═══════════════════════════════════════
            DESKTOP: 3-column fixed grid
            col-1: nodes (narrow)
            col-2: charts + log (wide)
            col-3: alerts + ML (medium)
        ═══════════════════════════════════════ */}
        <div className="hidden xl:grid xl:grid-cols-[280px_1fr_320px] gap-3 h-[calc(100vh-88px)]">

          {/* Column 1 — Node Grid */}
          <div className="overflow-hidden">
            <NodeGrid nodeMap={nodeMap} metricStream={metricStream} />
          </div>

          {/* Column 2 — Charts + Log */}
          <div className="grid grid-rows-[1fr_220px] gap-3 overflow-hidden">
            <div className="overflow-hidden">
              <MetricCharts metricStream={metricStream} nodeMap={nodeMap} />
            </div>
            <div className="overflow-hidden">
              <LogPanel logFeed={logFeed} />
            </div>
          </div>

          {/* Column 3 — Alerts + ML */}
          <div className="grid grid-rows-[1fr_320px] gap-3 overflow-hidden">
            <div className="overflow-hidden">
              <AlertFeed alertFeed={alertFeed} />
            </div>
            <div className="overflow-hidden">
              <MLPanel mlLatest={mlLatest} alertFeed={alertFeed} />
            </div>
          </div>
        </div>

        {/* ═══════════════════════════════════════
            MOBILE / TABLET: Single-tab view
        ═══════════════════════════════════════ */}
        <div className="xl:hidden h-[calc(100vh-130px)] overflow-hidden">
          {activeTab === 'nodes' && (
            <NodeGrid nodeMap={nodeMap} metricStream={metricStream} />
          )}
          {activeTab === 'charts' && (
            <MetricCharts metricStream={metricStream} nodeMap={nodeMap} />
          )}
          {activeTab === 'alerts' && (
            <AlertFeed alertFeed={alertFeed} />
          )}
          {activeTab === 'ai' && (
            <MLPanel mlLatest={mlLatest} alertFeed={alertFeed} />
          )}
          {activeTab === 'log' && (
            <LogPanel logFeed={logFeed} />
          )}
        </div>
      </main>

      {/* ── Footer ── */}
      <footer className="border-t border-cyber-border px-4 py-1.5 flex justify-between
                         text-[9px] font-mono text-cyber-muted bg-cyber-surface/60">
        <span>NetFault v1.0 — AI Network Fault Detection</span>
        <span>
          WS: <span className={connected ? 'text-cyber-green' : 'text-cyber-red'}>
            {connected ? 'CONNECTED' : 'DISCONNECTED'}
          </span>
          {' · '}
          {metricStream.length} metrics · {alertFeed.length} alerts
        </span>
      </footer>
    </div>
  )
}
