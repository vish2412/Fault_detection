// src/config.js
// Edit these values to match your server machine's IP and port.
// Or set VITE_SERVER_URL and VITE_WS_URL in frontend/.env.local

const SERVER_HOST = import.meta.env.VITE_SERVER_URL || 'http://localhost:8000'
const WS_HOST     = import.meta.env.VITE_WS_URL     || 'ws://localhost:8000'

export const config = {
  serverUrl:      SERVER_HOST,
  wsUrl:          WS_HOST,
  wsDashboard:    `${WS_HOST}/ws/dashboard`,
  apiNodes:       `${SERVER_HOST}/api/nodes`,
  apiMetrics:     `${SERVER_HOST}/api/metrics`,
  apiAlerts:      `${SERVER_HOST}/api/alerts`,
  apiFiles:       `${SERVER_HOST}/api/files`,
  apiHealth:      `${SERVER_HOST}/health`,
}

export default config
