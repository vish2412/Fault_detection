import logging
from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import desc, func, and_

from database.db import get_db
from database.models import MetricLog

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/metrics", tags=["metrics"])


@router.get("/latest")
async def get_latest_metrics(
    limit: int = Query(50, le=200),
    db: AsyncSession = Depends(get_db),
):
    """Get the most recent metric records across all nodes."""
    result = await db.execute(
        select(MetricLog)
        .order_by(desc(MetricLog.recorded_at))
        .limit(limit)
    )
    metrics = result.scalars().all()

    return {
        "metrics": [
            {
                "id": m.id,
                "node_id": m.node_id,
                "latency_ms": m.latency_ms,
                "packet_loss_rate": m.packet_loss_rate,
                "throughput_mbps": m.throughput_mbps,
                "jitter_ms": m.jitter_ms,
                "recorded_at": m.recorded_at.isoformat() if m.recorded_at else None,
            }
            for m in metrics
        ]
    }


@router.get("/summary")
async def get_metrics_summary(
    hours: int = Query(1, ge=1, le=168),
    db: AsyncSession = Depends(get_db),
):
    """Network-wide metric summary for the past N hours."""
    since = datetime.utcnow() - timedelta(hours=hours)

    result = await db.execute(
        select(
            MetricLog.node_id,
            func.avg(MetricLog.latency_ms).label("avg_latency"),
            func.max(MetricLog.latency_ms).label("max_latency"),
            func.avg(MetricLog.packet_loss_rate).label("avg_packet_loss"),
            func.avg(MetricLog.throughput_mbps).label("avg_throughput"),
            func.min(MetricLog.throughput_mbps).label("min_throughput"),
            func.avg(MetricLog.jitter_ms).label("avg_jitter"),
            func.count(MetricLog.id).label("sample_count"),
        )
        .where(MetricLog.recorded_at >= since)
        .group_by(MetricLog.node_id)
    )
    rows = result.all()

    return {
        "period_hours": hours,
        "since": since.isoformat(),
        "nodes": [
            {
                "node_id": row.node_id,
                "avg_latency_ms": round(row.avg_latency or 0, 2),
                "max_latency_ms": round(row.max_latency or 0, 2),
                "avg_packet_loss": round(row.avg_packet_loss or 0, 4),
                "avg_throughput_mbps": round(row.avg_throughput or 0, 2),
                "min_throughput_mbps": round(row.min_throughput or 0, 2),
                "avg_jitter_ms": round(row.avg_jitter or 0, 2),
                "sample_count": row.sample_count,
            }
            for row in rows
        ],
    }


@router.get("/timeseries/{node_id}")
async def get_timeseries(
    node_id: str,
    minutes: int = Query(10, ge=1, le=1440),
    db: AsyncSession = Depends(get_db),
):
    """Get time-series metric data for charting."""
    since = datetime.utcnow() - timedelta(minutes=minutes)

    result = await db.execute(
        select(MetricLog)
        .where(
            and_(
                MetricLog.node_id == node_id,
                MetricLog.recorded_at >= since,
            )
        )
        .order_by(MetricLog.recorded_at)
    )
    metrics = result.scalars().all()

    return {
        "node_id": node_id,
        "period_minutes": minutes,
        "timeseries": [
            {
                "timestamp": m.recorded_at.isoformat(),
                "latency_ms": m.latency_ms,
                "packet_loss_rate": m.packet_loss_rate,
                "throughput_mbps": m.throughput_mbps,
                "jitter_ms": m.jitter_ms,
            }
            for m in metrics
        ],
        "count": len(metrics),
    }
