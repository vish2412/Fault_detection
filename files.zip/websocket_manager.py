import asyncio
import json
import logging
from collections import defaultdict
from datetime import datetime
from typing import Any, Dict, List, Optional, Set

from fastapi import WebSocket

logger = logging.getLogger(__name__)


class ConnectionManager:
    """
    Manages all WebSocket connections.
    Separates node connections (data producers) from dashboard connections (consumers).
    """

    def __init__(self):
        # node_id -> WebSocket (one socket per node)
        self.node_connections: Dict[str, WebSocket] = {}

        # Dashboard viewers (many allowed)
        self.dashboard_connections: List[WebSocket] = []

        # node_id -> last heartbeat timestamp
        self.last_heartbeat: Dict[str, datetime] = {}

        # node_id -> metadata dict
        self.node_metadata: Dict[str, Dict[str, Any]] = {}

        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------
    # Node connections
    # ------------------------------------------------------------------

    async def connect_node(
        self, websocket: WebSocket, node_id: str, metadata: Optional[Dict] = None
    ) -> None:
        await websocket.accept()
        async with self._lock:
            # Disconnect previous socket if node reconnects
            if node_id in self.node_connections:
                try:
                    await self.node_connections[node_id].close()
                except Exception:
                    pass

            self.node_connections[node_id] = websocket
            self.last_heartbeat[node_id] = datetime.utcnow()
            self.node_metadata[node_id] = {
                "node_id": node_id,
                "connected_at": datetime.utcnow().isoformat(),
                "status": "online",
                **(metadata or {}),
            }

        logger.info("Node connected: %s | total nodes: %d", node_id, len(self.node_connections))

        await self.send_to_node(
            node_id,
            {
                "type": "connection_ack",
                "node_id": node_id,
                "timestamp": datetime.utcnow().isoformat(),
                "message": "Connected to fault detection server",
            },
        )

    async def disconnect_node(self, node_id: str) -> None:
        async with self._lock:
            self.node_connections.pop(node_id, None)
            if node_id in self.node_metadata:
                self.node_metadata[node_id]["status"] = "offline"
                self.node_metadata[node_id]["disconnected_at"] = datetime.utcnow().isoformat()

        logger.info("Node disconnected: %s", node_id)

        # Notify dashboards
        await self.broadcast_to_dashboards(
            {
                "type": "node_status",
                "node_id": node_id,
                "status": "offline",
                "timestamp": datetime.utcnow().isoformat(),
            }
        )

    # ------------------------------------------------------------------
    # Dashboard connections
    # ------------------------------------------------------------------

    async def connect_dashboard(self, websocket: WebSocket) -> None:
        await websocket.accept()
        async with self._lock:
            self.dashboard_connections.append(websocket)

        logger.info("Dashboard connected | total dashboards: %d", len(self.dashboard_connections))

        # Send current node states to newly connected dashboard
        await self.send_to_websocket(
            websocket,
            {
                "type": "initial_state",
                "nodes": list(self.node_metadata.values()),
                "timestamp": datetime.utcnow().isoformat(),
            },
        )

    async def disconnect_dashboard(self, websocket: WebSocket) -> None:
        async with self._lock:
            if websocket in self.dashboard_connections:
                self.dashboard_connections.remove(websocket)
        logger.info("Dashboard disconnected | total dashboards: %d", len(self.dashboard_connections))

    # ------------------------------------------------------------------
    # Messaging
    # ------------------------------------------------------------------

    async def send_to_node(self, node_id: str, data: Dict) -> bool:
        ws = self.node_connections.get(node_id)
        if ws:
            return await self.send_to_websocket(ws, data)
        return False

    async def send_to_websocket(self, websocket: WebSocket, data: Dict) -> bool:
        try:
            await websocket.send_text(json.dumps(data, default=str))
            return True
        except Exception as e:
            logger.warning("Failed to send message: %s", e)
            return False

    async def broadcast_to_dashboards(self, data: Dict) -> None:
        if not self.dashboard_connections:
            return

        message = json.dumps(data, default=str)
        dead: List[WebSocket] = []

        for ws in self.dashboard_connections:
            try:
                await ws.send_text(message)
            except Exception:
                dead.append(ws)

        # Cleanup dead connections
        async with self._lock:
            for ws in dead:
                if ws in self.dashboard_connections:
                    self.dashboard_connections.remove(ws)

    async def broadcast_to_all(self, data: Dict) -> None:
        """Send to both nodes and dashboards."""
        await self.broadcast_to_dashboards(data)

    # ------------------------------------------------------------------
    # Heartbeat tracking
    # ------------------------------------------------------------------

    def update_heartbeat(self, node_id: str) -> None:
        self.last_heartbeat[node_id] = datetime.utcnow()
        if node_id in self.node_metadata:
            self.node_metadata[node_id]["status"] = "online"
            self.node_metadata[node_id]["last_seen"] = datetime.utcnow().isoformat()

    def get_heartbeat_age(self, node_id: str) -> Optional[float]:
        """Returns seconds since last heartbeat, or None if never seen."""
        last = self.last_heartbeat.get(node_id)
        if last is None:
            return None
        return (datetime.utcnow() - last).total_seconds()

    # ------------------------------------------------------------------
    # State queries
    # ------------------------------------------------------------------

    @property
    def total_nodes(self) -> int:
        return len(self.node_connections)

    @property
    def total_dashboards(self) -> int:
        return len(self.dashboard_connections)

    def get_online_nodes(self) -> List[str]:
        return list(self.node_connections.keys())

    def get_all_node_metadata(self) -> List[Dict]:
        return list(self.node_metadata.values())


# Singleton instance
manager = ConnectionManager()
