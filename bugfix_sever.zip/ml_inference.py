import logging
import os
from typing import Any, Dict, Optional, Tuple

import joblib
import numpy as np

from config import get_settings
from fault_detector import FaultType, Severity

logger = logging.getLogger(__name__)
settings = get_settings()


class MLInferenceEngine:
    """
    Loads a pre-trained RandomForestClassifier and runs inference
    on incoming metric payloads. Falls back gracefully if the model
    file is not yet available.
    """

    FEATURE_COLUMNS = ["latency_ms", "packet_loss_rate", "throughput_mbps", "jitter_ms"]

    # Maps classifier label indices back to FaultType
    LABEL_MAP: Dict[int, FaultType] = {
        0: FaultType.NORMAL,
        1: FaultType.HIGH_LATENCY,
        2: FaultType.PACKET_LOSS,
        3: FaultType.THROUGHPUT_DEGRADATION,
        4: FaultType.NETWORK_CONGESTION,
        5: FaultType.DATA_CORRUPTION,
        6: FaultType.NODE_FAILURE,
    }

    def __init__(self):
        self.model = None
        self.scaler = None
        self._loaded = False
        self._load_model()

    def _resolve_path(self, path: str) -> str:
        """
        BUG FIX: Always resolve model paths to absolute paths.

        The original code used os.path.exists() on a relative path like
        '../ml_model/models/fault_classifier.pkl'.  This is resolved relative
        to the process CWD — which may not be the server/ directory if the
        server is launched from the project root or via a process manager.

        Resolving to absolute using os.path.abspath() fixes the lookup
        regardless of where the process is started from.
        """
        return os.path.abspath(path)

    def _load_model(self) -> None:
        # BUG FIX 1: resolve to absolute paths before existence checks
        model_path = self._resolve_path(settings.ML_MODEL_PATH)
        scaler_path = self._resolve_path(settings.ML_SCALER_PATH)

        logger.info("ML model path (resolved): %s", model_path)

        if not os.path.exists(model_path):
            logger.warning(
                "ML model not found at '%s' — inference disabled until trained. "
                "Run:  python ml_model/train.py",
                model_path,
            )
            return

        try:
            self.model = joblib.load(model_path)
            if os.path.exists(scaler_path):
                self.scaler = joblib.load(scaler_path)
                logger.info("Scaler loaded from '%s'", scaler_path)
            else:
                logger.info("No scaler found at '%s' — running unscaled.", scaler_path)
            self._loaded = True
            logger.info("ML model loaded successfully from '%s'", model_path)
        except Exception as e:
            logger.error("Failed to load ML model: %s", e)

    def reload(self) -> bool:
        """
        Hot-reload the model from disk (call after retraining).

        BUG FIX 2: Clear cached state before reloading so stale
        self._loaded=False from a previous failed load doesn't block
        the fresh attempt.
        """
        logger.info("Reloading ML model...")
        self._loaded = False
        self.model = None
        self.scaler = None
        self._load_model()
        logger.info("ML model reload result: ready=%s", self._loaded)
        return self._loaded

    @property
    def is_ready(self) -> bool:
        return self._loaded and self.model is not None

    def _extract_features(self, metrics: Dict[str, Any]) -> Optional[np.ndarray]:
        try:
            features = [
                float(metrics.get("latency_ms", 0.0)),
                float(metrics.get("packet_loss_rate", 0.0)),
                float(metrics.get("throughput_mbps", 0.0)),
                float(metrics.get("jitter_ms", 0.0)),
            ]
            return np.array(features).reshape(1, -1)
        except (TypeError, ValueError) as e:
            logger.warning("Feature extraction failed: %s", e)
            return None

    def predict(
        self, metrics: Dict[str, Any]
    ) -> Tuple[Optional[FaultType], Optional[float], Optional[Dict[str, float]]]:
        """
        Returns (fault_type, confidence, class_probabilities).
        All values are None if the model is not loaded.
        """
        if not self.is_ready:
            return None, None, None

        X = self._extract_features(metrics)
        if X is None:
            return None, None, None

        try:
            if self.scaler is not None:
                X = self.scaler.transform(X)

            pred_idx = int(self.model.predict(X)[0])
            proba = self.model.predict_proba(X)[0]
            confidence = float(proba[pred_idx])

            fault_type = self.LABEL_MAP.get(pred_idx, FaultType.NORMAL)

            # Build probability dict for all classes
            class_probs = {
                self.LABEL_MAP[i].value: float(proba[i])
                for i in range(len(proba))
                if i in self.LABEL_MAP
            }

            return fault_type, confidence, class_probs

        except Exception as e:
            logger.error("ML inference error: %s", e)
            return None, None, None

    def predict_as_dict(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        fault_type, confidence, class_probs = self.predict(metrics)

        if fault_type is None:
            return {
                "ml_available": False,
                "fault_type": None,
                "confidence": None,
                "class_probabilities": None,
            }

        severity_map = {
            FaultType.NORMAL: Severity.LOW,
            FaultType.HIGH_LATENCY: Severity.MEDIUM,
            FaultType.PACKET_LOSS: Severity.MEDIUM,
            FaultType.THROUGHPUT_DEGRADATION: Severity.MEDIUM,
            FaultType.NETWORK_CONGESTION: Severity.CRITICAL,
            FaultType.DATA_CORRUPTION: Severity.CRITICAL,
            FaultType.NODE_FAILURE: Severity.CRITICAL,
        }

        return {
            "ml_available": True,
            "fault_type": fault_type.value,
            "severity": severity_map.get(fault_type, Severity.LOW).value,
            "confidence": round(confidence, 4),
            "class_probabilities": {k: round(v, 4) for k, v in (class_probs or {}).items()},
        }


# ---------------------------------------------------------------------------
# Singleton — instantiated at import time.
#
# BUG FIX 3: If the model doesn't exist at startup (e.g. server started before
# training finished), the singleton silently sets _loaded=False.  The server
# must call ml_engine.reload() after training completes.
# The /api/ml/reload endpoint does exactly this, but previously it was never
# called automatically.  The lifespan in main.py now attempts an auto-reload
# after confirming the file exists, so a pre-trained model is always picked up.
# ---------------------------------------------------------------------------
ml_engine = MLInferenceEngine()
