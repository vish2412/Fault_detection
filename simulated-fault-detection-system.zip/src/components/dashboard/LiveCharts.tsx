import {
  LineChart, Line, AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import { useSimulationStore } from '../../store/simulationStore';
import { GlassPanel } from '../ui/GlassPanel';
import { useMemo } from 'react';

interface TooltipPayload {
  color: string;
  name: string;
  value: number;
}

function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: TooltipPayload[]; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-slate-900/95 border border-slate-700 rounded-lg p-2 text-xs font-mono">
      <p className="text-slate-400 mb-1">{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color }}>{p.name}: {typeof p.value === 'number' ? p.value.toFixed(2) : p.value}</p>
      ))}
    </div>
  );
}

// Multi-node latency chart
function LatencyChart() {
  const nodes = useSimulationStore(s => s.nodes);

  const data = useMemo(() => {
    const coreNodes = nodes.filter(n => n.type === 'core' || n.type === 'gateway').slice(0, 4);
    const maxLen = Math.max(...coreNodes.map(n => n.metrics.length));
    return Array.from({ length: Math.min(maxLen, 30) }, (_, i) => {
      const idx = Math.max(0, (coreNodes[0]?.metrics.length || 0) - 30 + i);
      const point: Record<string, number | string> = {
        t: `T-${30 - i}`,
      };
      coreNodes.forEach(node => {
        const m = node.metrics[idx];
        if (m) point[node.name] = parseFloat(m.latency.toFixed(1));
      });
      return point;
    });
  }, [nodes]);

  const colors = ['#60a5fa', '#34d399', '#f59e0b', '#a78bfa'];
  const coreNodes = nodes.filter(n => n.type === 'core' || n.type === 'gateway').slice(0, 4);

  return (
    <GlassPanel title="Latency Monitor" titleIcon="⚡" className="col-span-2">
      <div className="text-xs text-slate-500 font-mono mb-2">RTT (ms) — Core & Gateway Nodes</div>
      <ResponsiveContainer width="100%" height={180}>
        <LineChart data={data} margin={{ top: 5, right: 10, bottom: 0, left: -10 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
          <XAxis dataKey="t" tick={{ fontSize: 9, fill: '#64748b', fontFamily: 'JetBrains Mono' }} interval={4} />
          <YAxis tick={{ fontSize: 9, fill: '#64748b', fontFamily: 'JetBrains Mono' }} unit="ms" />
          <Tooltip content={<CustomTooltip />} />
          <Legend wrapperStyle={{ fontSize: '9px', fontFamily: 'JetBrains Mono' }} />
          {coreNodes.map((n, i) => (
            <Line key={n.id} type="monotone" dataKey={n.name} stroke={colors[i]} dot={false} strokeWidth={1.5} isAnimationActive={false} />
          ))}
          {/* Threshold line */}
          <Line type="monotone" dataKey={() => 200} stroke="#ef4444" strokeDasharray="4 4" dot={false} strokeWidth={1} name="threshold" isAnimationActive={false} />
        </LineChart>
      </ResponsiveContainer>
    </GlassPanel>
  );
}

// Packet loss area chart
function PacketLossChart() {
  const nodes = useSimulationStore(s => s.nodes);

  const data = useMemo(() => {
    const edgeNodes = nodes.filter(n => n.type === 'edge').slice(0, 3);
    const maxLen = Math.max(...edgeNodes.map(n => n.metrics.length), 0);
    return Array.from({ length: Math.min(maxLen, 30) }, (_, i) => {
      const idx = Math.max(0, (edgeNodes[0]?.metrics.length || 0) - 30 + i);
      let totalLoss = 0;
      let count = 0;
      edgeNodes.forEach(node => {
        const m = node.metrics[idx];
        if (m) { totalLoss += m.packetLoss; count++; }
      });
      return {
        t: `T-${30 - i}`,
        loss: count > 0 ? parseFloat((totalLoss / count).toFixed(2)) : 0,
        threshold: 10,
      };
    });
  }, [nodes]);

  return (
    <GlassPanel title="Packet Loss" titleIcon="📦" className="col-span-1">
      <div className="text-xs text-slate-500 font-mono mb-2">Avg % — Edge Nodes</div>
      <ResponsiveContainer width="100%" height={180}>
        <AreaChart data={data} margin={{ top: 5, right: 10, bottom: 0, left: -10 }}>
          <defs>
            <linearGradient id="lossGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#ef4444" stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
          <XAxis dataKey="t" tick={{ fontSize: 9, fill: '#64748b', fontFamily: 'JetBrains Mono' }} interval={4} />
          <YAxis tick={{ fontSize: 9, fill: '#64748b', fontFamily: 'JetBrains Mono' }} unit="%" />
          <Tooltip content={<CustomTooltip />} />
          <Area type="monotone" dataKey="loss" stroke="#ef4444" fill="url(#lossGrad)" strokeWidth={2} isAnimationActive={false} />
          <Line type="monotone" dataKey="threshold" stroke="#f59e0b" strokeDasharray="4 4" dot={false} strokeWidth={1} isAnimationActive={false} />
        </AreaChart>
      </ResponsiveContainer>
    </GlassPanel>
  );
}

// Throughput bar chart
function ThroughputChart() {
  const nodes = useSimulationStore(s => s.nodes);

  const data = useMemo(() => {
    return nodes.slice(0, 8).map(n => ({
      name: n.name.replace('ENDPOINT-', 'EP-').replace('CORE-', 'CR-').replace('EDGE-', 'ED-').replace('GW-', 'GW-'),
      throughput: parseFloat(n.currentMetrics.throughput.toFixed(1)),
      status: n.status,
    }));
  }, [nodes]);

  return (
    <GlassPanel title="Throughput" titleIcon="🌐" className="col-span-1">
      <div className="text-xs text-slate-500 font-mono mb-2">Mbps — Per Node</div>
      <ResponsiveContainer width="100%" height={180}>
        <BarChart data={data} margin={{ top: 5, right: 10, bottom: 20, left: -10 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
          <XAxis dataKey="name" tick={{ fontSize: 8, fill: '#64748b', fontFamily: 'JetBrains Mono' }} angle={-35} textAnchor="end" />
          <YAxis tick={{ fontSize: 9, fill: '#64748b', fontFamily: 'JetBrains Mono' }} unit="M" />
          <Tooltip content={<CustomTooltip />} />
          <Bar dataKey="throughput" radius={[3, 3, 0, 0]} isAnimationActive={false}
            fill="#60a5fa"
            // Dynamic color per bar
            label={false}
          />
        </BarChart>
      </ResponsiveContainer>
    </GlassPanel>
  );
}

// Jitter line chart
function JitterChart() {
  const nodes = useSimulationStore(s => s.nodes);

  const data = useMemo(() => {
    const allNodes = nodes.slice(0, 3);
    const maxLen = Math.max(...allNodes.map(n => n.metrics.length), 0);
    return Array.from({ length: Math.min(maxLen, 30) }, (_, i) => {
      const idx = Math.max(0, (allNodes[0]?.metrics.length || 0) - 30 + i);
      const point: Record<string, number | string> = { t: `T-${30 - i}` };
      allNodes.forEach(node => {
        const m = node.metrics[idx];
        if (m) point[node.name] = parseFloat(m.jitter.toFixed(1));
      });
      return point;
    });
  }, [nodes]);

  const colors = ['#a78bfa', '#34d399', '#fb923c'];
  const displayNodes = nodes.slice(0, 3);

  return (
    <GlassPanel title="Jitter Analysis" titleIcon="〰️" className="col-span-1">
      <div className="text-xs text-slate-500 font-mono mb-2">ms variance — RTT instability</div>
      <ResponsiveContainer width="100%" height={180}>
        <LineChart data={data} margin={{ top: 5, right: 10, bottom: 0, left: -10 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
          <XAxis dataKey="t" tick={{ fontSize: 9, fill: '#64748b', fontFamily: 'JetBrains Mono' }} interval={4} />
          <YAxis tick={{ fontSize: 9, fill: '#64748b', fontFamily: 'JetBrains Mono' }} unit="ms" />
          <Tooltip content={<CustomTooltip />} />
          <Legend wrapperStyle={{ fontSize: '9px', fontFamily: 'JetBrains Mono' }} />
          {displayNodes.map((n, i) => (
            <Line key={n.id} type="monotone" dataKey={n.name} stroke={colors[i]} dot={false} strokeWidth={1.5} isAnimationActive={false} />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </GlassPanel>
  );
}

// CPU/Memory area chart
function ResourceChart() {
  const nodes = useSimulationStore(s => s.nodes);

  const data = useMemo(() => {
    const coreNode = nodes.find(n => n.type === 'core');
    if (!coreNode) return [];
    return coreNode.metrics.slice(-30).map((m, i) => ({
      t: `T-${30 - i}`,
      cpu: parseFloat(m.cpuUsage.toFixed(1)),
      memory: parseFloat(m.memoryUsage.toFixed(1)),
    }));
  }, [nodes]);

  return (
    <GlassPanel title="System Resources" titleIcon="💻" className="col-span-1">
      <div className="text-xs text-slate-500 font-mono mb-2">CPU & Memory % — CORE-ALPHA</div>
      <ResponsiveContainer width="100%" height={180}>
        <AreaChart data={data} margin={{ top: 5, right: 10, bottom: 0, left: -10 }}>
          <defs>
            <linearGradient id="cpuGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#60a5fa" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#60a5fa" stopOpacity={0.02} />
            </linearGradient>
            <linearGradient id="memGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#a78bfa" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#a78bfa" stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
          <XAxis dataKey="t" tick={{ fontSize: 9, fill: '#64748b', fontFamily: 'JetBrains Mono' }} interval={4} />
          <YAxis tick={{ fontSize: 9, fill: '#64748b', fontFamily: 'JetBrains Mono' }} unit="%" domain={[0, 100]} />
          <Tooltip content={<CustomTooltip />} />
          <Legend wrapperStyle={{ fontSize: '9px', fontFamily: 'JetBrains Mono' }} />
          <Area type="monotone" dataKey="cpu" stroke="#60a5fa" fill="url(#cpuGrad)" strokeWidth={2} isAnimationActive={false} />
          <Area type="monotone" dataKey="memory" stroke="#a78bfa" fill="url(#memGrad)" strokeWidth={2} isAnimationActive={false} />
        </AreaChart>
      </ResponsiveContainer>
    </GlassPanel>
  );
}

export function LiveCharts() {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      <LatencyChart />
      <PacketLossChart />
      <ThroughputChart />
      <JitterChart />
      <ResourceChart />
    </div>
  );
}
