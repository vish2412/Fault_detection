// src/components/MLPanel.jsx
import React from 'react'

const CLASS_COLORS = {
  NORMAL:                 'var(--green)',
  HIGH_LATENCY:           'var(--cyan)',
  PACKET_LOSS:            'var(--amber)',
  THROUGHPUT_DEGRADATION: '#b388ff',
  NETWORK_CONGESTION:     'var(--red)',
  DATA_CORRUPTION:        '#ff6e40',
  NODE_FAILURE:           'var(--red)',
}

const CLASS_ICONS = {
  NORMAL:                 '✅',
  HIGH_LATENCY:           '⏱',
  PACKET_LOSS:            '📉',
  THROUGHPUT_DEGRADATION: '🐢',
  NETWORK_CONGESTION:     '🌐',
  DATA_CORRUPTION:        '☠',
  NODE_FAILURE:           '💀',
}

function ConfidenceBar({ label, value, highlight }) {
  const pct = Math.round((value || 0) * 100)
  const color = CLASS_COLORS[label] || 'var(--muted)'
  return (
    <div className={`space-y-0.5 ${highlight ? 'opacity-100' : 'opacity-50'}`}>
      <div className="flex justify-between items-center text-[10px]">
        <span className="flex items-center gap-1.5">
          <span>{CLASS_ICONS[label] || '▸'}</span>
          <span className={highlight ? 'text-cyber-text font-bold' : 'text-cyber-muted'}>
            {label}
          </span>
        </span>
        <span className="font-bold" style={{ color }}>{pct}%</span>
      </div>
      <div className="h-1.5 bg-cyber-border rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${pct}%`, background: color, boxShadow: highlight ? `0 0 6px ${color}` : 'none' }}
        />
      </div>
    </div>
  )
}

export default function MLPanel({ mlLatest, alertFeed }) {
  const recentMLAlerts = alertFeed
    .filter(a => a.ml?.ml_available)
    .slice(0, 5)

  return (
    <div className="panel h-full flex flex-col">
      <div className="panel-header">
        <span className="dot dot-amber animate-pulse-slow" />
        AI FAULT CLASSIFIER
        <span className="ml-auto text-[9px] font-mono text-cyber-muted">
          RandomForest · 7 classes
        </span>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-4">

        {/* ── Current Prediction ── */}
        {mlLatest ? (
          <div>
            <div className="text-[9px] text-cyber-muted mb-2 tracking-widest uppercase">
              Latest Prediction — {mlLatest.node_id}
            </div>

            {/* Big result */}
            <div className="panel p-3 mb-3 border-cyber-amber/30"
                 style={{ background: 'rgba(255,171,0,0.05)' }}>
              <div className="flex items-center gap-3">
                <span className="text-3xl leading-none">
                  {CLASS_ICONS[mlLatest.fault_type] || '?'}
                </span>
                <div>
                  <div className="text-[10px] text-cyber-muted">PREDICTED FAULT</div>
                  <div className="font-display font-bold text-[15px] glow-amber leading-tight">
                    {mlLatest.fault_type}
                  </div>
                </div>
                <div className="ml-auto text-right">
                  <div className="text-[9px] text-cyber-muted">CONFIDENCE</div>
                  <div className="text-[22px] font-bold glow-cyan leading-none">
                    {((mlLatest.confidence || 0) * 100).toFixed(1)}
                    <span className="text-[12px] text-cyber-muted">%</span>
                  </div>
                </div>
              </div>

              {/* Confidence bar for winning class */}
              <div className="mt-3">
                <div className="h-2 bg-cyber-border rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-700"
                    style={{
                      width: `${((mlLatest.confidence || 0) * 100).toFixed(0)}%`,
                      background: CLASS_COLORS[mlLatest.fault_type] || 'var(--cyan)',
                      boxShadow: `0 0 8px ${CLASS_COLORS[mlLatest.fault_type] || 'var(--cyan)'}`,
                    }}
                  />
                </div>
              </div>
            </div>

            {/* All class probabilities */}
            {mlLatest.class_probabilities && (
              <div>
                <div className="text-[9px] text-cyber-muted mb-2 tracking-widest uppercase">
                  Class Probabilities
                </div>
                <div className="space-y-2">
                  {Object.entries(mlLatest.class_probabilities)
                    .sort(([, a], [, b]) => b - a)
                    .map(([label, val]) => (
                      <ConfidenceBar
                        key={label}
                        label={label}
                        value={val}
                        highlight={label === mlLatest.fault_type}
                      />
                    ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-32 text-cyber-muted text-[11px]">
            <div className="text-2xl mb-2">🤖</div>
            <div>
              {mlLatest === null
                ? 'Waiting for ML predictions...'
                : 'ML model not loaded — run train.py first'}
            </div>
          </div>
        )}

        {/* ── Recent ML-flagged alerts ── */}
        {recentMLAlerts.length > 0 && (
          <div>
            <hr className="hr mb-3" />
            <div className="text-[9px] text-cyber-muted mb-2 tracking-widest uppercase">
              Recent AI Detections
            </div>
            <div className="space-y-1.5">
              {recentMLAlerts.map((a, i) => (
                <div key={i} className="panel px-3 py-1.5 flex items-center gap-2 text-[10px]">
                  <span>{CLASS_ICONS[a.ml.fault_type] || '▸'}</span>
                  <span className="text-cyber-amber font-bold flex-1">{a.ml.fault_type}</span>
                  <span className="text-cyber-muted">{a.node_id}</span>
                  <span className="text-cyber-text">
                    {((a.ml.confidence || 0) * 100).toFixed(0)}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
