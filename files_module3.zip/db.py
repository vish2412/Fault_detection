"""
database/db.py
==============
Async SQLAlchemy engine, session factory, and database initialisation.

Supports:
  - SQLite (default, via aiosqlite) — zero-configuration development
  - PostgreSQL (via asyncpg)        — production

Switch by setting the DATABASE_URL environment variable:
  SQLite    : sqlite+aiosqlite:///./network_monitor.db   (default)
  PostgreSQL: postgresql+asyncpg://user:pass@host/dbname
"""

import logging
import os
from typing import AsyncGenerator

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Base class for all ORM models
# ---------------------------------------------------------------------------


class Base(DeclarativeBase):
    """Shared declarative base.  All models must inherit from this class."""
    pass


# ---------------------------------------------------------------------------
# Engine — created once at module import time
# ---------------------------------------------------------------------------

DATABASE_URL: str = os.getenv(
    "DATABASE_URL",
    "sqlite+aiosqlite:///./network_monitor.db",
)

# Engine kwargs differ between SQLite and PostgreSQL
_is_sqlite = DATABASE_URL.startswith("sqlite")

_engine_kwargs: dict = {
    "echo": os.getenv("DB_ECHO", "false").lower() == "true",
}

if _is_sqlite:
    # SQLite needs check_same_thread disabled and benefits from WAL mode
    _engine_kwargs["connect_args"] = {"check_same_thread": False}
else:
    # PostgreSQL — tune pool for production
    _engine_kwargs["pool_size"] = int(os.getenv("DB_POOL_SIZE", "10"))
    _engine_kwargs["max_overflow"] = int(os.getenv("DB_MAX_OVERFLOW", "20"))
    _engine_kwargs["pool_pre_ping"] = True

engine: AsyncEngine = create_async_engine(DATABASE_URL, **_engine_kwargs)

# ---------------------------------------------------------------------------
# Session factory
# ---------------------------------------------------------------------------

AsyncSessionLocal: async_sessionmaker[AsyncSession] = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False,
)


# ---------------------------------------------------------------------------
# FastAPI dependency — yields a DB session per request
# ---------------------------------------------------------------------------


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Yield an :class:`AsyncSession` for the duration of a single request.

    Usage::

        @router.get("/example")
        async def endpoint(db: AsyncSession = Depends(get_db)):
            result = await db.execute(select(SomeModel))
            ...
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# ---------------------------------------------------------------------------
# Database initialisation
# ---------------------------------------------------------------------------


async def init_db() -> None:
    """
    Create all tables that do not yet exist.

    Called once during FastAPI application startup.  Safe to call multiple
    times (``checkfirst=True`` is the default for ``create_all``).

    For SQLite the WAL journal mode is enabled after table creation so that
    concurrent readers do not block the writer.
    """
    # Import models here so that they are registered on Base.metadata
    # before create_all() is invoked.
    from database import models  # noqa: F401 — side-effect import

    logger.info("Initialising database: %s", DATABASE_URL)

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    if _is_sqlite:
        await _enable_sqlite_wal()

    logger.info("Database tables ready.")


async def _enable_sqlite_wal() -> None:
    """Enable Write-Ahead Logging on SQLite for better concurrency."""
    from sqlalchemy import text

    async with AsyncSessionLocal() as session:
        await session.execute(text("PRAGMA journal_mode=WAL;"))
        await session.execute(text("PRAGMA synchronous=NORMAL;"))
        await session.execute(text("PRAGMA foreign_keys=ON;"))
        await session.commit()
    logger.debug("SQLite WAL mode enabled.")


# ---------------------------------------------------------------------------
# Teardown helper (optional — called during shutdown)
# ---------------------------------------------------------------------------


async def close_db() -> None:
    """Dispose the engine connection pool.  Call during application shutdown."""
    await engine.dispose()
    logger.info("Database engine disposed.")
