import { motion, AnimatePresence } from 'framer-motion';
import { useSimulationStore } from '../../store/simulationStore';
import type { ScenarioMode } from '../../simulation/types';
import { useState } from 'react';

const SCENARIOS: { mode: ScenarioMode; label: string; icon: string; desc: string; color: string }[] = [
  { mode: 'normal',                label: 'Normal',            icon: '✅', desc: 'Baseline operation with low fault rate',      color: 'border-emerald-500/30 hover:border-emerald-500/60' },
  { mode: 'network_outage',        label: 'Network Outage',    icon: '💀', desc: 'Multiple node failures, high packet loss',    color: 'border-red-500/30 hover:border-red-500/60' },
  { mode: 'ddos_attack',           label: 'DDoS Attack',       icon: '🌊', desc: 'CPU overload, latency spikes, mass loss',     color: 'border-orange-500/30 hover:border-orange-500/60' },
  { mode: 'node_cascade_failure',  label: 'Cascade Failure',   icon: '🔗', desc: 'Chain reaction of node failures',             color: 'border-amber-500/30 hover:border-amber-500/60' },
  { mode: 'high_congestion',       label: 'High Congestion',   icon: '📡', desc: 'Throughput collapse + extreme latency',       color: 'border-blue-500/30 hover:border-blue-500/60' },
  { mode: 'data_corruption_wave',  label: 'Corruption Wave',   icon: '🔴', desc: 'Mass data corruption events across nodes',   color: 'border-violet-500/30 hover:border-violet-500/60' },
];

export function SimulationControls() {
  const {
    isRunning, startSimulation, stopSimulation,
    config, setScenarioMode, setFaultFrequency,
    systemStats, tickCount,
  } = useSimulationStore();

  const [expanded, setExpanded] = useState(true);

  return (
    <div className="rounded-2xl border border-slate-700/60 bg-slate-900/80 backdrop-blur-md">
      {/* Header */}
      <div
        className="px-5 py-3 border-b border-slate-700/50 flex items-center justify-between cursor-pointer"
        onClick={() => setExpanded(e => !e)}
      >
        <div className="flex items-center gap-2">
          <span className="text-slate-400">⚙️</span>
          <h3 className="text-sm font-semibold text-slate-200 font-mono uppercase tracking-wide">Simulation Control</h3>
          <span className="text-xs font-mono text-slate-500">Tick #{tickCount}</span>
        </div>
        <div className="flex items-center gap-3">
          {/* Live indicator */}
          {isRunning && (
            <motion.div
              className="flex items-center gap-1.5 text-xs font-mono text-emerald-400"
              animate={{ opacity: [1, 0.5, 1] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              LIVE
            </motion.div>
          )}
          <span className="text-slate-600 text-sm">{expanded ? '▲' : '▼'}</span>
        </div>
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="p-4 space-y-4">
              {/* Start/Stop */}
              <div className="flex gap-3">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={isRunning ? stopSimulation : startSimulation}
                  className={`flex-1 py-2.5 rounded-xl font-mono font-bold text-sm transition-all ${
                    isRunning
                      ? 'bg-red-500/20 border border-red-500/40 text-red-400 hover:bg-red-500/30'
                      : 'bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/30'
                  }`}
                >
                  {isRunning ? '⏹ Stop Simulation' : '▶ Start Simulation'}
                </motion.button>
              </div>

              {/* System stats bar */}
              <div className="grid grid-cols-3 gap-2 text-xs font-mono">
                <div className="bg-slate-800/60 rounded-lg px-3 py-2 text-center">
                  <p className="text-emerald-400 font-bold">{systemStats.onlineNodes}</p>
                  <p className="text-slate-600">Online</p>
                </div>
                <div className="bg-slate-800/60 rounded-lg px-3 py-2 text-center">
                  <p className="text-amber-400 font-bold">{systemStats.activeFaults}</p>
                  <p className="text-slate-600">Faults</p>
                </div>
                <div className="bg-slate-800/60 rounded-lg px-3 py-2 text-center">
                  <p className="text-red-400 font-bold">{systemStats.offlineNodes}</p>
                  <p className="text-slate-600">Offline</p>
                </div>
              </div>

              {/* Fault Frequency slider */}
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-xs font-mono text-slate-400">Fault Frequency</span>
                  <span className="text-xs font-mono text-amber-400">{(config.faultFrequency * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={config.faultFrequency * 100}
                  onChange={e => setFaultFrequency(Number(e.target.value) / 100)}
                  className="w-full accent-amber-500 h-1.5 cursor-pointer"
                />
                <div className="flex justify-between text-xs font-mono text-slate-600 mt-1">
                  <span>0% (Stable)</span>
                  <span>100% (Chaos)</span>
                </div>
              </div>

              {/* Scenario Selector */}
              <div>
                <p className="text-xs font-mono text-slate-400 mb-2 uppercase">Scenario Mode</p>
                <div className="grid grid-cols-2 gap-2">
                  {SCENARIOS.map(s => (
                    <motion.button
                      key={s.mode}
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                      onClick={() => setScenarioMode(s.mode)}
                      className={`
                        text-left p-2.5 rounded-lg border transition-all text-xs
                        ${config.scenarioMode === s.mode
                          ? 'bg-blue-500/20 border-blue-500/60 ring-1 ring-blue-500/40'
                          : `bg-slate-800/40 ${s.color}`
                        }
                      `}
                    >
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <span>{s.icon}</span>
                        <span className={`font-bold font-mono ${config.scenarioMode === s.mode ? 'text-blue-300' : 'text-slate-300'}`}>{s.label}</span>
                      </div>
                      <p className="text-slate-500 font-mono leading-tight">{s.desc}</p>
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Active scenario badge */}
              {config.scenarioMode !== 'normal' && (
                <motion.div
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 rounded-lg px-3 py-2"
                >
                  <motion.span
                    animate={{ opacity: [1, 0.3, 1] }}
                    transition={{ duration: 0.8, repeat: Infinity }}
                    className="text-amber-400"
                  >⚠</motion.span>
                  <span className="text-xs font-mono text-amber-300">
                    SCENARIO ACTIVE: {SCENARIOS.find(s => s.mode === config.scenarioMode)?.label.toUpperCase()}
                  </span>
                </motion.div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
