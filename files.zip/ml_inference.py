import logging
import os
from typing import Any, Dict, Optional, Tuple

import joblib
import numpy as np

from config import get_settings
from fault_detector import FaultType, Severity

logger = logging.getLogger(__name__)
settings = get_settings()


class MLInferenceEngine:
    """
    Loads a pre-trained RandomForestClassifier and runs inference
    on incoming metric payloads. Falls back gracefully if the model
    file is not yet available.
    """

    FEATURE_COLUMNS = ["latency_ms", "packet_loss_rate", "throughput_mbps", "jitter_ms"]

    # Maps classifier label indices back to FaultType
    LABEL_MAP: Dict[int, FaultType] = {
        0: FaultType.NORMAL,
        1: FaultType.HIGH_LATENCY,
        2: FaultType.PACKET_LOSS,
        3: FaultType.THROUGHPUT_DEGRADATION,
        4: FaultType.NETWORK_CONGESTION,
        5: FaultType.DATA_CORRUPTION,
        6: FaultType.NODE_FAILURE,
    }

    def __init__(self):
        self.model = None
        self.scaler = None
        self._loaded = False
        self._load_model()

    def _load_model(self) -> None:
        model_path = settings.ML_MODEL_PATH
        scaler_path = settings.ML_SCALER_PATH

        if not os.path.exists(model_path):
            logger.warning(
                "ML model not found at %s — inference will be skipped until model is trained.",
                model_path,
            )
            return

        try:
            self.model = joblib.load(model_path)
            if os.path.exists(scaler_path):
                self.scaler = joblib.load(scaler_path)
            self._loaded = True
            logger.info("ML model loaded from %s", model_path)
        except Exception as e:
            logger.error("Failed to load ML model: %s", e)

    def reload(self) -> bool:
        """Hot-reload the model (call after retraining)."""
        self._loaded = False
        self.model = None
        self.scaler = None
        self._load_model()
        return self._loaded

    @property
    def is_ready(self) -> bool:
        return self._loaded and self.model is not None

    def _extract_features(self, metrics: Dict[str, Any]) -> Optional[np.ndarray]:
        try:
            features = [
                float(metrics.get("latency_ms", 0.0)),
                float(metrics.get("packet_loss_rate", 0.0)),
                float(metrics.get("throughput_mbps", 0.0)),
                float(metrics.get("jitter_ms", 0.0)),
            ]
            return np.array(features).reshape(1, -1)
        except (TypeError, ValueError) as e:
            logger.warning("Feature extraction failed: %s", e)
            return None

    def predict(
        self, metrics: Dict[str, Any]
    ) -> Tuple[Optional[FaultType], Optional[float], Optional[Dict[str, float]]]:
        """
        Returns (fault_type, confidence, class_probabilities).
        All values are None if the model is not loaded.
        """
        if not self.is_ready:
            return None, None, None

        X = self._extract_features(metrics)
        if X is None:
            return None, None, None

        try:
            if self.scaler is not None:
                X = self.scaler.transform(X)

            pred_idx = int(self.model.predict(X)[0])
            proba = self.model.predict_proba(X)[0]
            confidence = float(proba[pred_idx])

            fault_type = self.LABEL_MAP.get(pred_idx, FaultType.NORMAL)

            # Build probability dict for all classes
            class_probs = {
                self.LABEL_MAP[i].value: float(proba[i])
                for i in range(len(proba))
                if i in self.LABEL_MAP
            }

            return fault_type, confidence, class_probs

        except Exception as e:
            logger.error("ML inference error: %s", e)
            return None, None, None

    def predict_as_dict(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        fault_type, confidence, class_probs = self.predict(metrics)

        if fault_type is None:
            return {
                "ml_available": False,
                "fault_type": None,
                "confidence": None,
                "class_probabilities": None,
            }

        severity_map = {
            FaultType.NORMAL: Severity.LOW,
            FaultType.HIGH_LATENCY: Severity.MEDIUM,
            FaultType.PACKET_LOSS: Severity.MEDIUM,
            FaultType.THROUGHPUT_DEGRADATION: Severity.MEDIUM,
            FaultType.NETWORK_CONGESTION: Severity.CRITICAL,
            FaultType.DATA_CORRUPTION: Severity.CRITICAL,
            FaultType.NODE_FAILURE: Severity.CRITICAL,
        }

        return {
            "ml_available": True,
            "fault_type": fault_type.value,
            "severity": severity_map.get(fault_type, Severity.LOW).value,
            "confidence": round(confidence, 4),
            "class_probabilities": {k: round(v, 4) for k, v in (class_probs or {}).items()},
        }


# Singleton
ml_engine = MLInferenceEngine()
