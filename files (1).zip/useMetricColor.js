/**
 * useMetricColor.js
 * -----------------
 * Pure utility — maps a metric name + value to a Tailwind colour class
 * and a hex colour string for use in Recharts.
 *
 * Thresholds sourced from CONFIG.THRESHOLDS (matches server/config.py).
 *
 * Usage:
 *   const { textClass, hexColor, label } = getMetricColor("latency_ms", 312);
 */

import CONFIG from "../config.js";

const T = CONFIG.THRESHOLDS;

/**
 * Returns colour information for a given metric value.
 *
 * @param {string} metric  — one of: latency_ms | packet_loss_rate | throughput_mbps | jitter_ms
 * @param {number} value
 * @returns {{ textClass: string, bgClass: string, hexColor: string, level: "normal"|"warn"|"critical" }}
 */
export function getMetricColor(metric, value) {
  if (value == null || isNaN(value)) {
    return { textClass: "text-slate-400", bgClass: "bg-slate-500/20", hexColor: "#64748b", level: "unknown" };
  }

  const thresh = T[metric];
  if (!thresh) {
    return { textClass: "text-slate-300", bgClass: "bg-slate-500/20", hexColor: "#94a3b8", level: "normal" };
  }

  // throughput: lower is worse (inverted thresholds)
  const isInverted = metric === "throughput_mbps";
  let level;

  if (isInverted) {
    level = value <= thresh.crit ? "critical"
          : value <= thresh.warn ? "warn"
          : "normal";
  } else {
    level = value >= thresh.crit ? "critical"
          : value >= thresh.warn ? "warn"
          : "normal";
  }

  switch (level) {
    case "critical":
      return { textClass: "text-red-400",     bgClass: "bg-red-500/15",     hexColor: "#f87171", level };
    case "warn":
      return { textClass: "text-amber-400",   bgClass: "bg-amber-500/15",   hexColor: "#fbbf24", level };
    default:
      return { textClass: "text-emerald-400", bgClass: "bg-emerald-500/15", hexColor: "#34d399", level };
  }
}

/**
 * Returns a Recharts-friendly stroke colour for a chart line.
 */
export function getChartColor(metric, latestValue) {
  return getMetricColor(metric, latestValue).hexColor;
}

/**
 * Severity → colour mapping for alert/fault indicators.
 */
export const SEVERITY_COLORS = {
  LOW:      { text: "text-blue-400",    bg: "bg-blue-500/15",    border: "border-blue-500/30",    hex: "#60a5fa" },
  MEDIUM:   { text: "text-amber-400",   bg: "bg-amber-500/15",   border: "border-amber-500/30",   hex: "#fbbf24" },
  CRITICAL: { text: "text-red-400",     bg: "bg-red-500/15",     border: "border-red-500/30",     hex: "#f87171" },
  NORMAL:   { text: "text-emerald-400", bg: "bg-emerald-500/15", border: "border-emerald-500/30", hex: "#34d399" },
};

export function getSeverityColor(severity) {
  return SEVERITY_COLORS[severity?.toUpperCase()] || SEVERITY_COLORS.LOW;
}

/**
 * Format metric value for display.
 */
export function formatMetric(metric, value) {
  if (value == null || isNaN(value)) return "—";
  switch (metric) {
    case "latency_ms":       return `${value.toFixed(1)} ms`;
    case "packet_loss_rate": return `${(value * 100).toFixed(2)}%`;
    case "throughput_mbps":  return `${value.toFixed(1)} Mbps`;
    case "jitter_ms":        return `${value.toFixed(1)} ms`;
    default:                 return String(value);
  }
}
