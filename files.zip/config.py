import os
from functools import lru_cache


class Settings:
    APP_NAME: str = "AI Network Fault Detection System"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = os.getenv("DEBUG", "false").lower() == "true"

    # Database
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL", "sqlite+aiosqlite:///./network_monitor.db"
    )

    # Security
    SECRET_KEY: str = os.getenv("SECRET_KEY", "change-me-in-production-secret-key")
    VALID_API_KEYS: list = ["dev-key-1234", "node-key-5678", "dashboard-key-9999"]

    # WebSocket
    WS_HEARTBEAT_TIMEOUT: int = 5        # seconds before node marked offline
    WS_MAX_CONNECTIONS: int = 200

    # Fault thresholds
    LATENCY_THRESHOLD_MS: float = float(os.getenv("LATENCY_THRESHOLD_MS", "200.0"))
    PACKET_LOSS_THRESHOLD: float = float(os.getenv("PACKET_LOSS_THRESHOLD", "0.05"))   # 5%
    THROUGHPUT_MIN_MBPS: float = float(os.getenv("THROUGHPUT_MIN_MBPS", "1.0"))
    JITTER_THRESHOLD_MS: float = float(os.getenv("JITTER_THRESHOLD_MS", "50.0"))

    # ML
    ML_MODEL_PATH: str = os.getenv("ML_MODEL_PATH", "../ml_model/models/fault_classifier.pkl")
    ML_SCALER_PATH: str = os.getenv("ML_SCALER_PATH", "../ml_model/models/scaler.pkl")

    # File uploads
    UPLOAD_DIR: str = os.getenv("UPLOAD_DIR", "./uploads")

    # CORS
    CORS_ORIGINS: list = [
        "http://localhost:3000",
        "http://localhost:5173",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:5173",
        "*",
    ]


@lru_cache()
def get_settings() -> Settings:
    return Settings()
