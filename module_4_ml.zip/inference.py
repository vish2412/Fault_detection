"""
ml_model/inference.py
=====================
Standalone inference utility for the trained fault detection classifier.

Designed for two use-cases:
  1. CLI tool — feed raw metrics on the command line and print predictions.
  2. Import library — import ``predict()`` or ``FaultPredictor`` directly
     into any Python script without pulling in the full FastAPI server.

The backend server uses ``server/ml_inference.py`` (which wraps this logic
with server-specific config paths).  This module is kept intentionally
independent so it can be run, tested, and benchmarked in isolation.

Usage examples
--------------
# Single prediction:
    python inference.py \
        --latency 312.5 \
        --loss 0.02 \
        --throughput 45.2 \
        --jitter 8.1

# Batch prediction from a CSV file (columns: latency_ms,packet_loss_rate,throughput_mbps,jitter_ms):
    python inference.py --csv /path/to/metrics.csv

# Interactive REPL:
    python inference.py --interactive

# Import in code:
    from ml_model.inference import FaultPredictor
    predictor = FaultPredictor()
    result = predictor.predict_dict({"latency_ms": 312.5, "packet_loss_rate": 0.02,
                                     "throughput_mbps": 45.2, "jitter_ms": 8.1})
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import joblib
import numpy as np

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants (must stay in sync with train.py)
# ---------------------------------------------------------------------------

FAULT_CLASSES = [
    "NORMAL",
    "HIGH_LATENCY",
    "PACKET_LOSS",
    "THROUGHPUT_DEGRADATION",
    "NETWORK_CONGESTION",
    "DATA_CORRUPTION",
    "NODE_FAILURE",
]

FEATURE_COLUMNS = ["latency_ms", "packet_loss_rate", "throughput_mbps", "jitter_ms"]

SEVERITY_MAP: Dict[str, str] = {
    "NORMAL": "LOW",
    "HIGH_LATENCY": "MEDIUM",
    "PACKET_LOSS": "MEDIUM",
    "THROUGHPUT_DEGRADATION": "MEDIUM",
    "NETWORK_CONGESTION": "CRITICAL",
    "DATA_CORRUPTION": "CRITICAL",
    "NODE_FAILURE": "CRITICAL",
}

# Default paths (relative to this file's location)
_HERE = Path(__file__).parent
DEFAULT_MODEL_PATH = str(_HERE / "models" / "fault_classifier.pkl")
DEFAULT_SCALER_PATH = str(_HERE / "models" / "scaler.pkl")


# ---------------------------------------------------------------------------
# FaultPredictor — the main inference class
# ---------------------------------------------------------------------------


class FaultPredictor:
    """
    Loads the trained RandomForestClassifier and exposes prediction methods.

    Parameters
    ----------
    model_path : str
        Path to the serialised ``fault_classifier.pkl`` file.
    scaler_path : str
        Path to the serialised ``scaler.pkl`` file.  Silently skipped if the
        file does not exist (i.e., training was run with ``--no-scaler``).
    """

    def __init__(
        self,
        model_path: str = DEFAULT_MODEL_PATH,
        scaler_path: str = DEFAULT_SCALER_PATH,
    ) -> None:
        self._model = None
        self._scaler = None
        self._loaded = False
        self._model_path = model_path
        self._scaler_path = scaler_path
        self._load()

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    def _load(self) -> None:
        """Load model (and optional scaler) from disk."""
        if not os.path.exists(self._model_path):
            logger.warning(
                "Model file not found at '%s'.  "
                "Run 'python ml_model/train.py' first.",
                self._model_path,
            )
            return

        try:
            self._model = joblib.load(self._model_path)
            logger.info("Loaded model from '%s'", self._model_path)
        except Exception as exc:
            logger.error("Failed to load model: %s", exc)
            return

        if os.path.exists(self._scaler_path):
            try:
                self._scaler = joblib.load(self._scaler_path)
                logger.info("Loaded scaler from '%s'", self._scaler_path)
            except Exception as exc:
                logger.warning("Failed to load scaler: %s", exc)

        self._loaded = True

    def reload(self) -> bool:
        """
        Hot-reload model artefacts from disk.

        Returns ``True`` if the model loaded successfully.
        """
        self._model = None
        self._scaler = None
        self._loaded = False
        self._load()
        return self._loaded

    @property
    def is_ready(self) -> bool:
        """``True`` if the model is loaded and ready for inference."""
        return self._loaded and self._model is not None

    # ------------------------------------------------------------------
    # Feature extraction
    # ------------------------------------------------------------------

    def _extract_features(
        self, metrics: Dict[str, Any]
    ) -> Optional[np.ndarray]:
        """
        Convert a metrics dict to a (1, 4) numpy array.

        Missing keys default to 0.0.  Returns ``None`` on conversion error.
        """
        try:
            features = [
                float(metrics.get("latency_ms", 0.0)),
                float(metrics.get("packet_loss_rate", 0.0)),
                float(metrics.get("throughput_mbps", 0.0)),
                float(metrics.get("jitter_ms", 0.0)),
            ]
            arr = np.array(features, dtype=float).reshape(1, -1)

            # Basic range sanity checks — log a warning but don't reject
            if arr[0, 0] < 0:
                logger.warning("Negative latency_ms=%.2f clamped to 0", arr[0, 0])
                arr[0, 0] = 0.0
            if not (0.0 <= arr[0, 1] <= 1.0):
                logger.warning(
                    "packet_loss_rate=%.4f out of [0,1]; clamping.", arr[0, 1]
                )
                arr[0, 1] = float(np.clip(arr[0, 1], 0.0, 1.0))

            return arr
        except (TypeError, ValueError) as exc:
            logger.error("Feature extraction error: %s", exc)
            return None

    def _scale(self, X: np.ndarray) -> np.ndarray:
        """Apply scaler if available; return raw array otherwise."""
        if self._scaler is not None:
            return self._scaler.transform(X)
        return X

    # ------------------------------------------------------------------
    # Core prediction
    # ------------------------------------------------------------------

    def predict(
        self,
        metrics: Dict[str, Any],
    ) -> Tuple[Optional[str], Optional[float], Optional[Dict[str, float]]]:
        """
        Predict the fault type for a single metric sample.

        Parameters
        ----------
        metrics : dict
            Must contain keys: ``latency_ms``, ``packet_loss_rate``,
            ``throughput_mbps``, ``jitter_ms``.

        Returns
        -------
        fault_type : str or None
            Predicted fault class name (e.g. ``"HIGH_LATENCY"``).
        confidence : float or None
            Probability of the predicted class (0–1).
        class_probabilities : dict or None
            Mapping of each fault class name to its predicted probability.
        """
        if not self.is_ready:
            return None, None, None

        X = self._extract_features(metrics)
        if X is None:
            return None, None, None

        try:
            X_scaled = self._scale(X)
            pred_idx: int = int(self._model.predict(X_scaled)[0])
            proba: np.ndarray = self._model.predict_proba(X_scaled)[0]

            fault_type = FAULT_CLASSES[pred_idx]
            confidence = float(proba[pred_idx])

            class_probabilities = {
                cls: float(proba[i]) for i, cls in enumerate(FAULT_CLASSES)
            }

            return fault_type, confidence, class_probabilities

        except Exception as exc:
            logger.error("Inference error: %s", exc)
            return None, None, None

    def predict_dict(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """
        Convenience wrapper — returns a single dict suitable for JSON serialisation.

        Example return value::

            {
                "ml_available": true,
                "fault_type": "HIGH_LATENCY",
                "severity": "MEDIUM",
                "confidence": 0.9421,
                "class_probabilities": {
                    "NORMAL": 0.0312,
                    "HIGH_LATENCY": 0.9421,
                    ...
                }
            }
        """
        fault_type, confidence, class_probs = self.predict(metrics)

        if fault_type is None:
            return {
                "ml_available": False,
                "fault_type": None,
                "severity": None,
                "confidence": None,
                "class_probabilities": None,
            }

        return {
            "ml_available": True,
            "fault_type": fault_type,
            "severity": SEVERITY_MAP.get(fault_type, "LOW"),
            "confidence": round(confidence, 4),
            "class_probabilities": {
                k: round(v, 4) for k, v in class_probs.items()
            },
        }

    def predict_batch(
        self,
        metrics_list: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """
        Predict fault types for a list of metric dicts in a single model call.

        Significantly faster than calling ``predict_dict`` in a loop because
        the random forest evaluates all rows at once.

        Parameters
        ----------
        metrics_list : list of dict
            Each dict must have the four feature keys.

        Returns
        -------
        list of dict
            One result dict per input row, in the same order.
        """
        if not self.is_ready:
            return [
                {"ml_available": False, "fault_type": None, "severity": None,
                 "confidence": None, "class_probabilities": None}
                for _ in metrics_list
            ]

        # Build feature matrix — skip None rows
        X_rows, valid_indices = [], []
        for i, m in enumerate(metrics_list):
            x = self._extract_features(m)
            if x is not None:
                X_rows.append(x[0])
                valid_indices.append(i)

        # Prepare result placeholders
        results: List[Dict[str, Any]] = [
            {"ml_available": False, "fault_type": None, "severity": None,
             "confidence": None, "class_probabilities": None}
            for _ in metrics_list
        ]

        if not X_rows:
            return results

        try:
            X_matrix = np.vstack(X_rows)
            X_scaled = self._scale(X_matrix)

            pred_indices = self._model.predict(X_scaled).astype(int)
            all_probas = self._model.predict_proba(X_scaled)

            for batch_pos, orig_idx in enumerate(valid_indices):
                pred_idx = int(pred_indices[batch_pos])
                proba = all_probas[batch_pos]
                fault_type = FAULT_CLASSES[pred_idx]
                confidence = float(proba[pred_idx])
                class_probs = {
                    cls: round(float(proba[i]), 4)
                    for i, cls in enumerate(FAULT_CLASSES)
                }
                results[orig_idx] = {
                    "ml_available": True,
                    "fault_type": fault_type,
                    "severity": SEVERITY_MAP.get(fault_type, "LOW"),
                    "confidence": round(confidence, 4),
                    "class_probabilities": class_probs,
                }

        except Exception as exc:
            logger.error("Batch inference error: %s", exc)

        return results

    # ------------------------------------------------------------------
    # Model introspection
    # ------------------------------------------------------------------

    def model_info(self) -> Dict[str, Any]:
        """Return metadata about the loaded model."""
        if not self.is_ready:
            return {"loaded": False, "model_path": self._model_path}

        info: Dict[str, Any] = {
            "loaded": True,
            "model_path": self._model_path,
            "scaler_path": self._scaler_path if self._scaler else None,
            "n_estimators": getattr(self._model, "n_estimators", None),
            "n_classes": getattr(self._model, "n_classes_", None),
            "classes": FAULT_CLASSES,
            "features": FEATURE_COLUMNS,
            "oob_score": None,
        }

        if hasattr(self._model, "oob_score_"):
            info["oob_score"] = round(float(self._model.oob_score_), 6)

        if hasattr(self._model, "feature_importances_"):
            info["feature_importances"] = {
                col: round(float(imp), 6)
                for col, imp in zip(FEATURE_COLUMNS, self._model.feature_importances_)
            }

        return info


# ---------------------------------------------------------------------------
# Singleton instance (used by server/ml_inference.py as a fallback)
# ---------------------------------------------------------------------------

_predictor: Optional[FaultPredictor] = None


def get_predictor(
    model_path: str = DEFAULT_MODEL_PATH,
    scaler_path: str = DEFAULT_SCALER_PATH,
) -> FaultPredictor:
    """Return a module-level singleton ``FaultPredictor``, creating it if needed."""
    global _predictor
    if _predictor is None:
        _predictor = FaultPredictor(model_path=model_path, scaler_path=scaler_path)
    return _predictor


def predict(metrics: Dict[str, Any]) -> Dict[str, Any]:
    """
    Module-level convenience function.

    Equivalent to ``get_predictor().predict_dict(metrics)``.
    """
    return get_predictor().predict_dict(metrics)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _cli_single(args: argparse.Namespace, predictor: FaultPredictor) -> None:
    """Run a single prediction from CLI arguments."""
    metrics = {
        "latency_ms": args.latency,
        "packet_loss_rate": args.loss,
        "throughput_mbps": args.throughput,
        "jitter_ms": args.jitter,
    }
    logger.info("Input metrics: %s", metrics)
    result = predictor.predict_dict(metrics)
    print(json.dumps(result, indent=2))


def _cli_csv(args: argparse.Namespace, predictor: FaultPredictor) -> None:
    """Run batch predictions over a CSV file."""
    import csv

    csv_path = args.csv
    if not os.path.exists(csv_path):
        logger.error("CSV file not found: %s", csv_path)
        sys.exit(1)

    rows: List[Dict[str, Any]] = []
    with open(csv_path, newline="") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            rows.append({k: float(v) for k, v in row.items() if v.strip()})

    logger.info("Loaded %d rows from '%s'", len(rows), csv_path)
    results = predictor.predict_batch(rows)

    # Merge input + prediction for display
    output = []
    for row, res in zip(rows, results):
        output.append({**row, **res})

    print(json.dumps(output, indent=2))

    # Summary
    from collections import Counter
    counts = Counter(r["fault_type"] for r in results if r.get("fault_type"))
    print("\nPrediction summary:")
    for cls, cnt in sorted(counts.items(), key=lambda x: -x[1]):
        print(f"  {cls:<30} {cnt:>6} ({100*cnt/len(results):.1f}%)")


def _cli_interactive(predictor: FaultPredictor) -> None:
    """Simple REPL for manual testing."""
    print("AI Network Fault Detector — Interactive Mode")
    print("Enter metric values or 'q' to quit.\n")

    while True:
        try:
            raw = input("latency_ms [Enter to skip]: ").strip()
            if raw.lower() in ("q", "quit", "exit"):
                break
            latency = float(raw) if raw else 20.0

            raw = input("packet_loss_rate [0.0]: ").strip()
            loss = float(raw) if raw else 0.0

            raw = input("throughput_mbps [100.0]: ").strip()
            throughput = float(raw) if raw else 100.0

            raw = input("jitter_ms [5.0]: ").strip()
            jitter = float(raw) if raw else 5.0

        except (EOFError, KeyboardInterrupt):
            print("\nBye.")
            break
        except ValueError as exc:
            print(f"  Invalid input: {exc}\n")
            continue

        metrics = {
            "latency_ms": latency,
            "packet_loss_rate": loss,
            "throughput_mbps": throughput,
            "jitter_ms": jitter,
        }
        result = predictor.predict_dict(metrics)
        print(f"\n  Prediction : {result['fault_type']}")
        print(f"  Severity   : {result['severity']}")
        print(f"  Confidence : {result['confidence']}")
        print(f"  Probabilities:")
        if result.get("class_probabilities"):
            for cls, prob in sorted(
                result["class_probabilities"].items(), key=lambda x: -x[1]
            ):
                bar = "█" * int(prob * 30)
                print(f"    {cls:<30} {prob:.4f}  {bar}")
        print()


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Standalone inference utility for the network fault classifier.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument(
        "--model-path",
        default=DEFAULT_MODEL_PATH,
        help="Path to fault_classifier.pkl",
    )
    p.add_argument(
        "--scaler-path",
        default=DEFAULT_SCALER_PATH,
        help="Path to scaler.pkl",
    )

    mode = p.add_mutually_exclusive_group()
    mode.add_argument("--csv", metavar="PATH", help="Run batch predictions on a CSV file.")
    mode.add_argument("--interactive", action="store_true", help="Start interactive REPL.")
    mode.add_argument("--info", action="store_true", help="Print model info and exit.")

    # Single prediction flags (used when neither --csv nor --interactive)
    p.add_argument("--latency", type=float, default=20.0, metavar="MS", help="latency_ms")
    p.add_argument("--loss", type=float, default=0.0, metavar="RATE", help="packet_loss_rate [0–1]")
    p.add_argument("--throughput", type=float, default=100.0, metavar="MBPS", help="throughput_mbps")
    p.add_argument("--jitter", type=float, default=5.0, metavar="MS", help="jitter_ms")

    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()

    predictor = FaultPredictor(
        model_path=args.model_path,
        scaler_path=args.scaler_path,
    )

    if args.info:
        print(json.dumps(predictor.model_info(), indent=2))
    elif args.csv:
        _cli_csv(args, predictor)
    elif args.interactive:
        _cli_interactive(predictor)
    else:
        _cli_single(args, predictor)
