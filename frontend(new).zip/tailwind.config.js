/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        mono: ['JetBrains Mono', 'monospace'],
        display: ['Syne', 'sans-serif'],
      },
      colors: {
        cyber: {
          bg:      '#080c10',
          surface: '#0d1117',
          panel:   '#111820',
          border:  '#1e2d3d',
          cyan:    '#00e5ff',
          amber:   '#ffab00',
          green:   '#00e676',
          red:     '#ff1744',
          yellow:  '#ffd600',
          muted:   '#4a5568',
          text:    '#c9d1d9',
        },
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4,0,0.6,1) infinite',
        'blink':      'blink 1.2s step-end infinite',
        'scan':       'scan 4s linear infinite',
        'fadein':     'fadein 0.4s ease forwards',
        'slidein':    'slidein 0.35s ease forwards',
      },
      keyframes: {
        blink:   { '0%,100%': { opacity: 1 }, '50%': { opacity: 0 } },
        scan:    { '0%': { transform: 'translateY(-100%)' }, '100%': { transform: 'translateY(100vh)' } },
        fadein:  { from: { opacity: 0 }, to: { opacity: 1 } },
        slidein: { from: { opacity: 0, transform: 'translateY(8px)' }, to: { opacity: 1, transform: 'translateY(0)' } },
      },
    },
  },
  plugins: [],
}
