/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Brand palette
        brand: {
          50:  "#f0f4ff",
          100: "#e0e9ff",
          200: "#c7d7fe",
          300: "#a5b8fc",
          400: "#8193f8",
          500: "#6470f3",
          600: "#5054e7",
          700: "#4341cc",
          800: "#3837a4",
          900: "#323382",
          950: "#1e1d4c",
        },
        // Severity colours
        severity: {
          low:      "#3b82f6",   // blue-500
          medium:   "#f59e0b",   // amber-500
          critical: "#ef4444",   // red-500
          normal:   "#10b981",   // emerald-500
        },
        // Dark surface palette (dashboard background)
        surface: {
          900: "#0a0e1a",
          800: "#0f1526",
          700: "#161d35",
          600: "#1e2745",
          500: "#263054",
          400: "#334066",
        },
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "ui-monospace", "monospace"],
      },
      animation: {
        "pulse-slow":   "pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        "fade-in":      "fadeIn 0.3s ease-out",
        "slide-in-up":  "slideInUp 0.3s ease-out",
        "slide-in-right": "slideInRight 0.25s ease-out",
        "ping-once":    "ping 0.6s cubic-bezier(0, 0, 0.2, 1) 1",
      },
      keyframes: {
        fadeIn: {
          "0%":   { opacity: "0" },
          "100%": { opacity: "1" },
        },
        slideInUp: {
          "0%":   { transform: "translateY(12px)", opacity: "0" },
          "100%": { transform: "translateY(0)",    opacity: "1" },
        },
        slideInRight: {
          "0%":   { transform: "translateX(-12px)", opacity: "0" },
          "100%": { transform: "translateX(0)",     opacity: "1" },
        },
      },
      boxShadow: {
        "glow-blue":     "0 0 20px rgba(100, 112, 243, 0.35)",
        "glow-green":    "0 0 20px rgba(16, 185, 129, 0.35)",
        "glow-red":      "0 0 20px rgba(239, 68, 68, 0.35)",
        "glow-amber":    "0 0 20px rgba(245, 158, 11, 0.35)",
        "card":          "0 4px 24px rgba(0,0,0,0.4)",
        "card-hover":    "0 8px 32px rgba(0,0,0,0.55)",
      },
      backdropBlur: {
        xs: "2px",
      },
      screens: {
        "3xl": "1920px",
      },
    },
  },
  plugins: [],
};
