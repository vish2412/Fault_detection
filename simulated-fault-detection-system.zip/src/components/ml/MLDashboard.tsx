import { motion } from 'framer-motion';
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell,
  PieChart, Pie, Legend,
} from 'recharts';
import { useSimulationStore } from '../../store/simulationStore';
import { MODEL_METADATA, mlPredict } from '../../simulation/mlModel';
import { GlassPanel } from '../ui/GlassPanel';
import { useMemo } from 'react';

interface TooltipPayload {
  color: string;
  name: string;
  value: number;
}

function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: TooltipPayload[]; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-slate-900/95 border border-slate-700 rounded-lg p-2 text-xs font-mono">
      <p className="text-slate-400 mb-1">{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color }}>{p.name}: {typeof p.value === 'number' ? p.value.toFixed(3) : p.value}</p>
      ))}
    </div>
  );
}

export function MLDashboard() {
  const { nodes, allFaults } = useSimulationStore();

  // Compute live ML predictions for all nodes
  const predictions = useMemo(() => {
    return nodes.map(node => {
      const m = node.currentMetrics;
      const pred = mlPredict(m.latency, m.packetLoss, m.throughput, m.jitter);
      return { node, pred };
    });
  }, [nodes]);

  // Feature importance data
  const featureImportance = Object.entries(MODEL_METADATA.feature_importance).map(([k, v]) => ({
    feature: k,
    importance: v,
  }));

  // Fault distribution from all faults
  const faultDist = useMemo(() => {
    const counts: Record<string, number> = {};
    allFaults.forEach(f => {
      counts[f.faultType] = (counts[f.faultType] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [allFaults]);

  // Detection method breakdown
  const methodDist = useMemo(() => {
    const counts = { 'rule-based': 0, 'ml-model': 0, 'hybrid': 0 };
    allFaults.forEach(f => { counts[f.detectionMethod]++; });
    return [
      { name: 'Rule-Based', value: counts['rule-based'], color: '#60a5fa' },
      { name: 'ML Model', value: counts['ml-model'], color: '#a78bfa' },
      { name: 'Hybrid', value: counts['hybrid'], color: '#34d399' },
    ];
  }, [allFaults]);

  // Radar data for model performance
  const radarData = [
    { metric: 'Accuracy', value: MODEL_METADATA.accuracy * 100 },
    { metric: 'F1-Score', value: MODEL_METADATA.f1_score * 100 },
    { metric: 'Precision', value: 91.5 },
    { metric: 'Recall', value: 92.8 },
    { metric: 'AUC-ROC', value: 96.3 },
    { metric: 'Specificity', value: 94.1 },
  ];

  const PIE_COLORS = ['#ef4444', '#f59e0b', '#60a5fa', '#10b981', '#a78bfa', '#fb923c'];

  return (
    <div className="space-y-4">
      {/* Model Info Header */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Algorithm', value: 'RandomForest', sub: MODEL_METADATA.algorithm, icon: '🌳' },
          { label: 'Estimators', value: MODEL_METADATA.n_estimators, sub: 'Decision Trees', icon: '🌿' },
          { label: 'Overall Accuracy', value: `${(MODEL_METADATA.accuracy * 100).toFixed(2)}%`, sub: 'Test dataset', icon: '🎯' },
          { label: 'F1-Score', value: `${(MODEL_METADATA.f1_score * 100).toFixed(2)}%`, sub: 'Weighted avg', icon: '📊' },
        ].map((card, i) => (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="rounded-xl border border-violet-500/20 bg-violet-500/5 p-4"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-mono text-slate-500 uppercase">{card.label}</p>
                <p className="text-xl font-bold font-mono text-violet-300 mt-1">{card.value}</p>
                <p className="text-xs text-slate-600 font-mono">{card.sub}</p>
              </div>
              <span className="text-2xl">{card.icon}</span>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Feature Importance */}
        <GlassPanel title="Feature Importance" titleIcon="📈">
          <div className="text-xs text-slate-500 font-mono mb-3">Gini impurity reduction scores</div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={featureImportance} layout="vertical" margin={{ left: 10, right: 20, top: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis type="number" tick={{ fontSize: 9, fill: '#64748b', fontFamily: 'JetBrains Mono' }} domain={[0, 0.4]} />
              <YAxis dataKey="feature" type="category" tick={{ fontSize: 10, fill: '#94a3b8', fontFamily: 'JetBrains Mono' }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="importance" radius={[0, 4, 4, 0]}>
                {featureImportance.map((_, i) => (
                  <Cell key={i} fill={['#60a5fa', '#a78bfa', '#34d399', '#f59e0b'][i % 4]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </GlassPanel>

        {/* Model Performance Radar */}
        <GlassPanel title="Model Performance" titleIcon="🎯">
          <div className="text-xs text-slate-500 font-mono mb-3">Multi-class classification metrics</div>
          <ResponsiveContainer width="100%" height={200}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="#1e293b" />
              <PolarAngleAxis dataKey="metric" tick={{ fontSize: 9, fill: '#64748b', fontFamily: 'JetBrains Mono' }} />
              <Radar dataKey="value" stroke="#a78bfa" fill="#a78bfa" fillOpacity={0.2} strokeWidth={2} />
            </RadarChart>
          </ResponsiveContainer>
        </GlassPanel>

        {/* Detection Method Pie */}
        <GlassPanel title="Detection Methods" titleIcon="🔍">
          <div className="text-xs text-slate-500 font-mono mb-3">Rule-based vs ML vs Hybrid</div>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={methodDist} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" isAnimationActive={false}>
                {methodDist.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: '9px', fontFamily: 'JetBrains Mono' }} />
            </PieChart>
          </ResponsiveContainer>
        </GlassPanel>
      </div>

      {/* Fault Distribution */}
      {faultDist.length > 0 && (
        <GlassPanel title="Detected Fault Distribution" titleIcon="📋">
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={faultDist} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="name" tick={{ fontSize: 9, fill: '#64748b', fontFamily: 'JetBrains Mono' }} />
              <YAxis tick={{ fontSize: 9, fill: '#64748b', fontFamily: 'JetBrains Mono' }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {faultDist.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </GlassPanel>
      )}

      {/* Live ML Predictions Table */}
      <GlassPanel title="Live ML Predictions" titleIcon="🤖" headerRight={
        <span className="text-xs font-mono text-violet-400">RandomForest v{MODEL_METADATA.version}</span>
      }>
        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-700/50">
                {['Node', 'Latency', 'Loss %', 'Throughput', 'Jitter', 'Prediction', 'Confidence', 'Vote Dist.'].map(h => (
                  <th key={h} className="text-left py-2 px-3 text-slate-500 uppercase text-xs">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {predictions.map(({ node, pred }) => (
                <tr key={node.id} className="border-b border-slate-800/50 hover:bg-slate-800/30 transition-colors">
                  <td className="py-2 px-3 text-slate-300">{node.name}</td>
                  <td className={`py-2 px-3 ${node.currentMetrics.latency > 200 ? 'text-red-400' : 'text-slate-400'}`}>
                    {node.currentMetrics.latency.toFixed(1)}ms
                  </td>
                  <td className={`py-2 px-3 ${node.currentMetrics.packetLoss > 10 ? 'text-red-400' : 'text-slate-400'}`}>
                    {node.currentMetrics.packetLoss.toFixed(2)}%
                  </td>
                  <td className="py-2 px-3 text-slate-400">{node.currentMetrics.throughput.toFixed(1)}M</td>
                  <td className="py-2 px-3 text-slate-400">{node.currentMetrics.jitter.toFixed(1)}ms</td>
                  <td className="py-2 px-3">
                    <span className={`px-2 py-0.5 rounded text-xs font-bold ${
                      pred.faultType === 'NORMAL' ? 'bg-emerald-500/20 text-emerald-400' :
                      pred.faultType === 'NODE_FAILURE' ? 'bg-red-600/30 text-red-400' :
                      'bg-amber-500/20 text-amber-400'
                    }`}>
                      {pred.faultType}
                    </span>
                  </td>
                  <td className="py-2 px-3">
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-slate-800 rounded-full h-1.5">
                        <div
                          className={`h-1.5 rounded-full ${pred.confidence > 0.85 ? 'bg-violet-500' : pred.confidence > 0.7 ? 'bg-amber-500' : 'bg-slate-500'}`}
                          style={{ width: `${pred.confidence * 100}%` }}
                        />
                      </div>
                      <span className="text-violet-400">{(pred.confidence * 100).toFixed(1)}%</span>
                    </div>
                  </td>
                  <td className="py-2 px-3">
                    <div className="flex gap-1 flex-wrap">
                      {Object.entries(pred.treeVotes).slice(0, 3).map(([label, pct]) => (
                        <span key={label} className="text-xs bg-slate-800 text-slate-400 px-1 rounded">
                          {label.slice(0, 4)}: {pct}%
                        </span>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassPanel>

      {/* Model Training Info */}
      <GlassPanel title="Model Training Details" titleIcon="🔬">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono">
          {[
            { label: 'Training Data', value: MODEL_METADATA.trained_on },
            { label: 'Max Depth', value: `${MODEL_METADATA.max_depth} levels` },
            { label: 'Min Samples Split', value: MODEL_METADATA.min_samples_split },
            { label: 'Training Date', value: MODEL_METADATA.training_date },
            { label: 'Classes', value: MODEL_METADATA.classes.length },
            { label: 'Version', value: `v${MODEL_METADATA.version}` },
            { label: 'Framework', value: 'scikit-learn (sim)' },
            { label: 'Serialization', value: 'joblib (sim)' },
          ].map(item => (
            <div key={item.label} className="rounded-lg bg-slate-800/50 p-3">
              <p className="text-slate-500 text-xs">{item.label}</p>
              <p className="text-slate-200 font-bold mt-0.5">{item.value}</p>
            </div>
          ))}
        </div>
        <div className="mt-4">
          <p className="text-xs text-slate-500 mb-2">Detected Fault Classes:</p>
          <div className="flex flex-wrap gap-2">
            {MODEL_METADATA.classes.map((cls, i) => (
              <span key={cls} className="text-xs px-2 py-1 rounded bg-slate-800 font-mono" style={{ color: PIE_COLORS[i % PIE_COLORS.length] }}>
                {cls}
              </span>
            ))}
          </div>
        </div>
      </GlassPanel>
    </div>
  );
}
