import type { ReactNode } from 'react';
import { motion } from 'framer-motion';

interface GlassPanelProps {
  children: ReactNode;
  className?: string;
  title?: string;
  titleIcon?: ReactNode;
  headerRight?: ReactNode;
  animate?: boolean;
  noPadding?: boolean;
}

export function GlassPanel({ children, className = '', title, titleIcon, headerRight, animate = false, noPadding = false }: GlassPanelProps) {
  const Wrapper = animate ? motion.div : 'div';
  const motionProps = animate ? { initial: { opacity: 0, y: 20 }, animate: { opacity: 1, y: 0 } } : {};

  return (
    // @ts-ignore
    <Wrapper
      {...motionProps}
      className={`rounded-2xl border border-slate-700/60 bg-slate-900/70 backdrop-blur-md ${className}`}
    >
      {(title || headerRight) && (
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-700/50">
          {title && (
            <div className="flex items-center gap-2">
              {titleIcon && <span className="text-slate-400">{titleIcon}</span>}
              <h3 className="text-sm font-semibold text-slate-200 font-mono tracking-wide uppercase">{title}</h3>
            </div>
          )}
          {headerRight && <div className="flex items-center gap-2">{headerRight}</div>}
        </div>
      )}
      <div className={noPadding ? '' : 'p-4'}>
        {children}
      </div>
    </Wrapper>
  );
}
