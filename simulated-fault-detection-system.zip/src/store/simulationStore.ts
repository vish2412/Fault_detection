import { create } from 'zustand';
import { NetworkSimulator } from '../simulation/networkSimulator';
import type {
  NetworkNode,
  FaultEvent,
  FileTransferEvent,
  LogEntry,
  SystemStats,
  SimulationConfig,
  ScenarioMode,
  FaultType,
} from '../simulation/types';

interface SimulationState {
  // Core simulation
  simulator: NetworkSimulator;
  isRunning: boolean;
  tickInterval: ReturnType<typeof setInterval> | null;
  tickCount: number;

  // Data
  nodes: NetworkNode[];
  allFaults: FaultEvent[];
  fileTransfers: FileTransferEvent[];
  logs: LogEntry[];
  systemStats: SystemStats;

  // Config
  config: SimulationConfig;

  // UI State
  selectedNodeId: string | null;
  activeTab: 'dashboard' | 'topology' | 'alerts' | 'logs' | 'ml' | 'transfers';
  alertFilter: 'ALL' | 'LOW' | 'MEDIUM' | 'CRITICAL';
  logFilter: 'ALL' | 'INFO' | 'WARN' | 'ERROR' | 'DEBUG';

  // Actions
  startSimulation: () => void;
  stopSimulation: () => void;
  tick: () => void;
  setScenarioMode: (mode: ScenarioMode) => void;
  setFaultFrequency: (freq: number) => void;
  setSelectedNode: (id: string | null) => void;
  setActiveTab: (tab: SimulationState['activeTab']) => void;
  setAlertFilter: (f: SimulationState['alertFilter']) => void;
  setLogFilter: (f: SimulationState['logFilter']) => void;
  forceNodeFault: (nodeId: string, faultType: FaultType) => void;
  recoverNode: (nodeId: string) => void;
  clearFaults: () => void;
  exportLogs: () => void;
}

const simulator = new NetworkSimulator();

function computeStats(nodes: NetworkNode[], allFaults: FaultEvent[], transfers: FileTransferEvent[]): SystemStats {
  const online = nodes.filter(n => n.status !== 'offline');
  const offline = nodes.filter(n => n.status === 'offline');
  const warning = nodes.filter(n => n.status === 'warning');
  const critical = nodes.filter(n => n.status === 'critical');
  const activeFaults = allFaults.filter(f => !f.resolved);
  const resolved = allFaults.filter(f => f.resolved);

  const avgLatency = online.length
    ? online.reduce((s, n) => s + n.currentMetrics.latency, 0) / online.length
    : 0;
  const avgPacketLoss = online.length
    ? online.reduce((s, n) => s + n.currentMetrics.packetLoss, 0) / online.length
    : 0;
  const avgThroughput = online.length
    ? online.reduce((s, n) => s + n.currentMetrics.throughput, 0) / online.length
    : 0;
  const corrupted = transfers.filter(t => t.corrupted).length;

  return {
    totalNodes: nodes.length,
    onlineNodes: online.length,
    offlineNodes: offline.length,
    warningNodes: warning.length,
    criticalNodes: critical.length,
    totalFaults: allFaults.length,
    activeFaults: activeFaults.length,
    resolvedFaults: resolved.length,
    avgLatency,
    avgPacketLoss,
    avgThroughput,
    totalFileTransfers: transfers.length,
    corruptedTransfers: corrupted,
    mlAccuracy: 93.12,
    uptime: Date.now(),
  };
}

export const useSimulationStore = create<SimulationState>((set, get) => ({
  simulator,
  isRunning: false,
  tickInterval: null,
  tickCount: 0,
  nodes: simulator.getNodes(),
  allFaults: [],
  fileTransfers: [],
  logs: [],
  systemStats: computeStats(simulator.getNodes(), [], []),
  config: {
    faultFrequency: 0.3,
    scenarioMode: 'normal',
    nodeCount: 12,
    simulationSpeed: 1,
    enableML: true,
    enableCorruption: true,
  },
  selectedNodeId: null,
  activeTab: 'dashboard',
  alertFilter: 'ALL',
  logFilter: 'ALL',

  startSimulation: () => {
    const { isRunning } = get();
    if (isRunning) return;
    const interval = setInterval(() => {
      get().tick();
    }, 2000);
    // Run first tick immediately
    get().tick();
    set({ isRunning: true, tickInterval: interval });
  },

  stopSimulation: () => {
    const { tickInterval } = get();
    if (tickInterval) clearInterval(tickInterval);
    set({ isRunning: false, tickInterval: null });
  },

  tick: () => {
    const { simulator, allFaults, fileTransfers } = get();
    const result = simulator.tick();

    const updatedAllFaults = [
      ...result.newFaults,
      ...allFaults.filter(f => !result.newFaults.some(nf => nf.nodeId === f.nodeId && nf.faultType === f.faultType)),
    ].slice(0, 300);

    const updatedTransfers = [
      ...result.newTransfers,
      ...fileTransfers,
    ].slice(0, 100);

    const updatedLogs = [
      ...result.newLogs,
      ...get().logs,
    ].slice(0, 500);

    const stats = computeStats(result.nodes, updatedAllFaults, updatedTransfers);

    set(state => ({
      nodes: result.nodes,
      allFaults: updatedAllFaults,
      fileTransfers: updatedTransfers,
      logs: updatedLogs,
      systemStats: stats,
      tickCount: state.tickCount + 1,
    }));
  },

  setScenarioMode: (mode) => {
    get().simulator.setScenarioMode(mode);
    set(state => ({ config: { ...state.config, scenarioMode: mode } }));
  },

  setFaultFrequency: (freq) => {
    get().simulator.setFaultFrequency(freq);
    set(state => ({ config: { ...state.config, faultFrequency: freq } }));
  },

  setSelectedNode: (id) => set({ selectedNodeId: id }),
  setActiveTab: (tab) => set({ activeTab: tab }),
  setAlertFilter: (f) => set({ alertFilter: f }),
  setLogFilter: (f) => set({ logFilter: f }),

  forceNodeFault: (nodeId, faultType) => {
    get().simulator.forceNodeFault(nodeId, faultType);
  },

  recoverNode: (nodeId) => {
    get().simulator.recoverNode(nodeId);
  },

  clearFaults: () => set({ allFaults: [] }),

  exportLogs: () => {
    const { logs } = get();
    const csv = [
      'Timestamp,Level,Node,Category,Message',
      ...logs.map(l =>
        `"${new Date(l.timestamp).toISOString()}","${l.level}","${l.nodeName}","${l.category}","${l.message.replace(/"/g, '""')}"`
      ),
    ].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `network-logs-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  },
}));
