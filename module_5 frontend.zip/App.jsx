import React, { useState, useEffect, useCallback, useRef } from "react";
import { clsx } from "clsx";

import { useWebSocket } from "./hooks/useWebSocket.js";
import { useNodeStore } from "./hooks/useNodeStore.js";
import { useAlertStore } from "./hooks/useAlertStore.js";

import Header        from "./components/Header.jsx";
import NodeGrid      from "./components/NodeGrid.jsx";
import MetricCharts  from "./components/MetricCharts.jsx";
import AlertFeed     from "./components/AlertFeed.jsx";
import MLPanel       from "./components/MLPanel.jsx";
import LogPanel      from "./components/LogPanel.jsx";
import StatusBar     from "./components/StatusBar.jsx";

import CONFIG from "./config.js";

// ─── Active tab definition ────────────────────────────────────────────────────
const TABS = [
  { id: "overview",  label: "Overview",    icon: "⬡" },
  { id: "metrics",   label: "Metrics",     icon: "📈" },
  { id: "alerts",    label: "Alerts",      icon: "🔔" },
  { id: "ai",        label: "AI Engine",   icon: "🤖" },
  { id: "logs",      label: "Raw Logs",    icon: "📋" },
];

// ─── App ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [activeTab,       setActiveTab]       = useState("overview");
  const [selectedNodeId,  setSelectedNodeId]  = useState(null);
  const [lastMLPrediction, setLastMLPrediction] = useState(null);

  // ── Raw log entries (kept here, shared down to LogPanel) ──────────────────
  const [logEntries, setLogEntries] = useState([]);
  const addLog = useCallback((entry) => {
    setLogEntries((prev) => [entry, ...prev].slice(0, CONFIG.MAX_LOG_ENTRIES));
  }, []);

  // ── Node store ─────────────────────────────────────────────────────────────
  const {
    nodes,
    metricHistory,
    upsertNode,
    appendMetric,
    setNodeStatus,
  } = useNodeStore();

  // ── Alert store ────────────────────────────────────────────────────────────
  const {
    alerts,
    unreadCount,
    addAlert,
    markAllRead,
  } = useAlertStore();

  // ── WebSocket message handler ──────────────────────────────────────────────
  const handleMessage = useCallback((msg) => {
    const ts = msg.timestamp || new Date().toISOString();

    switch (msg.type) {

      case "initial_state": {
        // Server pushes all known nodes on first connection
        (msg.nodes || []).forEach((n) => upsertNode(n));
        addLog({ ts, type: "system", text: `Initial state: ${(msg.nodes || []).length} node(s) registered.` });
        break;
      }

      case "heartbeat": {
        upsertNode({ node_id: msg.node_id, status: "online", last_seen: ts });
        addLog({ ts, type: "heartbeat", nodeId: msg.node_id, text: `Heartbeat from ${msg.node_id}` });
        break;
      }

      case "metrics": {
        const payload = msg.payload || {};
        appendMetric(msg.node_id, { ...payload, timestamp: ts });
        upsertNode({ node_id: msg.node_id, status: "online", last_seen: ts, latestMetrics: payload });

        if (msg.ml_prediction) {
          setLastMLPrediction({ nodeId: msg.node_id, ts, ...msg.ml_prediction });
        }

        addLog({
          ts,
          type: "metrics",
          nodeId: msg.node_id,
          text: `Metrics — latency=${payload.latency_ms?.toFixed(1)}ms  loss=${(payload.packet_loss_rate * 100)?.toFixed(1)}%  throughput=${payload.throughput_mbps?.toFixed(1)}Mbps  jitter=${payload.jitter_ms?.toFixed(1)}ms`,
        });
        break;
      }

      case "fault_alert": {
        addAlert({
          id:           `${msg.node_id}-${ts}`,
          nodeId:       msg.node_id,
          faultType:    msg.fault_type,
          severity:     msg.severity,
          description:  msg.description,
          source:       msg.source,
          mlPrediction: msg.ml_prediction,
          ts,
        });
        addLog({ ts, type: "fault", nodeId: msg.node_id, text: `FAULT [${msg.severity}] ${msg.fault_type} — ${msg.description}` });
        break;
      }

      case "node_status": {
        setNodeStatus(msg.node_id, msg.status);
        addLog({ ts, type: "status", nodeId: msg.node_id, text: `Node ${msg.node_id} is now ${msg.status.toUpperCase()}` });
        break;
      }

      default:
        addLog({ ts, type: "unknown", text: `Unknown message type: ${msg.type}` });
    }
  }, [upsertNode, appendMetric, setNodeStatus, addAlert, addLog]);

  // ── WebSocket connection ───────────────────────────────────────────────────
  const { connectionState, reconnectCount } = useWebSocket(
    CONFIG.WS_DASHBOARD,
    handleMessage
  );

  // ── Auto-select first node when nodes become available ────────────────────
  useEffect(() => {
    if (!selectedNodeId && nodes.length > 0) {
      setSelectedNodeId(nodes[0].node_id);
    }
  }, [nodes, selectedNodeId]);

  // ── Switch to alerts tab on new critical fault ────────────────────────────
  const prevAlertCount = useRef(0);
  useEffect(() => {
    const criticals = alerts.filter((a) => a.severity === "CRITICAL").length;
    if (criticals > prevAlertCount.current && activeTab !== "alerts") {
      // Don't force tab switch — just badge the tab; user stays in flow
    }
    prevAlertCount.current = criticals;
  }, [alerts, activeTab]);

  // ── Derived summary stats ─────────────────────────────────────────────────
  const onlineCount  = nodes.filter((n) => n.status === "online").length;
  const offlineCount = nodes.filter((n) => n.status === "offline").length;
  const criticalAlerts = alerts.filter((a) => a.severity === "CRITICAL" && !a.read).length;

  // ─── Render ───────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-surface-900 flex flex-col">

      {/* ── Top header ─────────────────────────────────────────────────────── */}
      <Header
        connectionState={connectionState}
        reconnectCount={reconnectCount}
        onlineCount={onlineCount}
        offlineCount={offlineCount}
        totalNodes={nodes.length}
        criticalAlerts={criticalAlerts}
      />

      {/* ── Navigation tabs ────────────────────────────────────────────────── */}
      <nav className="border-b border-surface-600 bg-surface-800/60 backdrop-blur-sm sticky top-0 z-20">
        <div className="max-w-screen-2xl mx-auto px-4 flex gap-1 overflow-x-auto no-scrollbar">
          {TABS.map((tab) => {
            const isAlerts = tab.id === "alerts";
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id);
                  if (isAlerts) markAllRead();
                }}
                className={clsx(
                  "relative flex items-center gap-2 px-4 py-3.5 text-sm font-medium whitespace-nowrap",
                  "border-b-2 transition-all duration-150 focus:outline-none",
                  activeTab === tab.id
                    ? "border-brand-400 text-brand-300"
                    : "border-transparent text-slate-400 hover:text-slate-200 hover:border-surface-400"
                )}
              >
                <span className="text-base leading-none">{tab.icon}</span>
                {tab.label}
                {/* Unread badge for alerts tab */}
                {isAlerts && unreadCount > 0 && (
                  <span className="absolute -top-0.5 right-1 min-w-[18px] h-[18px] flex items-center justify-center rounded-full bg-red-500 text-white text-[10px] font-bold px-1">
                    {unreadCount > 99 ? "99+" : unreadCount}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </nav>

      {/* ── Main content ───────────────────────────────────────────────────── */}
      <main className="flex-1 max-w-screen-2xl mx-auto w-full px-4 py-6">

        {/* OVERVIEW TAB */}
        {activeTab === "overview" && (
          <div className="space-y-6 animate-fade-in">
            {/* Summary stat strip */}
            <SummaryStrip
              onlineCount={onlineCount}
              offlineCount={offlineCount}
              totalNodes={nodes.length}
              totalAlerts={alerts.length}
              criticalAlerts={criticalAlerts}
              lastMLPrediction={lastMLPrediction}
            />
            {/* Node grid — full width on overview */}
            <NodeGrid
              nodes={nodes}
              selectedNodeId={selectedNodeId}
              onSelectNode={setSelectedNodeId}
            />
            {/* Bottom two-column: charts left, alerts right */}
            <div className="grid grid-cols-1 xl:grid-cols-5 gap-6">
              <div className="xl:col-span-3">
                <MetricCharts
                  nodes={nodes}
                  metricHistory={metricHistory}
                  selectedNodeId={selectedNodeId}
                  onSelectNode={setSelectedNodeId}
                  compact
                />
              </div>
              <div className="xl:col-span-2">
                <AlertFeed alerts={alerts} compact maxItems={8} />
              </div>
            </div>
          </div>
        )}

        {/* METRICS TAB */}
        {activeTab === "metrics" && (
          <div className="animate-fade-in">
            <MetricCharts
              nodes={nodes}
              metricHistory={metricHistory}
              selectedNodeId={selectedNodeId}
              onSelectNode={setSelectedNodeId}
            />
          </div>
        )}

        {/* ALERTS TAB */}
        {activeTab === "alerts" && (
          <div className="animate-fade-in">
            <AlertFeed alerts={alerts} />
          </div>
        )}

        {/* AI ENGINE TAB */}
        {activeTab === "ai" && (
          <div className="animate-fade-in">
            <MLPanel
              lastPrediction={lastMLPrediction}
              alerts={alerts}
              nodes={nodes}
            />
          </div>
        )}

        {/* RAW LOGS TAB */}
        {activeTab === "logs" && (
          <div className="animate-fade-in">
            <LogPanel entries={logEntries} />
          </div>
        )}

      </main>

      {/* ── Status bar ─────────────────────────────────────────────────────── */}
      <StatusBar
        connectionState={connectionState}
        nodeCount={nodes.length}
        onlineCount={onlineCount}
        alertCount={alerts.length}
        lastMLPrediction={lastMLPrediction}
      />
    </div>
  );
}

// ─── SummaryStrip ─────────────────────────────────────────────────────────────
function SummaryStrip({ onlineCount, offlineCount, totalNodes, totalAlerts, criticalAlerts, lastMLPrediction }) {
  const stats = [
    {
      label: "Nodes Online",
      value: onlineCount,
      sub: `of ${totalNodes} total`,
      color: onlineCount > 0 ? "text-emerald-400" : "text-slate-500",
      icon: "🟢",
    },
    {
      label: "Nodes Offline",
      value: offlineCount,
      sub: offlineCount > 0 ? "degraded" : "all healthy",
      color: offlineCount > 0 ? "text-red-400" : "text-slate-400",
      icon: "🔴",
    },
    {
      label: "Total Alerts",
      value: totalAlerts,
      sub: `${criticalAlerts} critical`,
      color: criticalAlerts > 0 ? "text-red-400" : "text-amber-400",
      icon: "⚠️",
    },
    {
      label: "Last AI Prediction",
      value: lastMLPrediction?.fault_type ?? "—",
      sub: lastMLPrediction
        ? `${(lastMLPrediction.confidence * 100).toFixed(1)}% confidence`
        : "awaiting data",
      color: lastMLPrediction?.fault_type === "NORMAL"
        ? "text-emerald-400"
        : lastMLPrediction
        ? "text-amber-400"
        : "text-slate-500",
      icon: "🤖",
    },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((s) => (
        <div key={s.label} className="glass-card p-4 flex items-start gap-3">
          <span className="text-2xl leading-none mt-0.5">{s.icon}</span>
          <div className="min-w-0">
            <p className="section-title truncate">{s.label}</p>
            <p className={clsx("text-2xl font-bold mt-1 truncate", s.color)}>{s.value}</p>
            <p className="text-xs text-slate-500 mt-0.5 truncate">{s.sub}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
