import { motion, AnimatePresence } from 'framer-motion';
import { useSimulationStore } from '../../store/simulationStore';
import { formatDistanceToNow } from 'date-fns';
import { useMemo } from 'react';

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function FileTransferPanel() {
  const { fileTransfers, nodes } = useSimulationStore();

  const nodeMap = useMemo(() => {
    const m: Record<string, string> = {};
    nodes.forEach(n => { m[n.id] = n.name; });
    return m;
  }, [nodes]);

  const stats = useMemo(() => ({
    total: fileTransfers.length,
    success: fileTransfers.filter(t => t.status === 'success').length,
    corrupted: fileTransfers.filter(t => t.corrupted).length,
    totalBytes: fileTransfers.reduce((s, t) => s + t.fileSize, 0),
    avgTime: fileTransfers.length
      ? fileTransfers.reduce((s, t) => s + t.transferTime, 0) / fileTransfers.length
      : 0,
  }), [fileTransfers]);

  return (
    <div className="rounded-2xl border border-slate-700/60 bg-slate-900/70 backdrop-blur-md">
      <div className="px-5 py-3 border-b border-slate-700/50 flex items-center gap-2">
        <span className="text-slate-400">📁</span>
        <h3 className="text-sm font-semibold text-slate-200 font-mono uppercase tracking-wide">File Transfer Monitor</h3>
      </div>

      {/* Stats */}
      <div className="px-5 py-3 border-b border-slate-700/30 grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          { label: 'Total Transfers', value: stats.total, color: 'text-slate-300' },
          { label: 'Successful', value: stats.success, color: 'text-emerald-400' },
          { label: 'Corrupted', value: stats.corrupted, color: 'text-red-400' },
          { label: 'Total Data', value: formatBytes(stats.totalBytes), color: 'text-blue-400' },
          { label: 'Avg Transfer Time', value: `${stats.avgTime.toFixed(0)}ms`, color: 'text-violet-400' },
        ].map(s => (
          <div key={s.label} className="text-center p-2 rounded-lg bg-slate-800/40">
            <p className={`text-lg font-bold font-mono ${s.color}`}>{s.value}</p>
            <p className="text-xs text-slate-600">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Table */}
      <div className="p-4 overflow-y-auto max-h-[500px] custom-scrollbar">
        {fileTransfers.length === 0 ? (
          <div className="text-center py-12 text-slate-600 font-mono text-sm">
            <div className="text-4xl mb-3">📭</div>
            <p>No file transfers yet — simulation running...</p>
          </div>
        ) : (
          <div className="space-y-2">
            <AnimatePresence mode="popLayout" initial={false}>
              {fileTransfers.map(transfer => (
                <motion.div
                  key={transfer.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={`rounded-lg border p-3 font-mono text-xs ${
                    transfer.corrupted
                      ? 'border-red-500/30 bg-red-500/10'
                      : 'border-emerald-500/20 bg-emerald-500/5'
                  }`}
                >
                  <div className="flex items-start justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{transfer.corrupted ? '🔴' : '✅'}</span>
                      <div>
                        <p className="text-white font-semibold">{transfer.filename}</p>
                        <p className="text-slate-500 text-xs mt-0.5">
                          {nodeMap[transfer.sourceNodeId] || transfer.sourceNodeId}
                          {' → '}
                          {nodeMap[transfer.targetNodeId] || transfer.targetNodeId}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={`px-2 py-0.5 rounded text-xs font-bold ${
                        transfer.status === 'success' ? 'bg-emerald-500/20 text-emerald-400' :
                        transfer.status === 'corrupted' ? 'bg-red-500/20 text-red-400' :
                        'bg-slate-500/20 text-slate-400'
                      }`}>
                        {transfer.status.toUpperCase()}
                      </span>
                      <span className="text-slate-500">{formatDistanceToNow(transfer.timestamp, { addSuffix: true })}</span>
                    </div>
                  </div>

                  <div className="mt-2 grid grid-cols-2 md:grid-cols-4 gap-2">
                    <div>
                      <span className="text-slate-600">Size: </span>
                      <span className="text-slate-300">{formatBytes(transfer.fileSize)}</span>
                    </div>
                    <div>
                      <span className="text-slate-600">Time: </span>
                      <span className="text-slate-300">{transfer.transferTime}ms</span>
                    </div>
                    <div className="col-span-2">
                      <span className="text-slate-600">Expected SHA256: </span>
                      <span className={transfer.corrupted ? 'text-red-400' : 'text-emerald-400'}>
                        {transfer.expectedChecksum.slice(0, 16)}...
                      </span>
                    </div>
                    {transfer.corrupted && (
                      <div className="col-span-2 md:col-span-4">
                        <span className="text-slate-600">Actual SHA256: </span>
                        <span className="text-red-400">{transfer.actualChecksum.slice(0, 16)}... </span>
                        <span className="text-red-300 font-bold">⚠ MISMATCH — DATA CORRUPTION DETECTED</span>
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}
