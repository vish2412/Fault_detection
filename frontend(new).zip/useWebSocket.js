// src/hooks/useWebSocket.js
import { useEffect, useRef, useState, useCallback } from 'react'
import config from '../config'

const MAX_RECONNECT_DELAY = 30000   // 30 s
const BASE_RECONNECT_DELAY = 2000   // 2 s

export function useWebSocket() {
  const wsRef            = useRef(null)
  const reconnectTimer   = useRef(null)
  const reconnectDelay   = useRef(BASE_RECONNECT_DELAY)
  const mountedRef       = useRef(true)

  const [connected,    setConnected]    = useState(false)
  const [lastMessage,  setLastMessage]  = useState(null)   // raw parsed object
  const [error,        setError]        = useState(null)

  // Separate typed streams — consumers can pick what they need
  const [nodeMap,      setNodeMap]      = useState({})      // node_id -> metadata
  const [metricStream, setMetricStream] = useState([])      // last 200 metric events
  const [alertFeed,    setAlertFeed]    = useState([])      // last 100 fault alerts
  const [logFeed,      setLogFeed]      = useState([])      // last 150 raw log lines
  const [mlLatest,     setMlLatest]     = useState(null)    // most recent ML prediction

  // ── Helper: prepend to bounded array ──
  const prepend = (arr, item, max) => [item, ...arr].slice(0, max)

  // ── Message dispatcher ──
  const handleMessage = useCallback((event) => {
    let msg
    try { msg = JSON.parse(event.data) } catch { return }

    setLastMessage(msg)

    const ts = msg.timestamp || new Date().toISOString()

    switch (msg.type) {

      // ── Initial state dump on connect ──
      case 'initial_state': {
        const map = {}
        ;(msg.nodes || []).forEach(n => { map[n.node_id] = n })
        setNodeMap(map)
        setLogFeed(prev => prepend(prev,
          { ts, text: `[INIT] Received state for ${msg.nodes?.length ?? 0} node(s)`, level: 'info' }, 150))
        break
      }

      // ── Node online/offline ──
      case 'node_status': {
        setNodeMap(prev => ({
          ...prev,
          [msg.node_id]: {
            ...(prev[msg.node_id] || {}),
            node_id:    msg.node_id,
            status:     msg.status,
            hostname:   msg.hostname   || prev[msg.node_id]?.hostname,
            ip_address: msg.ip_address || prev[msg.node_id]?.ip_address,
            last_seen:  ts,
          },
        }))
        setLogFeed(prev => prepend(prev,
          { ts, text: `[NODE] ${msg.node_id} → ${msg.status.toUpperCase()}`,
            level: msg.status === 'online' ? 'success' : 'error' }, 150))
        break
      }

      // ── Heartbeat ──
      case 'heartbeat': {
        setNodeMap(prev => ({
          ...prev,
          [msg.node_id]: {
            ...(prev[msg.node_id] || { node_id: msg.node_id }),
            status:    'online',
            last_seen: ts,
          },
        }))
        break
      }

      // ── Live metrics ──
      case 'metrics': {
        const entry = {
          node_id:   msg.node_id,
          timestamp: ts,
          ...msg.payload,
          ml:        msg.ml_prediction,
        }
        setMetricStream(prev => prepend(prev, entry, 200))

        if (msg.ml_prediction?.ml_available) {
          setMlLatest({ node_id: msg.node_id, ts, ...msg.ml_prediction })
        }

        // Keep node alive
        setNodeMap(prev => ({
          ...prev,
          [msg.node_id]: {
            ...(prev[msg.node_id] || { node_id: msg.node_id }),
            status:    'online',
            last_seen: ts,
          },
        }))
        break
      }

      // ── Fault alert ──
      case 'fault_alert': {
        const alert = {
          id:          msg.db_id || Date.now(),
          node_id:     msg.node_id,
          fault_type:  msg.fault_type,
          severity:    msg.severity,
          description: msg.description,
          source:      msg.source,
          ml:          msg.ml_prediction,
          ts,
        }
        setAlertFeed(prev => prepend(prev, alert, 100))
        setLogFeed(prev => prepend(prev,
          { ts, text: `[${msg.severity}] ${msg.node_id} — ${msg.fault_type}: ${msg.description}`,
            level: msg.severity === 'CRITICAL' ? 'error'
                 : msg.severity === 'MEDIUM'   ? 'warn' : 'info' }, 150))
        break
      }

      default:
        break
    }
  }, [])

  // ── Connect ──
  const connect = useCallback(() => {
    if (!mountedRef.current) return

    try {
      const ws = new WebSocket(config.wsDashboard)
      wsRef.current = ws

      ws.onopen = () => {
        if (!mountedRef.current) return
        setConnected(true)
        setError(null)
        reconnectDelay.current = BASE_RECONNECT_DELAY
        setLogFeed(prev => prepend(prev,
          { ts: new Date().toISOString(), text: `[WS] Connected to ${config.wsDashboard}`, level: 'success' }, 150))
      }

      ws.onmessage = handleMessage

      ws.onerror = (e) => {
        setError('WebSocket error — check server connection')
      }

      ws.onclose = () => {
        if (!mountedRef.current) return
        setConnected(false)
        setLogFeed(prev => prepend(prev,
          { ts: new Date().toISOString(), text: `[WS] Disconnected. Reconnecting in ${reconnectDelay.current / 1000}s...`, level: 'warn' }, 150))

        reconnectTimer.current = setTimeout(() => {
          reconnectDelay.current = Math.min(reconnectDelay.current * 1.5, MAX_RECONNECT_DELAY)
          connect()
        }, reconnectDelay.current)
      }

    } catch (err) {
      setError(String(err))
    }
  }, [handleMessage])

  useEffect(() => {
    mountedRef.current = true
    connect()
    return () => {
      mountedRef.current = false
      clearTimeout(reconnectTimer.current)
      wsRef.current?.close()
    }
  }, [connect])

  // Ping keepalive every 25 s
  useEffect(() => {
    const id = setInterval(() => {
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'ping' }))
      }
    }, 25000)
    return () => clearInterval(id)
  }, [])

  return {
    connected,
    error,
    lastMessage,
    nodeMap,
    metricStream,
    alertFeed,
    logFeed,
    mlLatest,
  }
}
