import { motion } from 'framer-motion';
import { useSimulationStore } from '../../store/simulationStore';
import { MetricCard } from '../ui/MetricCard';

export function SystemOverview() {
  const { systemStats, tickCount } = useSimulationStore();
  const s = systemStats;

  const healthPct = s.totalNodes > 0 ? Math.round((s.onlineNodes / s.totalNodes) * 100) : 0;

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-8 gap-3">
      <motion.div
        className="col-span-2 md:col-span-4 xl:col-span-2 row-span-2 rounded-2xl border border-slate-700/60 bg-gradient-to-br from-blue-900/30 to-slate-900/70 backdrop-blur-md p-5 flex flex-col justify-between"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
      >
        <div>
          <p className="text-xs font-mono text-slate-400 uppercase tracking-widest">Network Health</p>
          <div className="mt-3 flex items-center gap-3">
            <div className="relative w-20 h-20">
              <svg viewBox="0 0 36 36" className="w-20 h-20 -rotate-90">
                <circle cx="18" cy="18" r="15.9" fill="none" stroke="#1e293b" strokeWidth="3" />
                <motion.circle
                  cx="18" cy="18" r="15.9" fill="none"
                  stroke={healthPct > 80 ? '#10b981' : healthPct > 50 ? '#f59e0b' : '#ef4444'}
                  strokeWidth="3"
                  strokeDasharray={`${healthPct} ${100 - healthPct}`}
                  strokeLinecap="round"
                  initial={{ strokeDasharray: '0 100' }}
                  animate={{ strokeDasharray: `${healthPct} ${100 - healthPct}` }}
                  transition={{ duration: 1.2, ease: 'easeOut' }}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-xl font-bold font-mono text-white">{healthPct}%</span>
              </div>
            </div>
            <div>
              <p className="text-2xl font-bold text-white font-mono">{s.onlineNodes}/{s.totalNodes}</p>
              <p className="text-xs text-slate-400">Nodes Online</p>
              <div className="mt-1 flex gap-2">
                <span className="text-xs text-emerald-400 font-mono">{s.onlineNodes - s.warningNodes - s.criticalNodes} healthy</span>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <div className="rounded-lg bg-slate-800/50 p-2 text-center">
            <p className="text-lg font-bold text-amber-400 font-mono">{s.warningNodes}</p>
            <p className="text-xs text-slate-500">Warning</p>
          </div>
          <div className="rounded-lg bg-slate-800/50 p-2 text-center">
            <p className="text-lg font-bold text-red-400 font-mono">{s.criticalNodes}</p>
            <p className="text-xs text-slate-500">Critical</p>
          </div>
          <div className="rounded-lg bg-slate-800/50 p-2 text-center">
            <p className="text-lg font-bold text-slate-400 font-mono">{s.offlineNodes}</p>
            <p className="text-xs text-slate-500">Offline</p>
          </div>
          <div className="rounded-lg bg-slate-800/50 p-2 text-center">
            <p className="text-lg font-bold text-blue-400 font-mono">#{tickCount}</p>
            <p className="text-xs text-slate-500">Tick</p>
          </div>
        </div>
      </motion.div>

      <MetricCard
        label="Avg Latency"
        value={s.avgLatency.toFixed(1)}
        unit="ms"
        icon="⚡"
        status={s.avgLatency > 200 ? 'bad' : s.avgLatency > 100 ? 'warn' : 'good'}
        trend={s.avgLatency > 150 ? 'up' : 'stable'}
        subtext="RTT (Round-Trip Time)"
        animateIn
        className="col-span-1"
      />
      <MetricCard
        label="Packet Loss"
        value={s.avgPacketLoss.toFixed(2)}
        unit="%"
        icon="📦"
        status={s.avgPacketLoss > 10 ? 'bad' : s.avgPacketLoss > 5 ? 'warn' : 'good'}
        trend={s.avgPacketLoss > 8 ? 'up' : 'stable'}
        subtext="Avg across all nodes"
        animateIn
        className="col-span-1"
      />
      <MetricCard
        label="Throughput"
        value={s.avgThroughput.toFixed(0)}
        unit="Mbps"
        icon="🌐"
        status={s.avgThroughput < 50 ? 'bad' : s.avgThroughput < 150 ? 'warn' : 'good'}
        trend={s.avgThroughput < 100 ? 'down' : 'stable'}
        subtext="Avg network bandwidth"
        animateIn
        className="col-span-1"
      />
      <MetricCard
        label="Active Faults"
        value={s.activeFaults}
        icon="🚨"
        status={s.activeFaults > 5 ? 'bad' : s.activeFaults > 2 ? 'warn' : s.activeFaults > 0 ? 'warn' : 'good'}
        trend={s.activeFaults > 3 ? 'up' : 'stable'}
        subtext={`${s.resolvedFaults} resolved`}
        animateIn
        className="col-span-1"
      />
      <MetricCard
        label="ML Accuracy"
        value={s.mlAccuracy.toFixed(2)}
        unit="%"
        icon="🤖"
        status="good"
        subtext="RandomForest v2.4.1"
        animateIn
        className="col-span-1"
      />
      <MetricCard
        label="File Transfers"
        value={s.totalFileTransfers}
        icon="📁"
        status={s.corruptedTransfers > 3 ? 'bad' : 'good'}
        subtext={`${s.corruptedTransfers} corrupted`}
        animateIn
        className="col-span-1"
      />
    </div>
  );
}
