/**
 * AlertFeed.jsx
 * -------------
 * Scrollable alert list with severity filtering, colour-coded rows,
 * and ML prediction annotations per alert.
 */

import React, { useState, useMemo } from "react";
import { clsx } from "clsx";
import { getSeverityColor } from "../hooks/useMetricColor.js";
import { formatDistanceToNowStrict } from "date-fns";

const SEVERITY_ORDER = { CRITICAL: 0, MEDIUM: 1, LOW: 2 };
const FAULT_ICONS = {
  NODE_FAILURE:             "💀",
  HIGH_LATENCY:             "⏱",
  PACKET_LOSS:              "📦",
  THROUGHPUT_DEGRADATION:   "📉",
  NETWORK_CONGESTION:       "🚦",
  DATA_CORRUPTION:          "🔥",
  NORMAL:                   "✅",
};

function relativeTime(isoTs) {
  if (!isoTs) return "—";
  try { return formatDistanceToNowStrict(new Date(isoTs), { addSuffix: true }); }
  catch { return "—"; }
}

// ── Single alert row ───────────────────────────────────────────────────────────
function AlertRow({ alert }) {
  const [expanded, setExpanded] = useState(false);
  const sc  = getSeverityColor(alert.severity);
  const icon = FAULT_ICONS[alert.faultType] || "⚠";

  return (
    <div
      className={clsx(
        "border rounded-xl overflow-hidden transition-all duration-200 animate-slide-in-up",
        sc.bg, sc.border,
        !alert.read && "ring-1 ring-inset ring-white/5"
      )}
    >
      {/* Main row */}
      <button
        className="w-full text-left px-4 py-3 flex items-start gap-3 hover:brightness-110 transition-all"
        onClick={() => setExpanded((e) => !e)}
      >
        <span className="text-lg leading-none mt-0.5 flex-shrink-0">{icon}</span>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className={clsx("text-sm font-bold", sc.text)}>{alert.faultType}</span>
            <span className={clsx(
              "text-[10px] font-bold px-1.5 py-0.5 rounded border",
              sc.text, sc.bg, sc.border
            )}>
              {alert.severity}
            </span>
            {!alert.read && (
              <span className="w-1.5 h-1.5 rounded-full bg-white/40 flex-shrink-0" />
            )}
          </div>
          <p className="text-xs text-slate-400 mt-0.5 truncate">{alert.description}</p>
          <div className="flex items-center gap-3 mt-1 text-[10px] text-slate-500">
            <span className="font-mono">{alert.nodeId}</span>
            <span>•</span>
            <span>{relativeTime(alert.ts)}</span>
            {alert.source && (
              <>
                <span>•</span>
                <span className="capitalize">{alert.source?.replace("_", " ")}</span>
              </>
            )}
          </div>
        </div>
        <span className={clsx("text-slate-400 text-xs flex-shrink-0 mt-1", expanded && "rotate-180 transition-transform")}>
          ▾
        </span>
      </button>

      {/* Expanded: ML prediction breakdown */}
      {expanded && alert.mlPrediction && (
        <div className="px-4 pb-3 border-t border-white/5">
          <p className="text-[10px] text-slate-500 mt-2 mb-1.5 uppercase tracking-wider">ML Prediction</p>
          <div className="flex items-center gap-3 flex-wrap">
            <span className="text-xs font-mono text-slate-300">
              {alert.mlPrediction.fault_type ?? "—"}
            </span>
            {alert.mlPrediction.confidence != null && (
              <ConfidenceBar value={alert.mlPrediction.confidence} />
            )}
          </div>
          {alert.mlPrediction.class_probabilities && (
            <div className="mt-2 grid grid-cols-2 gap-x-6 gap-y-1">
              {Object.entries(alert.mlPrediction.class_probabilities)
                .sort(([, a], [, b]) => b - a)
                .map(([cls, prob]) => (
                  <div key={cls} className="flex items-center gap-2">
                    <div className="w-16 h-1 bg-surface-600 rounded-full overflow-hidden flex-shrink-0">
                      <div
                        className="h-full bg-brand-400 rounded-full"
                        style={{ width: `${prob * 100}%` }}
                      />
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono truncate">
                      {cls} {(prob * 100).toFixed(1)}%
                    </span>
                  </div>
                ))
              }
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function ConfidenceBar({ value }) {
  const pct   = (value * 100).toFixed(1);
  const color = value > 0.85 ? "#34d399" : value > 0.6 ? "#fbbf24" : "#f87171";
  return (
    <div className="flex items-center gap-2">
      <div className="w-20 h-1.5 bg-surface-600 rounded-full overflow-hidden">
        <div className="h-full rounded-full" style={{ width: `${value * 100}%`, backgroundColor: color }} />
      </div>
      <span className="text-[10px] font-mono" style={{ color }}>{pct}%</span>
    </div>
  );
}

// ── AlertFeed ─────────────────────────────────────────────────────────────────
const FILTERS = ["ALL", "CRITICAL", "MEDIUM", "LOW"];

export default function AlertFeed({ alerts, compact = false, maxItems }) {
  const [filter, setFilter] = useState("ALL");

  const filtered = useMemo(() => {
    const base = filter === "ALL" ? alerts : alerts.filter((a) => a.severity === filter);
    const sorted = [...base].sort((a, b) => {
      const sev = (SEVERITY_ORDER[a.severity] ?? 9) - (SEVERITY_ORDER[b.severity] ?? 9);
      if (sev !== 0) return sev;
      return new Date(b.ts) - new Date(a.ts);
    });
    return maxItems ? sorted.slice(0, maxItems) : sorted;
  }, [alerts, filter, maxItems]);

  // Count per severity
  const counts = useMemo(() => {
    const c = { ALL: alerts.length, CRITICAL: 0, MEDIUM: 0, LOW: 0 };
    alerts.forEach((a) => { if (a.severity in c) c[a.severity]++; });
    return c;
  }, [alerts]);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <h2 className="section-title">Fault Alerts</h2>
        {!compact && (
          <div className="flex items-center gap-1">
            {FILTERS.map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={clsx(
                  "px-2.5 py-1 rounded-lg text-xs font-medium border transition-all",
                  filter === f
                    ? "bg-brand-600/30 border-brand-400/50 text-brand-300"
                    : "bg-surface-700 border-surface-500 text-slate-400 hover:text-slate-200"
                )}
              >
                {f}
                {counts[f] > 0 && (
                  <span className="ml-1.5 text-[10px] opacity-70">({counts[f]})</span>
                )}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* List */}
      {filtered.length === 0 ? (
        <div className="glass-card p-8 text-center flex-1 flex flex-col items-center justify-center">
          <div className="text-3xl mb-2">✅</div>
          <p className="text-slate-400 text-sm">
            {filter === "ALL" ? "No alerts yet." : `No ${filter} alerts.`}
          </p>
        </div>
      ) : (
        <div className={clsx(
          "space-y-2 overflow-y-auto scrollbar-thin pr-1",
          compact ? "max-h-80" : "max-h-[680px]"
        )}>
          {filtered.map((alert) => (
            <AlertRow key={alert.id} alert={alert} />
          ))}
        </div>
      )}

      {/* Footer count */}
      {!compact && filtered.length > 0 && (
        <p className="text-[10px] text-slate-500 mt-2 text-right">
          Showing {filtered.length} of {alerts.length} alerts
        </p>
      )}
    </div>
  );
}
