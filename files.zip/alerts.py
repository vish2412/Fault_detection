import logging
from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import desc, func, and_

from database.db import get_db
from database.models import FaultEvent

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/alerts", tags=["alerts"])


@router.get("/")
async def list_alerts(
    severity: Optional[str] = Query(None, description="Filter: LOW, MEDIUM, CRITICAL"),
    fault_type: Optional[str] = Query(None),
    node_id: Optional[str] = Query(None),
    hours: int = Query(24, ge=1, le=720),
    limit: int = Query(100, le=500),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
):
    """List fault alerts with optional filters."""
    since = datetime.utcnow() - timedelta(hours=hours)

    query = select(FaultEvent).where(FaultEvent.detected_at >= since)

    if severity:
        query = query.where(FaultEvent.severity == severity.upper())
    if fault_type:
        query = query.where(FaultEvent.fault_type == fault_type.upper())
    if node_id:
        query = query.where(FaultEvent.node_id == node_id)

    query = query.order_by(desc(FaultEvent.detected_at)).limit(limit).offset(offset)

    result = await db.execute(query)
    alerts = result.scalars().all()

    return {
        "alerts": [
            {
                "id": a.id,
                "node_id": a.node_id,
                "fault_type": a.fault_type,
                "severity": a.severity,
                "description": a.description,
                "source": a.source,
                "ml_fault_type": a.ml_fault_type,
                "ml_confidence": a.ml_confidence,
                "detected_at": a.detected_at.isoformat() if a.detected_at else None,
            }
            for a in alerts
        ],
        "count": len(alerts),
        "period_hours": hours,
    }


@router.get("/summary")
async def alerts_summary(
    hours: int = Query(24, ge=1, le=720),
    db: AsyncSession = Depends(get_db),
):
    """Summary of faults grouped by type and severity."""
    since = datetime.utcnow() - timedelta(hours=hours)

    # By fault type
    by_type = await db.execute(
        select(FaultEvent.fault_type, func.count(FaultEvent.id).label("count"))
        .where(FaultEvent.detected_at >= since)
        .group_by(FaultEvent.fault_type)
        .order_by(desc("count"))
    )

    # By severity
    by_severity = await db.execute(
        select(FaultEvent.severity, func.count(FaultEvent.id).label("count"))
        .where(FaultEvent.detected_at >= since)
        .group_by(FaultEvent.severity)
    )

    # By node
    by_node = await db.execute(
        select(FaultEvent.node_id, func.count(FaultEvent.id).label("count"))
        .where(FaultEvent.detected_at >= since)
        .group_by(FaultEvent.node_id)
        .order_by(desc("count"))
        .limit(10)
    )

    return {
        "period_hours": hours,
        "since": since.isoformat(),
        "by_fault_type": {row.fault_type: row.count for row in by_type},
        "by_severity": {row.severity: row.count for row in by_severity},
        "top_faulty_nodes": {row.node_id: row.count for row in by_node},
    }


@router.get("/recent")
async def recent_alerts(
    limit: int = Query(20, le=100),
    db: AsyncSession = Depends(get_db),
):
    """Get the most recent alerts across all nodes."""
    result = await db.execute(
        select(FaultEvent)
        .order_by(desc(FaultEvent.detected_at))
        .limit(limit)
    )
    alerts = result.scalars().all()

    return {
        "alerts": [
            {
                "id": a.id,
                "node_id": a.node_id,
                "fault_type": a.fault_type,
                "severity": a.severity,
                "description": a.description,
                "source": a.source,
                "ml_fault_type": a.ml_fault_type,
                "ml_confidence": a.ml_confidence,
                "detected_at": a.detected_at.isoformat() if a.detected_at else None,
            }
            for a in alerts
        ]
    }
