import logging
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import desc, func

from database.db import get_db
from database.models import Node, MetricLog, FaultEvent as FaultEventModel
from websocket_manager import manager

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/nodes", tags=["nodes"])


@router.get("/")
async def list_nodes(
    status: Optional[str] = Query(None, description="Filter by 'online' or 'offline'"),
    db: AsyncSession = Depends(get_db),
):
    """List all registered nodes with their current status."""
    query = select(Node)
    result = await db.execute(query)
    nodes = result.scalars().all()

    # Enrich with live connection data
    online_ids = set(manager.get_online_nodes())
    node_list = []
    for node in nodes:
        node_dict = {
            "node_id": node.node_id,
            "hostname": node.hostname,
            "ip_address": node.ip_address,
            "status": "online" if node.node_id in online_ids else "offline",
            "registered_at": node.registered_at.isoformat() if node.registered_at else None,
            "last_seen": node.last_seen.isoformat() if node.last_seen else None,
            "os_info": node.os_info,
            "tags": node.tags,
        }
        if status and node_dict["status"] != status:
            continue
        node_list.append(node_dict)

    return {"nodes": node_list, "total": len(node_list)}


@router.get("/{node_id}")
async def get_node(node_id: str, db: AsyncSession = Depends(get_db)):
    """Get details for a specific node."""
    result = await db.execute(select(Node).where(Node.node_id == node_id))
    node = result.scalar_one_or_none()

    if not node:
        raise HTTPException(status_code=404, detail=f"Node '{node_id}' not found")

    online_ids = set(manager.get_online_nodes())
    return {
        "node_id": node.node_id,
        "hostname": node.hostname,
        "ip_address": node.ip_address,
        "status": "online" if node.node_id in online_ids else "offline",
        "registered_at": node.registered_at.isoformat() if node.registered_at else None,
        "last_seen": node.last_seen.isoformat() if node.last_seen else None,
        "os_info": node.os_info,
        "tags": node.tags,
    }


@router.get("/{node_id}/metrics")
async def get_node_metrics(
    node_id: str,
    limit: int = Query(100, le=1000),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
):
    """Get historical metrics for a node."""
    result = await db.execute(
        select(MetricLog)
        .where(MetricLog.node_id == node_id)
        .order_by(desc(MetricLog.recorded_at))
        .limit(limit)
        .offset(offset)
    )
    metrics = result.scalars().all()

    return {
        "node_id": node_id,
        "metrics": [
            {
                "id": m.id,
                "latency_ms": m.latency_ms,
                "packet_loss_rate": m.packet_loss_rate,
                "throughput_mbps": m.throughput_mbps,
                "jitter_ms": m.jitter_ms,
                "recorded_at": m.recorded_at.isoformat() if m.recorded_at else None,
            }
            for m in metrics
        ],
        "count": len(metrics),
    }


@router.get("/{node_id}/faults")
async def get_node_faults(
    node_id: str,
    limit: int = Query(50, le=500),
    db: AsyncSession = Depends(get_db),
):
    """Get fault history for a node."""
    result = await db.execute(
        select(FaultEventModel)
        .where(FaultEventModel.node_id == node_id)
        .order_by(desc(FaultEventModel.detected_at))
        .limit(limit)
    )
    faults = result.scalars().all()

    return {
        "node_id": node_id,
        "faults": [
            {
                "id": f.id,
                "fault_type": f.fault_type,
                "severity": f.severity,
                "description": f.description,
                "source": f.source,
                "detected_at": f.detected_at.isoformat() if f.detected_at else None,
            }
            for f in faults
        ],
        "count": len(faults),
    }


@router.get("/{node_id}/stats")
async def get_node_stats(node_id: str, db: AsyncSession = Depends(get_db)):
    """Aggregate stats for a node (avg latency, total faults, etc.)."""
    # Metric aggregates
    agg_result = await db.execute(
        select(
            func.avg(MetricLog.latency_ms).label("avg_latency"),
            func.avg(MetricLog.packet_loss_rate).label("avg_packet_loss"),
            func.avg(MetricLog.throughput_mbps).label("avg_throughput"),
            func.avg(MetricLog.jitter_ms).label("avg_jitter"),
            func.count(MetricLog.id).label("total_metrics"),
        ).where(MetricLog.node_id == node_id)
    )
    agg = agg_result.one()

    # Fault counts
    fault_result = await db.execute(
        select(
            FaultEventModel.severity,
            func.count(FaultEventModel.id).label("count"),
        )
        .where(FaultEventModel.node_id == node_id)
        .group_by(FaultEventModel.severity)
    )
    fault_counts = {row.severity: row.count for row in fault_result}

    return {
        "node_id": node_id,
        "avg_latency_ms": round(agg.avg_latency or 0, 2),
        "avg_packet_loss_rate": round(agg.avg_packet_loss or 0, 4),
        "avg_throughput_mbps": round(agg.avg_throughput or 0, 2),
        "avg_jitter_ms": round(agg.avg_jitter or 0, 2),
        "total_metrics_recorded": agg.total_metrics or 0,
        "fault_counts_by_severity": fault_counts,
    }
