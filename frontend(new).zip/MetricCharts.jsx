// src/components/MetricCharts.jsx
import React, { useMemo, useState } from 'react'
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, ReferenceLine,
} from 'recharts'

const MAX_POINTS = 60

function shortTime(isoStr) {
  if (!isoStr) return ''
  const d = new Date(isoStr)
  return `${String(d.getMinutes()).padStart(2,'0')}:${String(d.getSeconds()).padStart(2,'0')}`
}

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div className="panel px-3 py-2 text-[11px] border-cyber-cyan/40 shadow-lg">
      <div className="text-cyber-muted mb-1">{label}</div>
      {payload.map(p => (
        <div key={p.dataKey} className="flex gap-3 justify-between">
          <span style={{ color: p.color }}>{p.name}</span>
          <span className="text-cyber-text font-bold">{
            typeof p.value === 'number' ? p.value.toFixed(2) : p.value
          }</span>
        </div>
      ))}
    </div>
  )
}

function MiniChart({ title, dataKey, data, color, unit, threshold, thresholdLabel }) {
  return (
    <div className="panel p-0">
      <div className="panel-header text-[10px]">
        <span className="dot" style={{ background: color, boxShadow: `0 0 5px ${color}` }} />
        {title}
        {data.length > 0 && (
          <span className="ml-auto text-cyber-text font-bold">
            {data[data.length - 1]?.[dataKey]?.toFixed(2)} {unit}
          </span>
        )}
      </div>
      <div className="px-1 pb-2" style={{ height: 110 }}>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="2 2" stroke="var(--border)" />
            <XAxis
              dataKey="ts"
              tickFormatter={shortTime}
              tick={{ fill: 'var(--muted)', fontSize: 9 }}
              interval="preserveStartEnd"
              tickLine={false}
            />
            <YAxis
              tick={{ fill: 'var(--muted)', fontSize: 9 }}
              tickLine={false}
              axisLine={false}
              width={36}
            />
            <Tooltip content={<CustomTooltip />} />
            {threshold !== undefined && (
              <ReferenceLine
                y={threshold}
                stroke="rgba(255,23,68,0.4)"
                strokeDasharray="4 2"
                label={{ value: thresholdLabel, fill: 'var(--red)', fontSize: 8, position: 'insideTopRight' }}
              />
            )}
            <Line
              type="monotone"
              dataKey={dataKey}
              name={title}
              stroke={color}
              strokeWidth={1.5}
              dot={false}
              activeDot={{ r: 3, fill: color }}
              isAnimationActive={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}

export default function MetricCharts({ metricStream, nodeMap }) {
  const nodeIds = Object.keys(nodeMap)
  const [selectedNode, setSelectedNode] = useState('__all__')

  // Filter + cap data for the selected node
  const filtered = useMemo(() => {
    const raw = selectedNode === '__all__'
      ? metricStream
      : metricStream.filter(m => m.node_id === selectedNode)
    return [...raw].reverse().slice(0, MAX_POINTS).map(m => ({
      ts:               m.timestamp,
      latency_ms:       m.latency_ms,
      packet_loss_pct:  (m.packet_loss_rate || 0) * 100,
      throughput_mbps:  m.throughput_mbps,
      jitter_ms:        m.jitter_ms,
    }))
  }, [metricStream, selectedNode])

  return (
    <div className="panel h-full flex flex-col">
      <div className="panel-header justify-between">
        <div className="flex items-center gap-2">
          <span className="dot dot-cyan" />
          LIVE METRICS
        </div>
        {/* Node selector */}
        <select
          value={selectedNode}
          onChange={e => setSelectedNode(e.target.value)}
          className="bg-cyber-surface border border-cyber-border text-cyber-cyan text-[10px]
                     px-2 py-0.5 rounded font-mono outline-none cursor-pointer
                     hover:border-cyber-cyan/60 transition-colors"
        >
          <option value="__all__">ALL NODES (mixed)</option>
          {nodeIds.map(id => (
            <option key={id} value={id}>{id}</option>
          ))}
        </select>
      </div>

      <div className="flex-1 overflow-y-auto p-3 grid grid-cols-1 gap-3">
        {filtered.length === 0 ? (
          <div className="flex items-center justify-center h-24 text-cyber-muted text-[11px]">
            No metric data yet...
          </div>
        ) : (
          <>
            <MiniChart
              title="LATENCY"
              dataKey="latency_ms"
              data={filtered}
              color="var(--cyan)"
              unit="ms"
              threshold={200}
              thresholdLabel="200ms"
            />
            <MiniChart
              title="PACKET LOSS"
              dataKey="packet_loss_pct"
              data={filtered}
              color="var(--amber)"
              unit="%"
              threshold={5}
              thresholdLabel="5%"
            />
            <MiniChart
              title="THROUGHPUT"
              dataKey="throughput_mbps"
              data={filtered}
              color="var(--green)"
              unit="Mbps"
            />
            <MiniChart
              title="JITTER"
              dataKey="jitter_ms"
              data={filtered}
              color="#b388ff"
              unit="ms"
              threshold={50}
              thresholdLabel="50ms"
            />
          </>
        )}
      </div>
    </div>
  )
}
