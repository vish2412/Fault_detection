/**
 * Core Network Simulation Engine
 * Generates realistic synthetic network telemetry data
 * Mimics behavior of real distributed network nodes
 */

import type {
  NetworkNode,
  NodeMetrics,
  FaultEvent,
  FileTransferEvent,
  LogEntry,
  ScenarioMode,
  FaultType,
  AlertSeverity,
  NodeStatus,
} from './types';
import { mlPredict } from './mlModel';

// ─── Utility Functions ─────────────────────────────────────────────────────────

let _idCounter = 0;
export function genId(): string {
  return `${Date.now()}-${++_idCounter}-${Math.random().toString(36).slice(2, 7)}`;
}

/** Gaussian random (Box-Muller transform) */
function gaussianRandom(mean: number, std: number): number {
  const u1 = Math.random();
  const u2 = Math.random();
  const z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
  return Math.max(0, mean + std * z);
}

/** Clamp value between min and max */
function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

/** Generate simulated SHA256-like checksum */
function genChecksum(): string {
  return Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
}

/** Simulate checksum corruption (flip random chars) */
function corruptChecksum(hash: string): string {
  const chars = hash.split('');
  const corruptions = Math.floor(Math.random() * 8) + 1;
  for (let i = 0; i < corruptions; i++) {
    const idx = Math.floor(Math.random() * chars.length);
    chars[idx] = Math.floor(Math.random() * 16).toString(16);
  }
  return chars.join('');
}

// ─── Node Topology ─────────────────────────────────────────────────────────────

const NODE_CONFIGS = [
  { name: 'CORE-ALPHA',   ip: '10.0.1.1',   region: 'US-East',    type: 'core' as const,     position: { x: 50, y: 50 } },
  { name: 'CORE-BETA',    ip: '10.0.1.2',   region: 'US-West',    type: 'core' as const,     position: { x: 50, y: 300 } },
  { name: 'GW-NORTH',     ip: '10.0.2.1',   region: 'EU-North',   type: 'gateway' as const,  position: { x: 250, y: 30 } },
  { name: 'GW-SOUTH',     ip: '10.0.2.2',   region: 'EU-South',   type: 'gateway' as const,  position: { x: 250, y: 320 } },
  { name: 'EDGE-01',      ip: '192.168.1.1', region: 'APAC',      type: 'edge' as const,     position: { x: 450, y: 80 } },
  { name: 'EDGE-02',      ip: '192.168.1.2', region: 'APAC',      type: 'edge' as const,     position: { x: 450, y: 200 } },
  { name: 'EDGE-03',      ip: '192.168.1.3', region: 'LATAM',     type: 'edge' as const,     position: { x: 450, y: 320 } },
  { name: 'ENDPOINT-WS1', ip: '172.16.0.1', region: 'US-East',   type: 'endpoint' as const, position: { x: 650, y: 50 } },
  { name: 'ENDPOINT-WS2', ip: '172.16.0.2', region: 'US-West',   type: 'endpoint' as const, position: { x: 650, y: 170 } },
  { name: 'ENDPOINT-WS3', ip: '172.16.0.3', region: 'EU-North',  type: 'endpoint' as const, position: { x: 650, y: 290 } },
  { name: 'ENDPOINT-WS4', ip: '172.16.0.4', region: 'APAC',      type: 'endpoint' as const, position: { x: 650, y: 380 } },
  { name: 'ENDPOINT-WS5', ip: '172.16.0.5', region: 'LATAM',     type: 'endpoint' as const, position: { x: 150, y: 420 } },
];

const NODE_CONNECTIONS: [string, string][] = [
  ['CORE-ALPHA', 'CORE-BETA'],
  ['CORE-ALPHA', 'GW-NORTH'],
  ['CORE-ALPHA', 'GW-SOUTH'],
  ['CORE-BETA', 'GW-SOUTH'],
  ['CORE-BETA', 'GW-NORTH'],
  ['GW-NORTH', 'EDGE-01'],
  ['GW-NORTH', 'EDGE-02'],
  ['GW-SOUTH', 'EDGE-02'],
  ['GW-SOUTH', 'EDGE-03'],
  ['EDGE-01', 'ENDPOINT-WS1'],
  ['EDGE-01', 'ENDPOINT-WS2'],
  ['EDGE-02', 'ENDPOINT-WS3'],
  ['EDGE-03', 'ENDPOINT-WS4'],
  ['CORE-BETA', 'ENDPOINT-WS5'],
];

// ─── Normal Baseline per Node Type ─────────────────────────────────────────────

const TYPE_BASELINES = {
  core:     { latency: 8,   jitter: 2,  loss: 0.1, throughput: 950 },
  gateway:  { latency: 18,  jitter: 4,  loss: 0.3, throughput: 500 },
  edge:     { latency: 35,  jitter: 8,  loss: 0.8, throughput: 200 },
  endpoint: { latency: 55,  jitter: 12, loss: 1.5, throughput: 80  },
};

// ─── Main Simulator Class ───────────────────────────────────────────────────────

export class NetworkSimulator {
  private nodes: Map<string, NetworkNode> = new Map();
  private faultRegistry: Map<string, FaultEvent[]> = new Map();
  private logs: LogEntry[] = [];
  private fileTransfers: FileTransferEvent[] = [];
  private scenarioMode: ScenarioMode = 'normal';
  private faultFrequency: number = 0.3;

  private tickCount: number = 0;

  // Per-node fault state (persists across ticks for gradual degradation)
  private nodeFaultState: Map<string, {
    latencySpike: number;
    lossSpike: number;
    throughputDrop: number;
    isOffline: boolean;
    offlineTimer: number;
    corruptionActive: boolean;
  }> = new Map();

  constructor() {
    this.initializeNodes();
  }

  private initializeNodes() {
    NODE_CONFIGS.forEach((config, idx) => {
      const id = `node-${idx + 1}`;
      const initialMetrics = this.generateHealthyMetrics(config.type);
      const node: NetworkNode = {
        id,
        name: config.name,
        ip: config.ip,
        region: config.region,
        type: config.type,
        status: 'healthy',
        lastHeartbeat: Date.now(),
        metrics: [initialMetrics],
        currentMetrics: initialMetrics,
        faults: [],
        connections: [],
        position: config.position,
        uptime: Math.floor(Math.random() * 86400 * 30), // 0-30 days
      };
      this.nodes.set(id, node);
      this.faultRegistry.set(id, []);
      this.nodeFaultState.set(id, {
        latencySpike: 0,
        lossSpike: 0,
        throughputDrop: 0,
        isOffline: false,
        offlineTimer: 0,
        corruptionActive: false,
      });
    });

    // Wire up connections
    NODE_CONNECTIONS.forEach(([nameA, nameB]) => {
      const nodeA = this.getNodeByName(nameA);
      const nodeB = this.getNodeByName(nameB);
      if (nodeA && nodeB) {
        nodeA.connections.push(nodeB.id);
        nodeB.connections.push(nodeA.id);
      }
    });
  }

  private getNodeByName(name: string): NetworkNode | undefined {
    for (const node of this.nodes.values()) {
      if (node.name === name) return node;
    }
    return undefined;
  }

  private generateHealthyMetrics(type: NetworkNode['type']): NodeMetrics {
    const baseline = TYPE_BASELINES[type];
    const checksum = genChecksum();
    return {
      timestamp: Date.now(),
      latency: gaussianRandom(baseline.latency, baseline.latency * 0.15),
      packetLoss: gaussianRandom(baseline.loss, baseline.loss * 0.3),
      throughput: gaussianRandom(baseline.throughput, baseline.throughput * 0.08),
      jitter: gaussianRandom(baseline.jitter, baseline.jitter * 0.2),
      cpuUsage: gaussianRandom(25, 8),
      memoryUsage: gaussianRandom(45, 10),
      hopCount: Math.floor(gaussianRandom(3, 1)) + 1,
      checksum,
      expectedChecksum: checksum,
    };
  }

  // ─── Scenario Appliers ────────────────────────────────────────────────────────

  private applyScenarioToNode(
    nodeId: string,
    _type: NetworkNode['type'],
    baseMetrics: NodeMetrics
  ): NodeMetrics {
    const state = this.nodeFaultState.get(nodeId)!;
    const freq = this.faultFrequency;
    const mode = this.scenarioMode;
    let m = { ...baseMetrics };

    // Decay existing spikes (gradual recovery)
    state.latencySpike *= 0.85;
    state.lossSpike *= 0.88;
    state.throughputDrop *= 0.90;

    // ── Scenario-specific injections ──
    switch (mode) {
      case 'network_outage': {
        // Random nodes go offline, others see extreme degradation
        if (Math.random() < freq * 0.15) {
          state.isOffline = true;
          state.offlineTimer = Math.floor(Math.random() * 8) + 3;
        }
        if (!state.isOffline) {
          state.latencySpike += gaussianRandom(300, 80);
          state.lossSpike += gaussianRandom(25, 8);
          state.throughputDrop += gaussianRandom(60, 15);
        }
        break;
      }
      case 'ddos_attack': {
        // All nodes see high packet loss + latency
        state.latencySpike += gaussianRandom(150, 40) * freq;
        state.lossSpike += gaussianRandom(15, 5) * freq;
        m.cpuUsage = clamp(m.cpuUsage + gaussianRandom(50, 10), 0, 100);
        m.memoryUsage = clamp(m.memoryUsage + gaussianRandom(25, 8), 0, 100);
        break;
      }
      case 'node_cascade_failure': {
        // Failures propagate through connected nodes
        if (Math.random() < freq * 0.12) {
          state.isOffline = true;
          state.offlineTimer = Math.floor(Math.random() * 5) + 2;
        }
        state.latencySpike += gaussianRandom(100, 30);
        state.lossSpike += gaussianRandom(8, 3);
        break;
      }
      case 'high_congestion': {
        // Throughput collapses, latency spikes
        state.throughputDrop += gaussianRandom(70, 20) * freq;
        state.latencySpike += gaussianRandom(200, 60) * freq;
        state.lossSpike += gaussianRandom(5, 2) * freq;
        break;
      }
      case 'data_corruption_wave': {
        state.corruptionActive = Math.random() < freq * 0.6;
        state.latencySpike += gaussianRandom(30, 10);
        break;
      }
      default: {
        // Normal mode: random fault injection based on frequency
        if (Math.random() < freq * 0.08) {
          const faultType = Math.floor(Math.random() * 5);
          switch (faultType) {
            case 0: state.latencySpike += gaussianRandom(180, 50); break;
            case 1: state.lossSpike += gaussianRandom(15, 5); break;
            case 2: state.throughputDrop += gaussianRandom(50, 20); break;
            case 3: state.corruptionActive = Math.random() < 0.4; break;
            case 4:
              if (Math.random() < freq * 0.3) {
                state.isOffline = true;
                state.offlineTimer = Math.floor(Math.random() * 4) + 1;
              }
              break;
          }
        }
      }
    }

    // Handle offline state
    if (state.isOffline) {
      state.offlineTimer--;
      if (state.offlineTimer <= 0) {
        state.isOffline = false;
      }
      // Return zeroed metrics to simulate offline node
      return {
        ...m,
        latency: 0,
        packetLoss: 100,
        throughput: 0,
        jitter: 0,
        timestamp: Date.now(),
      };
    }

    // Apply accumulated spikes
    m.latency = clamp(m.latency + state.latencySpike, 0, 2000);
    m.packetLoss = clamp(m.packetLoss + state.lossSpike, 0, 100);
    m.throughput = clamp(m.throughput - state.throughputDrop, 0, 10000);
    m.jitter = clamp(m.jitter + state.latencySpike * 0.15, 0, 500);

    // Corruption simulation
    if (state.corruptionActive) {
      m.checksum = corruptChecksum(m.expectedChecksum);
      state.corruptionActive = false; // one-shot per tick
    } else {
      m.checksum = m.expectedChecksum;
    }

    m.timestamp = Date.now();
    return m;
  }

  // ─── Fault Detection (Rule-Based + ML Hybrid) ─────────────────────────────────

  private detectFaults(node: NetworkNode, metrics: NodeMetrics): FaultEvent[] {
    const faults: FaultEvent[] = [];
    const now = Date.now();
    const isOffline = this.nodeFaultState.get(node.id)!.isOffline;

    // ── Rule-Based Detection ──

    // NODE_FAILURE: heartbeat timeout
    if (isOffline || (now - node.lastHeartbeat > 5000 && node.status !== 'healthy')) {
      faults.push(this.createFault(node, 'NODE_FAILURE', 'CRITICAL', 'rule-based',
        `Node ${node.name} has stopped sending heartbeats (>${Math.floor((now - node.lastHeartbeat) / 1000)}s timeout)`,
        now - node.lastHeartbeat, 'ms', 0.97));
    }

    // PACKET_LOSS
    if (metrics.packetLoss > 10) {
      const sev: AlertSeverity = metrics.packetLoss > 30 ? 'CRITICAL' : 'MEDIUM';
      faults.push(this.createFault(node, 'PACKET_LOSS', sev, 'rule-based',
        `Packet loss at ${metrics.packetLoss.toFixed(1)}% exceeds threshold (>10%)`,
        metrics.packetLoss, '%', 0.94));
    }

    // HIGH_LATENCY
    if (metrics.latency > 200) {
      const sev: AlertSeverity = metrics.latency > 500 ? 'CRITICAL' : metrics.latency > 300 ? 'MEDIUM' : 'LOW';
      faults.push(this.createFault(node, 'HIGH_LATENCY', sev, 'rule-based',
        `Latency ${metrics.latency.toFixed(0)}ms exceeds threshold (>200ms)`,
        metrics.latency, 'ms', 0.91));
    }

    // DATA_CORRUPTION
    if (metrics.checksum !== metrics.expectedChecksum) {
      faults.push(this.createFault(node, 'DATA_CORRUPTION', 'CRITICAL', 'rule-based',
        `Checksum mismatch detected on ${node.name}. Expected: ${metrics.expectedChecksum.slice(0, 8)}... Got: ${metrics.checksum.slice(0, 8)}...`,
        undefined, undefined, 0.99));
    }

    // CONGESTION (combined signal)
    if (metrics.latency > 150 && metrics.throughput < TYPE_BASELINES[node.type].throughput * 0.4) {
      faults.push(this.createFault(node, 'CONGESTION', 'MEDIUM', 'rule-based',
        `Network congestion: latency ${metrics.latency.toFixed(0)}ms + throughput degraded to ${metrics.throughput.toFixed(1)} Mbps`,
        metrics.throughput, 'Mbps', 0.88));
    }

    // THROUGHPUT_DEGRADATION
    if (metrics.throughput < TYPE_BASELINES[node.type].throughput * 0.25 && metrics.latency <= 200) {
      faults.push(this.createFault(node, 'THROUGHPUT_DEGRADATION', 'MEDIUM', 'rule-based',
        `Throughput dropped to ${metrics.throughput.toFixed(1)} Mbps (${Math.round((metrics.throughput / TYPE_BASELINES[node.type].throughput) * 100)}% of baseline)`,
        metrics.throughput, 'Mbps', 0.86));
    }

    // ── ML-Based Detection (for borderline cases) ──
    const mlResult = mlPredict(
      metrics.latency,
      metrics.packetLoss,
      metrics.throughput,
      metrics.jitter
    );

    // ML detects fault not already caught by rules
    const ruleFaultTypes = new Set(faults.map(f => f.faultType));
    if (
      mlResult.faultType !== 'NORMAL' &&
      !ruleFaultTypes.has(mlResult.faultType) &&
      mlResult.confidence > 0.72
    ) {
      const mlSev: AlertSeverity = mlResult.confidence > 0.9 ? 'CRITICAL' : mlResult.confidence > 0.8 ? 'MEDIUM' : 'LOW';
      faults.push(this.createFault(node, mlResult.faultType, mlSev, 'ml-model',
        `ML model detected ${mlResult.faultType} with ${(mlResult.confidence * 100).toFixed(1)}% confidence`,
        mlResult.confidence, 'confidence', mlResult.confidence));
    }

    // Upgrade detection method to 'hybrid' if both agreed
    if (faults.length > 1 && faults.some(f => f.detectionMethod === 'ml-model')) {
      faults.forEach(f => {
        if (f.detectionMethod === 'rule-based' && ruleFaultTypes.has(f.faultType)) {
          f.detectionMethod = 'hybrid';
          f.mlConfidence = Math.min(0.99, f.mlConfidence + 0.03);
        }
      });
    }

    return faults;
  }

  private createFault(
    node: NetworkNode,
    faultType: FaultType,
    severity: AlertSeverity,
    method: 'rule-based' | 'ml-model' | 'hybrid',
    description: string,
    value?: number,
    unit?: string,
    confidence: number = 0.85
  ): FaultEvent {
    return {
      id: genId(),
      nodeId: node.id,
      nodeName: node.name,
      faultType,
      severity,
      timestamp: Date.now(),
      description,
      value,
      unit,
      resolved: false,
      mlConfidence: confidence,
      detectionMethod: method,
    };
  }

  // ─── Node Status Calculator ────────────────────────────────────────────────────

  private calcNodeStatus(metrics: NodeMetrics, faults: FaultEvent[]): NodeStatus {
    if (metrics.packetLoss >= 90 || metrics.throughput === 0) return 'offline';
    const hasC = faults.some(f => f.severity === 'CRITICAL');
    if (hasC) return 'critical';
    const hasM = faults.some(f => f.severity === 'MEDIUM');
    if (hasM) return 'warning';
    if (faults.length > 0) return 'warning';
    return 'healthy';
  }

  // ─── File Transfer Simulation ─────────────────────────────────────────────────

  private simulateFileTransfer(sourceNode: NetworkNode, targetNode: NetworkNode): FileTransferEvent {
    const fileNames = [
      'config-backup.tar.gz', 'metrics-log.json', 'model-weights.bin',
      'network-snapshot.db', 'health-report.xml', 'firmware-update.img',
      'telemetry-batch.parquet', 'routing-table.csv',
    ];
    const expectedChecksum = genChecksum();
    const corruptionChance = this.faultFrequency * 0.2 + (this.scenarioMode === 'data_corruption_wave' ? 0.5 : 0);
    const corrupted = Math.random() < corruptionChance;
    const fileSize = Math.floor(gaussianRandom(1024 * 1024 * 5, 1024 * 1024 * 3)); // ~5MB avg

    return {
      id: genId(),
      sourceNodeId: sourceNode.id,
      targetNodeId: targetNode.id,
      filename: fileNames[Math.floor(Math.random() * fileNames.length)],
      fileSize: Math.max(fileSize, 1024),
      timestamp: Date.now(),
      expectedChecksum,
      actualChecksum: corrupted ? corruptChecksum(expectedChecksum) : expectedChecksum,
      corrupted,
      transferTime: Math.floor(gaussianRandom(120, 40)),
      status: corrupted ? 'corrupted' : 'success',
    };
  }

  // ─── Log Generator ────────────────────────────────────────────────────────────

  private addLog(
    node: NetworkNode,
    level: LogEntry['level'],
    message: string,
    category: LogEntry['category']
  ) {
    const entry: LogEntry = {
      id: genId(),
      timestamp: Date.now(),
      level,
      nodeId: node.id,
      nodeName: node.name,
      message,
      category,
    };
    this.logs.unshift(entry);
    if (this.logs.length > 500) this.logs = this.logs.slice(0, 500);
  }

  // ─── Main Tick (called every 2s) ─────────────────────────────────────────────

  tick(): {
    nodes: NetworkNode[];
    newFaults: FaultEvent[];
    newTransfers: FileTransferEvent[];
    newLogs: LogEntry[];
  } {
    this.tickCount++;
    const newFaults: FaultEvent[] = [];
    const newTransfers: FileTransferEvent[] = [];
    const newLogs: LogEntry[] = [];

    const nodeList = Array.from(this.nodes.values());

    nodeList.forEach(node => {
      // Generate base healthy metrics
      const baseMetrics = this.generateHealthyMetrics(node.type);

      // Apply scenario/fault simulation
      const metrics = this.applyScenarioToNode(node.id, node.type, baseMetrics);

      const isOffline = this.nodeFaultState.get(node.id)!.isOffline;

      // Update heartbeat (offline nodes don't send heartbeat)
      if (!isOffline) {
        node.lastHeartbeat = Date.now();
        node.uptime += 2;
      }

      // Update metrics history (keep last 60 data points)
      node.currentMetrics = metrics;
      node.metrics.push(metrics);
      if (node.metrics.length > 60) node.metrics = node.metrics.slice(-60);

      // Detect faults
      const faults = isOffline ? [
        this.createFault(node, 'NODE_FAILURE', 'CRITICAL', 'rule-based',
          `Node ${node.name} is OFFLINE — no heartbeat received`, undefined, undefined, 0.99)
      ] : this.detectFaults(node, metrics);

      // Resolve previous faults for this node if now healthy
      const prevFaults = this.faultRegistry.get(node.id) || [];
      prevFaults.forEach(f => {
        if (!f.resolved && faults.length === 0) {
          f.resolved = true;
          f.resolvedAt = Date.now();
        }
      });

      // Register new faults
      if (faults.length > 0) {
        faults.forEach(f => {
          newFaults.push(f);
          this.addLog(node, 'ERROR', `[${f.faultType}] ${f.description}`, 'fault');
        });
        this.faultRegistry.set(node.id, faults);
      } else {
        this.faultRegistry.set(node.id, []);
        if (this.tickCount % 5 === 0) {
          this.addLog(node, 'INFO',
            `Heartbeat OK | Latency: ${metrics.latency.toFixed(1)}ms | Loss: ${metrics.packetLoss.toFixed(2)}% | Throughput: ${metrics.throughput.toFixed(1)} Mbps`,
            'heartbeat');
        }
      }

      // Update node status
      node.status = this.calcNodeStatus(metrics, faults);
      node.faults = faults;

      // Simulate file transfers (every ~10 ticks randomly)
      if (this.tickCount % 8 === 0 && Math.random() < 0.4 && node.connections.length > 0) {
        const targetId = node.connections[Math.floor(Math.random() * node.connections.length)];
        const targetNode = this.nodes.get(targetId);
        if (targetNode) {
          const transfer = this.simulateFileTransfer(node, targetNode);
          this.fileTransfers.unshift(transfer);
          if (this.fileTransfers.length > 100) this.fileTransfers = this.fileTransfers.slice(0, 100);
          newTransfers.push(transfer);

          const logLevel = transfer.corrupted ? 'WARN' : 'INFO';
          const msg = transfer.corrupted
            ? `File transfer CORRUPTED: ${transfer.filename} → ${targetNode.name} (checksum mismatch)`
            : `File transfer OK: ${transfer.filename} → ${targetNode.name} (${(transfer.fileSize / 1024).toFixed(0)} KB in ${transfer.transferTime}ms)`;
          this.addLog(node, logLevel, msg, 'file_transfer');
          newLogs.push(this.logs[0]);
        }
      }
    });

    // Add scenario info log periodically
    if (this.tickCount % 10 === 0) {
      const systemLog: LogEntry = {
        id: genId(),
        timestamp: Date.now(),
        level: 'INFO',
        nodeId: 'system',
        nodeName: 'SYSTEM',
        message: `Simulation tick #${this.tickCount} | Mode: ${this.scenarioMode.toUpperCase()} | Fault freq: ${(this.faultFrequency * 100).toFixed(0)}% | Active nodes: ${nodeList.filter(n => n.status !== 'offline').length}/${nodeList.length}`,
        category: 'system',
      };
      this.logs.unshift(systemLog);
      newLogs.unshift(systemLog);
    }

    newLogs.push(...this.logs.slice(0, 3).filter(l => !newLogs.includes(l)));

    return {
      nodes: nodeList,
      newFaults,
      newTransfers,
      newLogs,
    };
  }

  // ─── Public API ───────────────────────────────────────────────────────────────

  setScenarioMode(mode: ScenarioMode) {
    this.scenarioMode = mode;
    // Reset fault states on scenario change
    this.nodeFaultState.forEach((state) => {
      state.latencySpike = 0;
      state.lossSpike = 0;
      state.throughputDrop = 0;
    });
  }

  setFaultFrequency(freq: number) {
    this.faultFrequency = clamp(freq, 0, 1);
  }

  getNodes(): NetworkNode[] {
    return Array.from(this.nodes.values());
  }

  getLogs(): LogEntry[] {
    return this.logs;
  }

  getFileTransfers(): FileTransferEvent[] {
    return this.fileTransfers;
  }

  getAllFaults(): FaultEvent[] {
    const all: FaultEvent[] = [];
    this.faultRegistry.forEach(faults => all.push(...faults));
    this.nodes.forEach(node => {
      // Include historical faults too
      all.push(...node.faults);
    });
    return all;
  }

  forceNodeFault(nodeId: string, faultType: FaultType) {
    const state = this.nodeFaultState.get(nodeId);
    if (!state) return;
    switch (faultType) {
      case 'HIGH_LATENCY': state.latencySpike = 400; break;
      case 'PACKET_LOSS': state.lossSpike = 35; break;
      case 'NODE_FAILURE': state.isOffline = true; state.offlineTimer = 5; break;
      case 'CONGESTION': state.latencySpike = 300; state.throughputDrop = 150; break;
      case 'THROUGHPUT_DEGRADATION': state.throughputDrop = 180; break;
      case 'DATA_CORRUPTION': state.corruptionActive = true; break;
    }
  }

  recoverNode(nodeId: string) {
    const state = this.nodeFaultState.get(nodeId);
    if (!state) return;
    state.latencySpike = 0;
    state.lossSpike = 0;
    state.throughputDrop = 0;
    state.isOffline = false;
    state.offlineTimer = 0;
    state.corruptionActive = false;
  }
}
