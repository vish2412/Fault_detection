/**
 * MetricCharts.jsx
 * ----------------
 * Four live Recharts charts (latency, packet loss, throughput, jitter)
 * for the selected node, fed from the in-memory metric history.
 *
 * Supports a `compact` prop for the overview tab (fewer controls, smaller charts).
 */

import React, { useState, useMemo } from "react";
import { clsx } from "clsx";
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  ReferenceLine,
} from "recharts";
import { getMetricColor, formatMetric } from "../hooks/useMetricColor.js";
import CONFIG from "../config.js";

const T = CONFIG.THRESHOLDS;

// ── Custom tooltip ─────────────────────────────────────────────────────────────
function ChartTooltip({ active, payload, label, metricKey, unit }) {
  if (!active || !payload?.length) return null;
  const val = payload[0]?.value;
  const { textClass } = getMetricColor(metricKey, val);
  return (
    <div className="glass-card px-3 py-2 text-xs shadow-xl border border-surface-500/50">
      <p className="text-slate-400 mb-1">{label}</p>
      <p className={clsx("font-mono font-semibold", textClass)}>
        {formatMetric(metricKey, val)}
      </p>
    </div>
  );
}

// ── Tick formatter ─────────────────────────────────────────────────────────────
function shortTs(ts) {
  if (!ts) return "";
  try {
    const d = new Date(ts);
    return `${d.getHours().toString().padStart(2,"0")}:${d.getMinutes().toString().padStart(2,"0")}:${d.getSeconds().toString().padStart(2,"0")}`;
  } catch { return ""; }
}

// ── Individual chart card ──────────────────────────────────────────────────────
function ChartCard({ title, metricKey, data, chartType = "line", compact }) {
  const latest = data.length ? data[data.length - 1]?.[metricKey] : null;
  const { hexColor, textClass } = getMetricColor(metricKey, latest);
  const height = compact ? 120 : 180;

  // Threshold reference lines
  const warnThresh  = T[metricKey]?.warn;
  const critThresh  = T[metricKey]?.crit;
  const isInverted  = metricKey === "throughput_mbps";

  // Y-axis domain
  const values = data.map((d) => d[metricKey]).filter((v) => v != null);
  const minV   = values.length ? Math.min(...values) : 0;
  const maxV   = values.length ? Math.max(...values) : 1;
  const pad    = (maxV - minV) * 0.15 || 1;
  const yMin   = Math.max(0, minV - pad);
  const yMax   = maxV + pad;

  const chartData = data.map((d) => ({
    ts:          shortTs(d.timestamp),
    [metricKey]: d[metricKey] != null ? parseFloat(d[metricKey].toFixed(3)) : null,
  }));

  const commonProps = {
    data: chartData,
    margin: { top: 4, right: 8, left: -16, bottom: 0 },
  };

  const axisProps = {
    tick:   { fontSize: 10, fill: "#64748b", fontFamily: "JetBrains Mono, monospace" },
    tickLine: false,
    axisLine: false,
  };

  return (
    <div className="glass-card p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-xs font-semibold text-slate-300">{title}</h3>
        <span className={clsx("mono-value text-sm font-bold", textClass)}>
          {formatMetric(metricKey, latest)}
        </span>
      </div>

      {/* Chart */}
      <ResponsiveContainer width="100%" height={height}>
        {chartType === "area" ? (
          <AreaChart {...commonProps}>
            <defs>
              <linearGradient id={`grad-${metricKey}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%"  stopColor={hexColor} stopOpacity={0.25} />
                <stop offset="95%" stopColor={hexColor} stopOpacity={0.02} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="ts" {...axisProps} interval="preserveStartEnd" />
            <YAxis domain={[yMin, yMax]} {...axisProps} />
            <Tooltip content={<ChartTooltip metricKey={metricKey} />} />
            {!isInverted && warnThresh != null && (
              <ReferenceLine y={warnThresh} stroke="#fbbf24" strokeDasharray="4 2" strokeWidth={1} />
            )}
            {!isInverted && critThresh != null && (
              <ReferenceLine y={critThresh} stroke="#f87171" strokeDasharray="4 2" strokeWidth={1} />
            )}
            {isInverted && warnThresh != null && (
              <ReferenceLine y={warnThresh} stroke="#fbbf24" strokeDasharray="4 2" strokeWidth={1} />
            )}
            <Area
              type="monotone"
              dataKey={metricKey}
              stroke={hexColor}
              strokeWidth={2}
              fill={`url(#grad-${metricKey})`}
              dot={false}
              isAnimationActive={false}
              connectNulls
            />
          </AreaChart>
        ) : chartType === "bar" ? (
          <BarChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="ts" {...axisProps} interval="preserveStartEnd" />
            <YAxis domain={[yMin, yMax]} {...axisProps} />
            <Tooltip content={<ChartTooltip metricKey={metricKey} />} />
            {warnThresh != null && (
              <ReferenceLine y={warnThresh} stroke="#fbbf24" strokeDasharray="4 2" strokeWidth={1} />
            )}
            <Bar
              dataKey={metricKey}
              fill={hexColor}
              fillOpacity={0.8}
              radius={[2, 2, 0, 0]}
              isAnimationActive={false}
            />
          </BarChart>
        ) : (
          <LineChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="ts" {...axisProps} interval="preserveStartEnd" />
            <YAxis domain={[yMin, yMax]} {...axisProps} />
            <Tooltip content={<ChartTooltip metricKey={metricKey} />} />
            {!isInverted && warnThresh != null && (
              <ReferenceLine y={warnThresh} stroke="#fbbf24" strokeDasharray="4 2" strokeWidth={1} />
            )}
            {!isInverted && critThresh != null && (
              <ReferenceLine y={critThresh} stroke="#f87171" strokeDasharray="4 2" strokeWidth={1} />
            )}
            <Line
              type="monotone"
              dataKey={metricKey}
              stroke={hexColor}
              strokeWidth={2}
              dot={false}
              isAnimationActive={false}
              connectNulls
            />
          </LineChart>
        )}
      </ResponsiveContainer>

      {/* Threshold legend */}
      {!compact && (warnThresh != null || critThresh != null) && (
        <div className="flex gap-4 mt-2 pt-2 border-t border-surface-600/40">
          {warnThresh != null && (
            <span className="flex items-center gap-1 text-[10px] text-amber-400">
              <span className="inline-block w-3 h-0.5 bg-amber-400" />
              warn {isInverted ? "≤" : "≥"} {formatMetric(metricKey, warnThresh)}
            </span>
          )}
          {critThresh != null && (
            <span className="flex items-center gap-1 text-[10px] text-red-400">
              <span className="inline-block w-3 h-0.5 bg-red-400" />
              crit {isInverted ? "≤" : "≥"} {formatMetric(metricKey, critThresh)}
            </span>
          )}
        </div>
      )}
    </div>
  );
}

// ── MetricCharts ──────────────────────────────────────────────────────────────
export default function MetricCharts({
  nodes,
  metricHistory,
  selectedNodeId,
  onSelectNode,
  compact = false,
}) {
  const history = useMemo(
    () => (selectedNodeId ? (metricHistory[selectedNodeId] || []) : []),
    [metricHistory, selectedNodeId]
  );

  return (
    <div>
      {/* Node selector */}
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <h2 className="section-title">Live Metrics</h2>
        <div className="flex items-center gap-2 flex-wrap">
          {nodes.map((n) => (
            <button
              key={n.node_id}
              onClick={() => onSelectNode(n.node_id)}
              className={clsx(
                "px-3 py-1 rounded-full text-xs font-medium border transition-all",
                selectedNodeId === n.node_id
                  ? "bg-brand-600/30 border-brand-400/50 text-brand-300"
                  : "bg-surface-700 border-surface-500 text-slate-400 hover:border-brand-500/40 hover:text-slate-200"
              )}
            >
              <span className={clsx(
                "inline-block w-1.5 h-1.5 rounded-full mr-1.5",
                n.status === "online" ? "bg-emerald-400" : "bg-red-500"
              )} />
              {n.node_id}
            </button>
          ))}
        </div>
      </div>

      {!selectedNodeId || nodes.length === 0 ? (
        <div className="glass-card p-8 text-center">
          <p className="text-slate-400">Select a node above to view its metrics.</p>
        </div>
      ) : history.length === 0 ? (
        <div className="glass-card p-8 text-center">
          <div className="text-2xl mb-2">📊</div>
          <p className="text-slate-400 text-sm">Waiting for metric data from <span className="text-brand-300 font-mono">{selectedNodeId}</span>…</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <ChartCard
            title="Latency (ms)"
            metricKey="latency_ms"
            data={history}
            chartType="line"
            compact={compact}
          />
          <ChartCard
            title="Packet Loss Rate"
            metricKey="packet_loss_rate"
            data={history}
            chartType="area"
            compact={compact}
          />
          <ChartCard
            title="Throughput (Mbps)"
            metricKey="throughput_mbps"
            data={history}
            chartType="bar"
            compact={compact}
          />
          <ChartCard
            title="Jitter (ms)"
            metricKey="jitter_ms"
            data={history}
            chartType="line"
            compact={compact}
          />
        </div>
      )}
    </div>
  );
}
