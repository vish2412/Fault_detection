import logging
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


class FaultType(str, Enum):
    NODE_FAILURE = "NODE_FAILURE"
    HIGH_LATENCY = "HIGH_LATENCY"
    PACKET_LOSS = "PACKET_LOSS"
    THROUGHPUT_DEGRADATION = "THROUGHPUT_DEGRADATION"
    NETWORK_CONGESTION = "NETWORK_CONGESTION"
    DATA_CORRUPTION = "DATA_CORRUPTION"
    NORMAL = "NORMAL"


class Severity(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    CRITICAL = "CRITICAL"


FAULT_SEVERITY_MAP: Dict[FaultType, Severity] = {
    FaultType.NODE_FAILURE: Severity.CRITICAL,
    FaultType.HIGH_LATENCY: Severity.MEDIUM,
    FaultType.PACKET_LOSS: Severity.MEDIUM,
    FaultType.THROUGHPUT_DEGRADATION: Severity.MEDIUM,
    FaultType.NETWORK_CONGESTION: Severity.HIGH if hasattr(Severity, "HIGH") else Severity.CRITICAL,
    FaultType.DATA_CORRUPTION: Severity.CRITICAL,
    FaultType.NORMAL: Severity.LOW,
}

# Remap NETWORK_CONGESTION to CRITICAL since we only have LOW/MEDIUM/CRITICAL
FAULT_SEVERITY_MAP[FaultType.NETWORK_CONGESTION] = Severity.CRITICAL


class FaultEvent:
    def __init__(
        self,
        node_id: str,
        fault_type: FaultType,
        severity: Severity,
        description: str,
        metric_snapshot: Optional[Dict] = None,
        source: str = "rule_engine",
    ):
        self.node_id = node_id
        self.fault_type = fault_type
        self.severity = severity
        self.description = description
        self.metric_snapshot = metric_snapshot or {}
        self.source = source
        self.timestamp = datetime.utcnow()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_id": self.node_id,
            "fault_type": self.fault_type.value,
            "severity": self.severity.value,
            "description": self.description,
            "metric_snapshot": self.metric_snapshot,
            "source": self.source,
            "timestamp": self.timestamp.isoformat(),
        }


class RuleBasedFaultDetector:
    """
    Applies threshold-based rules to a metric payload and returns
    a list of detected FaultEvents.
    """

    def __init__(self):
        self.latency_threshold = settings.LATENCY_THRESHOLD_MS
        self.packet_loss_threshold = settings.PACKET_LOSS_THRESHOLD
        self.throughput_min = settings.THROUGHPUT_MIN_MBPS
        self.jitter_threshold = settings.JITTER_THRESHOLD_MS

        # Per-node sliding window for congestion detection
        # node_id -> list of recent degradation flags
        self._degradation_window: Dict[str, List[bool]] = {}
        self._window_size: int = 5   # number of samples to consider

    def detect(self, node_id: str, metrics: Dict[str, Any]) -> List[FaultEvent]:
        faults: List[FaultEvent] = []

        latency: float = metrics.get("latency_ms", 0.0)
        packet_loss: float = metrics.get("packet_loss_rate", 0.0)   # 0.0 – 1.0
        throughput: float = metrics.get("throughput_mbps", 9999.0)
        jitter: float = metrics.get("jitter_ms", 0.0)
        checksum_ok: Optional[bool] = metrics.get("checksum_ok", None)

        snapshot = {
            "latency_ms": latency,
            "packet_loss_rate": packet_loss,
            "throughput_mbps": throughput,
            "jitter_ms": jitter,
        }

        # --- Rule 1: High Latency ---
        if latency > self.latency_threshold:
            faults.append(
                FaultEvent(
                    node_id=node_id,
                    fault_type=FaultType.HIGH_LATENCY,
                    severity=Severity.MEDIUM if latency < self.latency_threshold * 2 else Severity.CRITICAL,
                    description=(
                        f"Latency {latency:.1f}ms exceeds threshold {self.latency_threshold}ms"
                    ),
                    metric_snapshot=snapshot,
                )
            )

        # --- Rule 2: Packet Loss ---
        if packet_loss > self.packet_loss_threshold:
            severity = (
                Severity.CRITICAL if packet_loss > 0.20 else Severity.MEDIUM
            )
            faults.append(
                FaultEvent(
                    node_id=node_id,
                    fault_type=FaultType.PACKET_LOSS,
                    severity=severity,
                    description=(
                        f"Packet loss {packet_loss*100:.1f}% exceeds threshold "
                        f"{self.packet_loss_threshold*100:.1f}%"
                    ),
                    metric_snapshot=snapshot,
                )
            )

        # --- Rule 3: Throughput Degradation ---
        if throughput < self.throughput_min:
            faults.append(
                FaultEvent(
                    node_id=node_id,
                    fault_type=FaultType.THROUGHPUT_DEGRADATION,
                    severity=Severity.MEDIUM,
                    description=(
                        f"Throughput {throughput:.2f} Mbps below minimum {self.throughput_min} Mbps"
                    ),
                    metric_snapshot=snapshot,
                )
            )

        # --- Rule 4: Jitter / Congestion ---
        is_degraded = latency > self.latency_threshold * 0.7 or packet_loss > self.packet_loss_threshold * 0.5
        window = self._degradation_window.setdefault(node_id, [])
        window.append(is_degraded)
        if len(window) > self._window_size:
            window.pop(0)

        if len(window) == self._window_size and all(window):
            faults.append(
                FaultEvent(
                    node_id=node_id,
                    fault_type=FaultType.NETWORK_CONGESTION,
                    severity=Severity.CRITICAL,
                    description=(
                        f"Sustained degradation over {self._window_size} consecutive samples — "
                        f"network congestion detected. Jitter: {jitter:.1f}ms"
                    ),
                    metric_snapshot=snapshot,
                )
            )

        # --- Rule 5: Data Corruption ---
        if checksum_ok is False:
            faults.append(
                FaultEvent(
                    node_id=node_id,
                    fault_type=FaultType.DATA_CORRUPTION,
                    severity=Severity.CRITICAL,
                    description="Checksum mismatch detected — file data corrupted in transit",
                    metric_snapshot=snapshot,
                )
            )

        return faults

    def node_failure(self, node_id: str) -> FaultEvent:
        return FaultEvent(
            node_id=node_id,
            fault_type=FaultType.NODE_FAILURE,
            severity=Severity.CRITICAL,
            description=f"Node {node_id} has not sent a heartbeat within {settings.WS_HEARTBEAT_TIMEOUT}s",
            source="heartbeat_monitor",
        )


# Singleton
rule_detector = RuleBasedFaultDetector()
