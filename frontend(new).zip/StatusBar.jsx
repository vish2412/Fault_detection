// src/components/StatusBar.jsx
import React, { useState, useEffect } from 'react'
import config from '../config'

export default function StatusBar({ connected, error, nodeMap, alertFeed }) {
  const [tick, setTick] = useState(0)

  // Clock tick
  useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 1000)
    return () => clearInterval(id)
  }, [])

  const now = new Date().toLocaleTimeString([], {
    hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit',
  })

  const nodes  = Object.values(nodeMap)
  const online  = nodes.filter(n => n.status === 'online').length
  const critical = alertFeed.filter(a => a.severity === 'CRITICAL').length

  return (
    <header className="flex items-center justify-between px-4 py-2 border-b border-cyber-border
                        bg-cyber-surface/80 backdrop-blur-sm sticky top-0 z-50">
      {/* Left: Brand */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1.5">
          {/* Logo mark */}
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <polygon points="10,1 19,6 19,14 10,19 1,14 1,6" stroke="var(--cyan)" strokeWidth="1.5" fill="none" />
            <circle cx="10" cy="10" r="3" fill="var(--cyan)" opacity="0.8" />
            <line x1="10" y1="1" x2="10" y2="7" stroke="var(--cyan)" strokeWidth="1" />
            <line x1="10" y1="13" x2="10" y2="19" stroke="var(--cyan)" strokeWidth="1" />
          </svg>
          <span className="font-display font-800 text-[15px] tracking-tight glow-cyan">NetFault</span>
        </div>
        <span className="text-cyber-muted text-[10px] hidden sm:block">
          AI Network Fault Detection System
        </span>
      </div>

      {/* Center: Stats */}
      <div className="flex items-center gap-4 text-[10px] font-mono">
        <div className="flex items-center gap-1.5">
          <span className={`dot ${online > 0 ? 'dot-green' : 'dot-muted'}`} />
          <span className="text-cyber-muted">NODES</span>
          <span className="text-cyber-green font-bold">{online}</span>
          <span className="text-cyber-muted">/ {nodes.length}</span>
        </div>

        <div className="hidden sm:flex items-center gap-1.5">
          <span className={`dot ${critical > 0 ? 'dot-red animate-pulse-slow' : 'dot-muted'}`} />
          <span className="text-cyber-muted">CRITICAL</span>
          <span className={`font-bold ${critical > 0 ? 'text-cyber-red' : 'text-cyber-muted'}`}>
            {critical}
          </span>
        </div>
      </div>

      {/* Right: Connection + clock */}
      <div className="flex items-center gap-3 text-[10px] font-mono">
        {error ? (
          <div className="flex items-center gap-1.5 text-cyber-red">
            <span className="dot dot-red animate-pulse-slow" />
            <span className="hidden sm:block">ERROR</span>
          </div>
        ) : connected ? (
          <div className="flex items-center gap-1.5">
            <span className="dot dot-green animate-pulse-slow" />
            <span className="text-cyber-green hidden sm:block">LIVE</span>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 text-cyber-amber">
            <span className="dot dot-amber animate-pulse-slow" />
            <span className="hidden sm:block">CONNECTING...</span>
          </div>
        )}

        <div className="text-cyber-muted border-l border-cyber-border pl-3">
          {now}
        </div>
      </div>
    </header>
  )
}
