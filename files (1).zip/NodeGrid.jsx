/**
 * NodeGrid.jsx
 * ------------
 * Renders a responsive grid of node status cards.
 * Each card shows: status dot, node ID, hostname, last-seen, and latest metric bars.
 * Clicking a card selects that node for chart/detail views.
 */

import React from "react";
import { clsx } from "clsx";
import { getMetricColor, formatMetric } from "../hooks/useMetricColor.js";
import { formatDistanceToNowStrict } from "date-fns";

// ── Helpers ───────────────────────────────────────────────────────────────────
function relativeTime(isoTs) {
  if (!isoTs) return "never";
  try {
    return formatDistanceToNowStrict(new Date(isoTs), { addSuffix: true });
  } catch {
    return "—";
  }
}

function statusConfig(status) {
  switch (status) {
    case "online":  return { dot: "status-dot-online",  badge: "text-emerald-400 bg-emerald-500/10 border-emerald-500/30", label: "ONLINE"  };
    case "offline": return { dot: "status-dot-offline", badge: "text-red-400 bg-red-500/10 border-red-500/30",             label: "OFFLINE" };
    default:        return { dot: "status-dot-unknown", badge: "text-slate-400 bg-slate-500/10 border-slate-500/30",        label: "UNKNOWN" };
  }
}

// ── Metric mini-row ───────────────────────────────────────────────────────────
const MINI_METRICS = [
  { key: "latency_ms",       label: "Latency",    maxNorm: 500  },
  { key: "packet_loss_rate", label: "Loss",       maxNorm: 1    },
  { key: "throughput_mbps",  label: "Throughput", maxNorm: 1000 },
  { key: "jitter_ms",        label: "Jitter",     maxNorm: 200  },
];

function MetricBar({ metricKey, value, maxNorm }) {
  const { hexColor, textClass } = getMetricColor(metricKey, value);
  const pct = value == null ? 0
    : metricKey === "throughput_mbps"
      ? Math.min(100, (value / maxNorm) * 100)
      : Math.min(100, (value / maxNorm) * 100);

  return (
    <div className="flex items-center gap-2 min-w-0">
      <div className="flex-1 h-1 bg-surface-600 rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${pct}%`, backgroundColor: hexColor }}
        />
      </div>
      <span className={clsx("text-[10px] font-mono w-16 text-right flex-shrink-0", textClass)}>
        {formatMetric(metricKey, value)}
      </span>
    </div>
  );
}

// ── Single node card ──────────────────────────────────────────────────────────
function NodeCard({ node, isSelected, onSelect }) {
  const cfg    = statusConfig(node.status);
  const m      = node.latestMetrics || {};
  const isOff  = node.status === "offline";

  return (
    <button
      onClick={() => onSelect(node.node_id)}
      className={clsx(
        "w-full text-left glass-card p-4 transition-all duration-200 cursor-pointer",
        "hover:border-brand-500/50 hover:shadow-glow-blue focus:outline-none focus:ring-2 focus:ring-brand-500/50",
        isSelected && "border-brand-400/60 shadow-glow-blue",
        isOff && "opacity-70"
      )}
    >
      {/* ── Card header ──────────────────────────────────────────────────── */}
      <div className="flex items-start justify-between gap-2 mb-3">
        <div className="flex items-center gap-2 min-w-0">
          <span className={cfg.dot} />
          <div className="min-w-0">
            <p className="text-sm font-semibold text-slate-100 truncate leading-tight">
              {node.node_id}
            </p>
            {node.hostname && (
              <p className="text-[11px] text-slate-500 truncate font-mono mt-0.5">
                {node.hostname}
              </p>
            )}
          </div>
        </div>
        <span className={clsx(
          "flex-shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-full border",
          cfg.badge
        )}>
          {cfg.label}
        </span>
      </div>

      {/* ── Metric bars (hidden when offline and no latest data) ─────────── */}
      {!isOff && (
        <div className="space-y-1.5 mb-3">
          {MINI_METRICS.map(({ key, label, maxNorm }) => (
            <div key={key}>
              <p className="text-[10px] text-slate-500 mb-0.5">{label}</p>
              <MetricBar metricKey={key} value={m[key]} maxNorm={maxNorm} />
            </div>
          ))}
        </div>
      )}

      {isOff && (
        <div className="flex items-center gap-2 py-3 text-red-400/70 text-xs">
          <span>⚠</span>
          <span>Node unreachable — no heartbeat</span>
        </div>
      )}

      {/* ── Footer: last seen + IP ────────────────────────────────────────── */}
      <div className="flex items-center justify-between pt-2 border-t border-surface-600/50">
        <span className="text-[10px] text-slate-500">
          Last seen {relativeTime(node.last_seen)}
        </span>
        {node.ip_address && (
          <span className="text-[10px] font-mono text-slate-500">{node.ip_address}</span>
        )}
      </div>
    </button>
  );
}

// ── Empty state ───────────────────────────────────────────────────────────────
function EmptyState() {
  return (
    <div className="glass-card p-12 text-center col-span-full">
      <div className="text-4xl mb-3">📡</div>
      <p className="text-slate-300 font-medium">Waiting for nodes to connect…</p>
      <p className="text-slate-500 text-sm mt-1">
        Start the simulation client: <code className="font-mono bg-surface-700 px-1.5 py-0.5 rounded">python node_client.py</code>
      </p>
    </div>
  );
}

// ── NodeGrid ──────────────────────────────────────────────────────────────────
export default function NodeGrid({ nodes, selectedNodeId, onSelectNode }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <h2 className="section-title">Node Status</h2>
        <span className="text-xs text-slate-500">{nodes.length} node(s) registered</span>
      </div>

      <div className={clsx(
        "grid gap-4",
        "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5"
      )}>
        {nodes.length === 0
          ? <EmptyState />
          : nodes.map((node) => (
              <div key={node.node_id} className="animate-slide-in-up">
                <NodeCard
                  node={node}
                  isSelected={selectedNodeId === node.node_id}
                  onSelect={onSelectNode}
                />
              </div>
            ))
        }
      </div>
    </div>
  );
}
