export type NodeStatus = 'healthy' | 'warning' | 'critical' | 'offline';
export type FaultType =
  | 'PACKET_LOSS'
  | 'HIGH_LATENCY'
  | 'NODE_FAILURE'
  | 'DATA_CORRUPTION'
  | 'CONGESTION'
  | 'THROUGHPUT_DEGRADATION';

export type AlertSeverity = 'LOW' | 'MEDIUM' | 'CRITICAL';

export type ScenarioMode =
  | 'normal'
  | 'network_outage'
  | 'ddos_attack'
  | 'node_cascade_failure'
  | 'high_congestion'
  | 'data_corruption_wave';

export interface NodeMetrics {
  timestamp: number;
  latency: number;        // ms
  packetLoss: number;     // %
  throughput: number;     // Mbps
  jitter: number;         // ms
  cpuUsage: number;       // %
  memoryUsage: number;    // %
  hopCount: number;
  checksum: string;
  expectedChecksum: string;
}

export interface NetworkNode {
  id: string;
  name: string;
  ip: string;
  region: string;
  type: 'edge' | 'core' | 'gateway' | 'endpoint';
  status: NodeStatus;
  lastHeartbeat: number;
  metrics: NodeMetrics[];
  currentMetrics: NodeMetrics;
  faults: FaultEvent[];
  connections: string[]; // connected node IDs
  position: { x: number; y: number };
  uptime: number; // seconds
}

export interface FaultEvent {
  id: string;
  nodeId: string;
  nodeName: string;
  faultType: FaultType;
  severity: AlertSeverity;
  timestamp: number;
  description: string;
  value?: number;
  unit?: string;
  resolved: boolean;
  resolvedAt?: number;
  mlConfidence: number; // 0-1
  detectionMethod: 'rule-based' | 'ml-model' | 'hybrid';
}

export interface FileTransferEvent {
  id: string;
  sourceNodeId: string;
  targetNodeId: string;
  filename: string;
  fileSize: number; // bytes
  timestamp: number;
  expectedChecksum: string;
  actualChecksum: string;
  corrupted: boolean;
  transferTime: number; // ms
  status: 'success' | 'corrupted' | 'failed';
}

export interface LogEntry {
  id: string;
  timestamp: number;
  level: 'INFO' | 'WARN' | 'ERROR' | 'DEBUG';
  nodeId: string;
  nodeName: string;
  message: string;
  category: 'heartbeat' | 'fault' | 'recovery' | 'file_transfer' | 'ml_detection' | 'system';
}

export interface SystemStats {
  totalNodes: number;
  onlineNodes: number;
  offlineNodes: number;
  warningNodes: number;
  criticalNodes: number;
  totalFaults: number;
  activeFaults: number;
  resolvedFaults: number;
  avgLatency: number;
  avgPacketLoss: number;
  avgThroughput: number;
  totalFileTransfers: number;
  corruptedTransfers: number;
  mlAccuracy: number;
  uptime: number;
}

export interface SimulationConfig {
  faultFrequency: number;   // 0-1
  scenarioMode: ScenarioMode;
  nodeCount: number;
  simulationSpeed: number;  // 1x, 2x, 5x
  enableML: boolean;
  enableCorruption: boolean;
}

export interface MLPrediction {
  faultType: FaultType | 'NORMAL';
  confidence: number;
  features: {
    latency: number;
    packetLoss: number;
    throughput: number;
    jitter: number;
  };
  treeVotes: { [key: string]: number };
}
