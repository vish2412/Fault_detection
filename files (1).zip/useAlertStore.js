/**
 * useAlertStore.js
 * ----------------
 * Manages the fault alert list with unread-count tracking.
 *
 * Alert shape:
 *   {
 *     id:           string          — unique identifier
 *     nodeId:       string
 *     faultType:    string          — e.g. "HIGH_LATENCY"
 *     severity:     "LOW" | "MEDIUM" | "CRITICAL"
 *     description:  string
 *     source:       "rule_engine" | "ml_engine" | "heartbeat_monitor"
 *     mlPrediction: object | null
 *     ts:           ISO string
 *     read:         boolean
 *   }
 */

import { useState, useCallback, useMemo } from "react";
import CONFIG from "../config.js";

const MAX_ALERTS = CONFIG.MAX_ALERT_ENTRIES;

export function useAlertStore() {
  const [alerts, setAlerts] = useState([]);

  // ── addAlert ────────────────────────────────────────────────────────────────
  const addAlert = useCallback((alert) => {
    setAlerts((prev) => {
      const next = [{ ...alert, read: false }, ...prev];
      return next.length > MAX_ALERTS ? next.slice(0, MAX_ALERTS) : next;
    });
  }, []);

  // ── markAllRead ─────────────────────────────────────────────────────────────
  const markAllRead = useCallback(() => {
    setAlerts((prev) => {
      if (prev.every((a) => a.read)) return prev;
      return prev.map((a) => (a.read ? a : { ...a, read: true }));
    });
  }, []);

  // ── markRead ────────────────────────────────────────────────────────────────
  const markRead = useCallback((id) => {
    setAlerts((prev) =>
      prev.map((a) => (a.id === id ? { ...a, read: true } : a))
    );
  }, []);

  // ── clearAlerts ─────────────────────────────────────────────────────────────
  const clearAlerts = useCallback(() => setAlerts([]), []);

  // ── unreadCount — derived ───────────────────────────────────────────────────
  const unreadCount = useMemo(
    () => alerts.filter((a) => !a.read).length,
    [alerts]
  );

  return {
    alerts,
    unreadCount,
    addAlert,
    markAllRead,
    markRead,
    clearAlerts,
  };
}
