import { motion, AnimatePresence } from 'framer-motion';
import { useSimulationStore } from '../../store/simulationStore';
import { StatusBadge } from '../ui/StatusBadge';
import type { FaultEvent } from '../../simulation/types';
import { formatDistanceToNow } from 'date-fns';

const FAULT_ICONS: Record<string, string> = {
  PACKET_LOSS: '📦',
  HIGH_LATENCY: '⚡',
  NODE_FAILURE: '💀',
  DATA_CORRUPTION: '🔴',
  CONGESTION: '🌊',
  THROUGHPUT_DEGRADATION: '📉',
};

const FAULT_COLORS: Record<string, string> = {
  PACKET_LOSS: 'border-l-amber-500',
  HIGH_LATENCY: 'border-l-yellow-500',
  NODE_FAILURE: 'border-l-red-600',
  DATA_CORRUPTION: 'border-l-red-500',
  CONGESTION: 'border-l-orange-500',
  THROUGHPUT_DEGRADATION: 'border-l-blue-500',
};

function AlertRow({ fault }: { fault: FaultEvent }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className={`
        relative rounded-lg border border-slate-700/50 border-l-4 bg-slate-800/50 p-3
        ${FAULT_COLORS[fault.faultType] || 'border-l-slate-500'}
        ${fault.resolved ? 'opacity-50' : ''}
      `}
    >
      <div className="flex items-start gap-3">
        <span className="text-xl flex-shrink-0 mt-0.5">{FAULT_ICONS[fault.faultType] || '⚠️'}</span>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-bold text-white font-mono">{fault.faultType.replace(/_/g, ' ')}</span>
            <StatusBadge severity={fault.severity} size="sm" pulse={!fault.resolved && fault.severity === 'CRITICAL'} />
            {fault.resolved && (
              <span className="text-xs text-emerald-400 font-mono">✓ RESOLVED</span>
            )}
            <span className={`text-xs font-mono px-1.5 py-0.5 rounded ${
              fault.detectionMethod === 'ml-model' ? 'bg-violet-500/20 text-violet-400' :
              fault.detectionMethod === 'hybrid' ? 'bg-blue-500/20 text-blue-400' :
              'bg-slate-700 text-slate-400'
            }`}>
              {fault.detectionMethod === 'ml-model' ? '🤖 ML' : fault.detectionMethod === 'hybrid' ? '⚡ Hybrid' : '📏 Rule'}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-mono leading-relaxed">{fault.description}</p>
          <div className="flex items-center gap-3 mt-1.5">
            <span className="text-xs text-slate-500 font-mono">
              📍 {fault.nodeName}
            </span>
            <span className="text-xs text-slate-600 font-mono">
              {formatDistanceToNow(fault.timestamp, { addSuffix: true })}
            </span>
            <span className="text-xs font-mono text-blue-400">
              {(fault.mlConfidence * 100).toFixed(0)}% conf.
            </span>
            {fault.value !== undefined && (
              <span className="text-xs text-amber-400 font-mono">
                {fault.value.toFixed(2)} {fault.unit}
              </span>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export function AlertPanel() {
  const { allFaults, alertFilter, setAlertFilter, clearFaults } = useSimulationStore();

  const filtered = allFaults
    .filter(f => alertFilter === 'ALL' || f.severity === alertFilter)
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, 50);

  const criticalCount = allFaults.filter(f => f.severity === 'CRITICAL' && !f.resolved).length;
  const mediumCount = allFaults.filter(f => f.severity === 'MEDIUM' && !f.resolved).length;
  const lowCount = allFaults.filter(f => f.severity === 'LOW' && !f.resolved).length;

  return (
    <div className="rounded-2xl border border-slate-700/60 bg-slate-900/70 backdrop-blur-md">
      {/* Header */}
      <div className="px-5 py-3 border-b border-slate-700/50 flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-3">
          <span className="text-slate-400">🚨</span>
          <h3 className="text-sm font-semibold text-slate-200 font-mono uppercase tracking-wide">Alert Center</h3>
          {criticalCount > 0 && (
            <motion.span
              animate={{ opacity: [1, 0.4, 1] }}
              transition={{ duration: 0.8, repeat: Infinity }}
              className="text-xs bg-red-500/30 text-red-400 px-2 py-0.5 rounded-full font-mono"
            >
              {criticalCount} CRITICAL
            </motion.span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {/* Severity filter */}
          <div className="flex gap-1 bg-slate-800/60 rounded-lg p-1">
            {(['ALL', 'CRITICAL', 'MEDIUM', 'LOW'] as const).map(f => (
              <button
                key={f}
                onClick={() => setAlertFilter(f)}
                className={`text-xs px-2 py-1 rounded font-mono transition-colors ${
                  alertFilter === f
                    ? f === 'ALL' ? 'bg-blue-500/30 text-blue-300' :
                      f === 'CRITICAL' ? 'bg-red-500/30 text-red-300' :
                      f === 'MEDIUM' ? 'bg-amber-500/30 text-amber-300' :
                      'bg-blue-500/20 text-blue-300'
                    : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                {f} {f === 'CRITICAL' ? `(${criticalCount})` : f === 'MEDIUM' ? `(${mediumCount})` : f === 'LOW' ? `(${lowCount})` : `(${allFaults.length})`}
              </button>
            ))}
          </div>
          <button
            onClick={clearFaults}
            className="text-xs px-3 py-1 rounded-lg bg-slate-700/60 text-slate-400 hover:bg-slate-700 font-mono transition-colors"
          >
            Clear All
          </button>
        </div>
      </div>

      {/* Summary stats */}
      <div className="px-5 py-3 border-b border-slate-700/30 grid grid-cols-4 gap-3">
        {[
          { label: 'Total Alerts', value: allFaults.length, color: 'text-slate-300' },
          { label: 'Critical', value: criticalCount, color: 'text-red-400' },
          { label: 'Medium', value: mediumCount, color: 'text-amber-400' },
          { label: 'Resolved', value: allFaults.filter(f => f.resolved).length, color: 'text-emerald-400' },
        ].map(s => (
          <div key={s.label} className="text-center">
            <p className={`text-xl font-bold font-mono ${s.color}`}>{s.value}</p>
            <p className="text-xs text-slate-600">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Alerts list */}
      <div className="p-4 space-y-2 overflow-y-auto max-h-[500px] custom-scrollbar">
        {filtered.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-4xl mb-3">✅</div>
            <p className="text-slate-500 font-mono text-sm">No alerts {alertFilter !== 'ALL' ? `with severity ${alertFilter}` : ''}</p>
            <p className="text-slate-600 font-mono text-xs mt-1">All nodes operating normally</p>
          </div>
        ) : (
          <AnimatePresence mode="popLayout">
            {filtered.map(fault => (
              <AlertRow key={fault.id} fault={fault} />
            ))}
          </AnimatePresence>
        )}
      </div>
    </div>
  );
}
