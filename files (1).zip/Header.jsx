/**
 * Header.jsx
 * ----------
 * Top application bar.
 * Shows: logo, live indicator, connection state, node summary, critical alert badge.
 */

import React from "react";
import { clsx } from "clsx";
import { WS_STATES } from "../hooks/useWebSocket.js";

const CONNECTION_CONFIG = {
  [WS_STATES.CONNECTED]:    { label: "LIVE",         dot: "bg-emerald-400 animate-pulse", text: "text-emerald-400" },
  [WS_STATES.CONNECTING]:   { label: "CONNECTING…",  dot: "bg-amber-400 animate-pulse",   text: "text-amber-400"   },
  [WS_STATES.DISCONNECTED]: { label: "DISCONNECTED", dot: "bg-red-500",                   text: "text-red-400"     },
  [WS_STATES.ERROR]:        { label: "ERROR",         dot: "bg-red-500 animate-ping-once", text: "text-red-400"     },
};

export default function Header({
  connectionState,
  reconnectCount,
  onlineCount,
  offlineCount,
  totalNodes,
  criticalAlerts,
}) {
  const cfg = CONNECTION_CONFIG[connectionState] || CONNECTION_CONFIG[WS_STATES.DISCONNECTED];

  return (
    <header className="bg-surface-800 border-b border-surface-600 px-4 py-3 flex items-center justify-between gap-4 flex-wrap">

      {/* ── Logo + Title ───────────────────────────────────────────────────── */}
      <div className="flex items-center gap-3">
        {/* Animated logo icon */}
        <div className="relative w-9 h-9 flex items-center justify-center rounded-xl bg-brand-600/20 border border-brand-500/30">
          <span className="text-xl leading-none">⬡</span>
          {/* Pulse ring on connected */}
          {connectionState === WS_STATES.CONNECTED && (
            <span className="absolute inset-0 rounded-xl border border-brand-400/40 animate-pulse" />
          )}
        </div>
        <div>
          <h1 className="text-base font-bold text-gradient leading-none">NetWatch AI</h1>
          <p className="text-[10px] text-slate-500 mt-0.5 leading-none tracking-wide">
            Network Fault Detection System
          </p>
        </div>
      </div>

      {/* ── Centre: node counts ────────────────────────────────────────────── */}
      <div className="hidden sm:flex items-center gap-6">
        <NodeStat
          icon="🟢"
          label="Online"
          value={onlineCount}
          valueClass={onlineCount > 0 ? "text-emerald-400" : "text-slate-500"}
        />
        <NodeStat
          icon="🔴"
          label="Offline"
          value={offlineCount}
          valueClass={offlineCount > 0 ? "text-red-400" : "text-slate-500"}
        />
        <NodeStat
          icon="⬡"
          label="Total Nodes"
          value={totalNodes}
          valueClass="text-brand-300"
        />
        {criticalAlerts > 0 && (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-500/15 border border-red-500/30 animate-pulse">
            <span className="text-xs font-bold text-red-400">⚠ {criticalAlerts} CRITICAL</span>
          </div>
        )}
      </div>

      {/* ── Right: connection state ────────────────────────────────────────── */}
      <div className="flex items-center gap-3">
        {/* Reconnect counter */}
        {reconnectCount > 0 && (
          <span className="text-xs text-slate-500 font-mono hidden md:block">
            reconnects: {reconnectCount}
          </span>
        )}
        {/* Connection pill */}
        <div className={clsx(
          "flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold border",
          connectionState === WS_STATES.CONNECTED
            ? "bg-emerald-500/10 border-emerald-500/30"
            : connectionState === WS_STATES.CONNECTING
            ? "bg-amber-500/10 border-amber-500/30"
            : "bg-red-500/10 border-red-500/30"
        )}>
          <span className={clsx("w-2 h-2 rounded-full flex-shrink-0", cfg.dot)} />
          <span className={cfg.text}>{cfg.label}</span>
        </div>
      </div>

    </header>
  );
}

function NodeStat({ icon, label, value, valueClass }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-sm leading-none">{icon}</span>
      <div>
        <p className="text-[10px] text-slate-500 leading-none">{label}</p>
        <p className={clsx("text-sm font-bold leading-tight font-mono", valueClass)}>{value}</p>
      </div>
    </div>
  );
}
